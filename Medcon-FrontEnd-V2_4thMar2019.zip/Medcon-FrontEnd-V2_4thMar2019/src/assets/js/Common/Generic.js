﻿function ScrollToTopSection()
{

    $(window).scrollTop(5);
}