﻿export class Export {
    constructor(
        public id: number) { }

}
