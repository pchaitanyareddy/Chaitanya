import moment from 'moment';

export class ReportSchedule {
	private static DAY_OF_WEEK: string[] = [
		'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
	];

	constructor(public id: string,
		public trialId: number,
		public trialName: string,
		public cron: any) {
	}

	public intervalType(): ReportScheduleType {
		if (this.cron.hasOwnProperty('dayOfWeek')) {
			return ReportScheduleType.Weekly;
		} else if (this.cron.hasOwnProperty('day')) {
			return ReportScheduleType.Monthly;
		}

		return ReportScheduleType.Daily;
	}

	public cronReadable(): string {
		let result = '';

		switch (this.intervalType()) {
			case ReportScheduleType.Weekly:
				result += ReportSchedule.DAY_OF_WEEK[this.cron.dayOfWeek] + ' ';
				break;
			case ReportScheduleType.Monthly:
				if (this.cron.day === 'last') {
					result += 'end of month';
				} else {
					result += moment(this.cron.day, 'D').format('Do');
				}
				result += ' at ';
				break;
			default:
		}

		result += moment(this.cron.hour + ':' + this.cron.minute, 'HH:mm').format('HH:mm');

		return result;
	}
}

export enum ReportScheduleType {
	Weekly,
	Monthly,
	Daily
}
