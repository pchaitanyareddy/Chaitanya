﻿export class Company {
    constructor(public id: number,
        public name: string,
        public adherenceTarget: number,
        public companyType: string,
        public country: string =null,
        public countryId: number,
        public stateId: number,
        public state: string =null,
        public city: string,
        public zipcode: string,
        public phoneNumber: string,
        public address: string,
        public companyTypeId?: number;
        //public createdBy: string,
        //public createdDate: string,
        //public lastUpdatedBy: string,
        //public lastUpdatedDate: string,
        //public active: string,
        //public allowToEdit: number,
        //public allowToDelete: number

    ) {
    }
}
