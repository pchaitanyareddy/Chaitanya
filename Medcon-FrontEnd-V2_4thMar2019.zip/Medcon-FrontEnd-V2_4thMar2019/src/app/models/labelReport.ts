﻿export class LabelReport {
    constructor(
        ) {
    }
}
