export class MedConUser {
	constructor(public id: number,
		public sub: string,
		public givenName: string,
		public familyName: string,
		public email: string) {
	}
}
