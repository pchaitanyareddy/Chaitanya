export class Race {
	constructor(public id: number,
		public race: string) {
	}
}
