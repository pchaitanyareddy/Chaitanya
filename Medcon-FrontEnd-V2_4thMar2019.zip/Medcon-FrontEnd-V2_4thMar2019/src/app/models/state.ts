﻿export class State {
    constructor(public id: number,
        public name: string) {
    }
}
