﻿export class CompanyType {
    constructor(public companyTypeId: number,
        public companyType: string) {
    }
}
