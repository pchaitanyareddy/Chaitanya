﻿export class PatientSummaryGrid {
    constructor(public id: number,
        public patientID: string,
        public trialName: string,
        public trialGroupCount: number,
        public company: number,
        public startDate: number,
        public endDate: number,
        
    ) {
    }
}
