﻿export class PatientInformation {
    constructor(public id: number,
        public firstName: string,
        public lastName: string,
        public age: any,
        public gender: string,
        public emailAddress: string,
        public mobile: string,
        public race: string,
        public activeTrial: string,
        public country: string,
        public state: string,
        public city: string,
        public zipcode: string,
        public date: string,
        public active: string,
    ) {
    }
}
