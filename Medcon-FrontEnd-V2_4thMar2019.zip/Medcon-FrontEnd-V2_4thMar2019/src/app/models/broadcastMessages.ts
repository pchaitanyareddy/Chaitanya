﻿export class BroadcastMessages {
    constructor(
        public userName: string,
        public trailName: string,
        public patient: any,
        public msgType: string,
        public email: string,
        public messageTitle: string,
        public dateTime: string
        
    ) {
    }
}