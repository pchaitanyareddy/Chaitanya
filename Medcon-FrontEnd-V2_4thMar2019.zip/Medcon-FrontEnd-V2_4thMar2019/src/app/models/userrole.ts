export enum UserRole {
	MedConAdmin =1,
	CustomerAdmin=2,
    TrialAdmin = 3,
    LabelUser = 4,
    CustomerUser= 5,
	Patient=7,
}
