﻿export class PatientDosageDetails {
    constructor(public id: number,
        public patientID: string,
        public trialName: string,
        public dosagesTaken: number,
        public missedDosages: number,
        public scannedDosages: number,
        public manualDosages: number,
        public overdose: number,
    ) {
    }
}
