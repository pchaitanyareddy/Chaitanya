export class Pagination<T> {
	constructor(public page: number,
		public perPage: number,
		public pages: number,
		public total: number,
		public items: T[]) {
	}
}
