﻿export class CompanyEdit {
    constructor(
        public name: string,
        public companyType: string,
        public adherenceTarget: number,
        public address: string,
        public countryId: number,
        public stateId: number,
        public city: string,
        public zipcode: string,
        public phoneNumber: string,
        public country: string,
        public userId?: number

    ) {
    }
}
