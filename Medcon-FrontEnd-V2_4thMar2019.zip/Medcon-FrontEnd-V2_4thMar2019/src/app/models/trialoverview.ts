﻿export class TrialOverview {
    constructor(
        public lastScan: any,
        public firstScan: any,
        public target: any,
        public drug: any,
        public label: any,
        public trialinfo: any,
        public containers: any,
        //public containerId: number,
        //public patientId:string,
        //public datetime:any,

    ) {
    }
}
