﻿export class PatientReport {
    constructor(public id: number,
        public firstName: string,
        public lastName: string,
        public emailAddress: any,
        public mobile: string,
        public location: string,
        public status: string,
        public date: string,
    ) {
    }
}
