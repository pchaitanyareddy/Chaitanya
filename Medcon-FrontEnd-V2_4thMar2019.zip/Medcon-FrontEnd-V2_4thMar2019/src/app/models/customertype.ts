export class CustomerType {
	constructor(public id: number,
		public name: string) {
	}
}
