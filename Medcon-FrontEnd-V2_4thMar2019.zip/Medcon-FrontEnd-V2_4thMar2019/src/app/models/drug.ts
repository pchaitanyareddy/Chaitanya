export class Drug {
	constructor(public id: number,
		public name: string,
		public alias: string,
		public image: string,
        public inUse: boolean,
        public amount: number,
        public unit: string,
        public medicationId: number,
        public bucketKey:string
    ) {
	}
}
