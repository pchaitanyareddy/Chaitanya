﻿export class Notifications {
    constructor(
        public name: string,
        public userName: string,
        public trailName: string,
        public notificationType: string,
        public email: string,
        public numberOfSubscriptions: string,
        public trialNotifications: any,
        public notificationId: number

    ) {
    }
}