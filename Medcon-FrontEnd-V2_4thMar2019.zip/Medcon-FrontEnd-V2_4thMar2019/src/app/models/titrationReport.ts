﻿export class TitrateReport {
    constructor(
    ) {

    }
}
