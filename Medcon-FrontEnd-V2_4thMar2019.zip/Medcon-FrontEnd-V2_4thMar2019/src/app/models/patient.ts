export class Patient {
	constructor(public id: number,
		public patientNumber: string,
		public sex: string,
		public race: any,
		public dob: string,
		public firstScan: string,
		public lastScan: string) {
	}
}
