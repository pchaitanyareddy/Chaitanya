import { NgModule }      from '@angular/core';
import { DatexPipe }          from './datex.pipe';

@NgModule({
	imports: [],
	declarations: [DatexPipe],
	exports: [DatexPipe],
})
export class PipeModule {
	public static forRoot() {
		return {
			ngModule: PipeModule,
			providers: [],
		};
	}
}
