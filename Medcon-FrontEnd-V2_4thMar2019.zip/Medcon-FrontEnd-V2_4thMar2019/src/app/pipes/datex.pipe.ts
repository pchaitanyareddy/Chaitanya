import { Pipe, PipeTransform } from '@angular/core';
import moment from 'moment';

@Pipe({ name: 'myDatex' })
export class DatexPipe implements PipeTransform {
	public transform(value: any, format: string = ''): string {
		return moment(value).isValid() ? moment(value).format(format) : value;
	}
}
