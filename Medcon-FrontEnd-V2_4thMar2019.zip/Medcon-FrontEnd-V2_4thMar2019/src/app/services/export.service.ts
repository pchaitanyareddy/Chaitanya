﻿import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Pagination } from '../models/pagination';
import { Export } from '../models/export';
import { MedConUser } from '../models/medconuser';
import { saveAs } from 'file-saver';
import { TrialGroupRequest } from '../requests/trialgroup-request';
@Injectable()
export class ExportService {
    constructor(private http: Http) {
    }
    
    public getExportList(customerId: number, page?: number, perPage?: number): Observable<(Pagination<Export>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getExport(id: number, customerId?: number): Observable<(Export)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/export/' + id, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public exportAdherenceReport(trialId?: number): void {
        // Is supported
        try {
            let isFileSaverSupported = !!new Blob();
        } catch (e) {
            alert('Browser not supported');
            return;
        }

        let params: URLSearchParams = new URLSearchParams();
        params.set('trial_id', String(trialId || ''));
      
        this.http.get(API_PATH + '/export/adherence/export', { search: params })
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'))
            .subscribe((response) => {
                let blob = new Blob([decodeURIComponent(encodeURI(response.text()))], {
                    type: 'text/csv;charset=utf-8;'
                });

                let filename = 'medcon dose export.csv';
                saveAs(blob, filename);
            });
    }


}
