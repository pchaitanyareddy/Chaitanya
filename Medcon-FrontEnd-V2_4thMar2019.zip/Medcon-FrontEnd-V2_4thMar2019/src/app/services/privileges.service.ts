﻿import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Pagination } from '../models/pagination';
import { Privileges } from '../models/privileges';
import { MedConUser } from '../models/medconuser';
import { UserMedConCreateRequest } from '../requests/user-medcon-create-request';
import { UserPreferenceRequest } from '../requests/user-preference-request';
import { PrivilegesRequest } from '../requests/privileges-request';
import {CommonService} from '../services/commonService';
@Injectable()
export class PrivilegesService {
    constructor(private http: Http) {
    }


    public updatePrivileges(finalJsonString: string, roleId: number): Observable<(any)> {
        
        //return this.http.put('https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/roles/privileges/' + roleId, finalJsonString)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_PRIVILEGES+'roles/privileges/' + roleId, finalJsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getPrivileges(roleId:number)
    {
        
        //return this.http.get('https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/roles/privileges/' + roleId)
        return this.http.get(CommonService.API_PATH_V2_GET_PRIVILEGES+'roles/privileges/' + roleId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
       
    }

    public getPrivilegesByModule(roleId: number, moduleName: string)
    {

     return   [
           
            {
                "status": true,
                "moduleName": "Trials",
                "edit": 0,
                "add": 0,
                "view": 1,
                "id": 3,
                "delete": 0
            }
           
        ]


    }

    
}
