import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Site } from '../models/site';
import { SiteRequest } from '../requests/site-request';
import { Observable } from 'rxjs';
import { Country } from '../models/country';
import { State } from '../models/state';
import { CommonService }from '../services/commonService';

@Injectable()
export class SiteService {
    constructor(private http: Http) {
    }

    public getSites(customerId?: number): Observable<Site[]> {
        let customer = (customerId) ? '/' + customerId : '';

        return this.http.get(API_PATH + '/site/list' + customer)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createSite(request: SiteRequest, companyId: number): Observable<(any)> {

        //return this.http.post('https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/site/' + companyId, request)
        return this.http.post(CommonService.API_PATH_V2_CREATE_SITE + 'site/' + companyId, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));


    }

    public updateSite(id: number, request: SiteRequest): Observable<(any)> {

        //return this.http.put('https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/site/update/' + id, request)
        return this.http.put(CommonService.API_PATH_V2_UPDATE_SITE + 'site/update/' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getSite(id: number, customerId: number): Observable<(Site)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));
        

        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    //code added by Chaitanya
    public getSiteList(customerId: number, page?: number, perPage?: number): Observable<(Pagination<Site>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

       
        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public deleteSite(id: number): Observable<(any)> {
        

        //return this.http.delete('https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/site/delete/' + id)
        return this.http.delete(CommonService.API_PATH_V2_DELETE_SITE + 'site/delete/' + id)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }


    public getSelectedSite(siteId: number): any {

        //return this.http.get('https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/site/get/' + siteId)
        return this.http.get(CommonService.API_PATH_V2_GET_SELECTED_SITE + 'site/get/' + siteId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }

    public getCountries(): Observable<(Country[])> {

        //return this.http.get('https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/masterdata/list/countries')
        return this.http.get(CommonService.API_PATH_V2_LIST_OF_COUNTRIES + 'masterdata/list/countries')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getStatesByCountry(countryId: number): Observable<(State[])> {
        
        //return this.http.get('https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/masterdata/list/countries/' + countryId + '/states')
        return this.http.get(CommonService.API_PATH_V2_LIST_OF_STATES + 'masterdata/list/countries/' + countryId + '/states')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
}




