import { Injectable } from '@angular/core';

@Injectable()
export class TemplateService {
	public navigationMenuExtended = true;
}
