import { Injectable } from '@angular/core';
import { AwsUtil } from '../aws.service';
import { CognitoUtil } from './cognitoutil.service';
import { CognitoCallback, LoggedInCallback } from './cognito.service';
import { CurrentUserService } from '../currentuser.service';
import { UserRole } from '../../models/userrole';

/**
 * Created by Vladimir Budilov
 */

declare var AWS: any;
declare var AWSCognito: any;

@Injectable()
export class UserLoginService {

	constructor(public cognitoUtil: CognitoUtil,
		public currentUserService: CurrentUserService,
		public awsUtil: AwsUtil) {
	}

	public authenticate(username: string, password: string, callback: CognitoCallback, newPassword?: string,
		newAttributes?: { [key: string]: string }) {
		console.log('UserLoginService: starting the authentication');
		// Need to provide placeholder keys unless unauthorised user access is enabled for user pool
		AWSCognito.config.update({ accessKeyId: 'anything', secretAccessKey: 'anything' });

		let authenticationData = {
			Username: username,
			Password: password,
		};
		let authenticationDetails = new AWSCognito
			.CognitoIdentityServiceProvider
			.AuthenticationDetails(authenticationData);

		let userData = {
			Username: username,
			Pool: this.cognitoUtil.getUserPool()
		};

		console.log('UserLoginService: Params set...Authenticating the user');
		let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

		let handler = {
			onSuccess: (result) => {
				this.awsUtil.addCognitoCredentials(result.getIdToken().getJwtToken());

				callback.cognitoCallback(null, result);
			},
			onFailure: (err) => {
				callback.cognitoCallback(err.message, null);
			},
			newPasswordRequired: (userAttributes, requiredAttributes) => {
				// User was signed up by an admin and must provide new
				// password and required attributes, if any, to complete
				// authentication.

				// Either update the password or return that a new password is required
				if (newPassword != null) {
					cognitoUser.completeNewPasswordChallenge(newPassword, newAttributes, handler);
				} else {
					callback.cognitoCallback('newpassword', {
						required: requiredAttributes
					});
				}
			}
		};

		cognitoUser.authenticateUser(authenticationDetails, handler);
	}

	public forgotPassword(username: string, callback: CognitoCallback) {
		let userData = {
			Username: username,
			Pool: this.cognitoUtil.getUserPool()
		};

		let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

		cognitoUser.forgotPassword({
			onSuccess: (result) => {
				// Empty block
			},
			onFailure: (err) => {
				callback.cognitoCallback(err.message, null);
			},
			inputVerificationCode() {
				callback.cognitoCallback(null, null);
			}
		});

	}

	public confirmNewPassword(email: string,
		verificationCode: string,
		password: string,
		callback: CognitoCallback) {
		let userData = {
			Username: email,
			Pool: this.cognitoUtil.getUserPool()
		};

		let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

		cognitoUser.confirmPassword(verificationCode, password, {
			onSuccess: (result) => {
				callback.cognitoCallback(null, result);
			},
			onFailure: (err) => {
				callback.cognitoCallback(err.message, null);
			}
		});
	}

	public logout() {
        console.log('UserLoginService: Logging out');
        if(this.cognitoUtil.getCurrentUser()!=null)
		    this.cognitoUtil.getCurrentUser().signOut();
        this.currentUserService.clear();
        localStorage.clear();
	}

	public isAuthenticated(callback: LoggedInCallback) {
		if (callback == null) {
			throw('UserLoginService: Callback in isAuthenticated() cannot be null');
		}

		let cognitoUser = this.cognitoUtil.getCurrentUser();

		if (cognitoUser != null) {
			cognitoUser.getSession((err, session) => {
				if (err) {
					console.log('UserLoginService: Couldn\'t get the session: ' + err, err.stack);
					callback.isLoggedIn(err, false);
				} else {
					if (session.isValid()) {
						this.currentUserService.getRole().subscribe(
                            (role) => {
                                callback.isLoggedIn(err, true);
								
							},
							(err2) => {
								callback.isLoggedIn(err2, false);
							});
					} else {
						callback.isLoggedIn(err, false);
					}
				}
			});
		} else {
			console.log('UserLoginService: can\'t retrieve the current user');
			callback.isLoggedIn('Can\'t retrieve the CurrentUser', false);
		}
	}
}
