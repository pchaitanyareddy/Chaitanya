import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Settings } from '../models/settings';
import { Pagination } from '../models/pagination';
import { SettingsRequest } from '../requests/settings-request';
import { NotificationsmsgsRequest } from '../requests/notificationmsgs-request';
import { SettingsAlertMsgsRequest } from '../requests/settingsAlertMsgs-request';
import { CommonService }from '../services/commonService';


@Injectable()
export class SettingsService {
    constructor(private http: Http) {
    }

    public getSettings(customerId: number, page?: number,
        perPage?: number): Observable<(Pagination<Settings>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }

        return this.http.get(API_PATH + '/settings/list', { search: params })
            .map((res: Response) => {
                let response = res.json();
                response.items = [];
                res.json().items.forEach((item) => {
                    this.getCheckDosesLogged(item.id, customerId)
                        .subscribe((r) => item.inUse = r.value);
                    response.items.push(item);
                });
                return response;
            })
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getCheckDosesLogged(id: number, customerId: number): Observable<(any)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/settings/' + id + '/check/doses-logged', { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getSettingsAll(customerId: number): Observable<Settings[]> {
        return this.http.get(API_PATH + '/settings/list/' + customerId + '/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getSettingsUnusedList(customerId: number): Observable<Settings[]> {
        return this.http.get(API_PATH + '/settings/list/' + customerId + '/unused')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getSetting(id: number, customerId?: number): Observable<(Settings)> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('customer_id', String(customerId));

        return this.http.get(API_PATH + '/settings/' + id, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public createSettings(request: SettingsRequest): Observable<(any)> {
        return this.http.post(API_PATH + '/settings', request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public createSettingsAlert(jsonString: string,companyId:number): Observable<(any)> {

        //return this.http.put('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/alertmessages', jsonString)
        return this.http.put(CommonService.API_PATH_V2_CREATE_SETTING_ALERTMESSAGES + 'settings/alertmessages/' + companyId, jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public createSettingsNotificationMsgs(jsonString: string): Observable<(any)> {

        //return this.http.put('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/notificationmessages', jsonString)
            return this.http.put(CommonService.API_PATH_V2_CREATE_SETTING_NOTIFICATIONMESSAGES+'settings/notificationmessages', jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getSettingsList(customerId: number, page?: number, perPage?: number): Observable<(Pagination<Settings>)> {
        let params: URLSearchParams = new URLSearchParams();
        if (page) {
            params.set('page', String(page));
        }
        if (perPage) {
            params.set('per_page', String(perPage));
        }


        return this.http.get(API_PATH + '/user/list/' + customerId, { search: params })
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }





    public convertMinutesToString(totalMinutes: number): string {
        let minsPerDay = 24 * 60;
        let minsPerHour = 60;
        let minutes = totalMinutes;
        let converted = '';

        let days = Math.floor(minutes / minsPerDay);
        converted += days + 'D ';
        minutes = minutes - days * minsPerDay;
        let hours = Math.floor(minutes / minsPerHour);
        converted += hours + 'HRS ';
        minutes = minutes - hours * minsPerHour;
        converted += minutes + 'MINS';

        return converted;
    }
    public getTimeZone(companyId:number): any {

        //https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/timezone/all
        // return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/timezone/all')
        return this.http.get(CommonService.API_PATH_V2_GET_ALL_TIME_ZONE + 'settings/timezone/all?companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getSettingsDosageWindows(): any {

        //return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/dosagewindows')
           return this.http.get(CommonService.API_PATH_V2_GET_DOSAGE_WINDOW+'settings/dosagewindows')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateDosageWindows(jsonString: string): Observable<(any)> {

        //return this.http.put('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/dosagewindows', jsonString)
            return this.http.put(CommonService.API_PATH_V2_UPDATE_DOSAGE_WINDOW+'settings/dosagewindows', jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getAlertMessages(companyId:number): any {

        // return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/alertmessages')
        return this.http.get(CommonService.API_PATH_V2_GET_ALERT_MESSAGES + 'settings/alertmessages/' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateAlertMessages(id: number, request: SettingsRequest): Observable<(any)> {

        //return this.http.put('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/notificationmessages' + id, request)
            return this.http.put(CommonService.API_PATH_V2_UPDATE_ALERT_MESSAGES+'settings/notificationmessages' + id, request)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getNotificationMessages(): any {

        //return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/notificationmessages')
            return this.http.get(CommonService.API_PATH_V2_GET_NOTIFICATION_MESSAGES+'settings/notificationmessages')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public getDosageWindows(): Observable<(any)> {
        //return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/dosagewindows')
            return this.http.get(CommonService.API_PATH_V2_GET_DOSAGE_WINDOW + 'settings/dosagewindows')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

    public updateTimeZone(jsonString: string, companyId: number): Observable<(any)> {
        return this.http.put(CommonService.API_PATH_V2_UPDATE_SELECTED_TIME_ZONE + 'settings/timezone?companyId=' + companyId, jsonString)
        //return this.http.put('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/timezone', jsonString)
            .map((res: Response) => res.status === 200)
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
    public getTimeZoneDetails(companyId:number): Observable<(any)> {

        //return this.http.get('https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/settings/timezone')
        return this.http.get(CommonService.API_PATH_V2_GET_TIME_ZONE + 'settings/timezone?companyId=' + companyId)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
}
