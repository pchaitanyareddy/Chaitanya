import { Injectable } from '@angular/core';
import { UserRole } from '../models/userrole';
import { CognitoUtil } from './cognito/cognitoutil.service';
import { Observable } from 'rxjs';
import * as jwt_decode from 'jwt-decode';
import { Response, Http, URLSearchParams } from '@angular/http';
import {CommonService} from '../services/commonService';
@Injectable()
export class CurrentUserService {
	private _role: Observable<UserRole>;
	private _attributes: Observable<({ [key: string]: string })>;

    constructor(public cognitoUtil: CognitoUtil, private http: Http) {
	}

	/**
	 * Decode the identity token
	 * @returns {any}
	 */
	public getTokenInfo(): Observable<(Object)> {
		return Observable.create((subscriber) => {
			this.cognitoUtil.getIdToken({
				callback() {
					/* tslint:disable:no-empty */
				},
				callbackWithParam(token: any) {
					if (token === null) {
						subscriber.error(new Error('Token is null'));
						subscriber.complete();
					} else {
						let decoded = jwt_decode(token);
						subscriber.next(decoded);
						subscriber.complete();
					}
				}
			});
		});
	}

	public getRole(): Observable<UserRole> {
		if (!this._role) {
			this._role = this.getTokenInfo().map((attributes) => {
                let preferredRole = attributes['cognito:preferred_role'] || '';
					if (preferredRole.includes('customer-admin')) {
						return UserRole.CustomerAdmin;
					} else if (preferredRole.includes('customer-user')) {
						return UserRole.CustomerUser;
					} else if (preferredRole.includes('medcon-admin')) {
                        return UserRole.MedConAdmin;
                    } else if (preferredRole.includes('trial-admin')) {
                        return UserRole.TrialAdmin;
                    } else if (preferredRole.includes('label-user')) {
                        return UserRole.LabelUser;
					} else {
						return UserRole.Patient;
					}
				}
			)
				.publishReplay(1)
				.refCount();
		}

		return this._role;
	}

	public getUserAttributes(): Observable<({ [key: string]: string })> {
		if (!this._attributes) {
			this._attributes = this.getTokenInfo()
				.publishReplay(1)
				.refCount();
		}

		return this._attributes;
	}

	public clear(): void {
		this._role = null;
		this._attributes = null;
    }

    public getUserProfile(emailAddress: string):any
    {
        
        //return this.http.get('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/profile/' + emailAddress)
        return this.http.get(CommonService.API_PATH_V2_GET_USER_PROFILE+'user/profile/' + emailAddress)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }
}
