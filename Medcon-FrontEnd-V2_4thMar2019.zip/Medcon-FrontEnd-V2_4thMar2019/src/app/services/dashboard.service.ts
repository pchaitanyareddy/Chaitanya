import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { UserService } from './user.service';
import { UserPreferenceRequest } from '../requests/user-preference-request';

@Injectable()
export class DashboardService {
	public doseAdherenceInfo = new BehaviorSubject(null);
	public doseComplianceInfo = new BehaviorSubject(null);
	public doseTrackLogged = new BehaviorSubject(null);
	public dosageHistory = new BehaviorSubject(null);
	public viewState = new BehaviorSubject(null);

	constructor(private userService: UserService) {
	}

	public trackDosesLogged(logged: any): void {
		let doses = { daily: [], weekly: [], monthly: [] };
		let response: any;
		let ranges = ['daily', 'weekly', 'monthly'];

		ranges.forEach((range) => {
			response = logged[range];
			doses[range] = [
				{
					heading: 'Doses captured from scanning',
					first: {
						value: response.scan.now,
						percentage: (response.scan.now >= response.scan.then) ?
							(response.scan.now === 0) ? 0 : 100 :
							(response.scan.now / response.scan.then) * 100
					},
					second: {
						value: response.scan.then,
						percentage: (response.scan.then >= response.scan.now) ?
							(response.scan.then === 0) ? 0 : 100 :
							(response.scan.then / response.scan.now) * 100
					}
				},
				{
                    heading: 'Doses captured manually',
					first: {
						value: response.manual.now,
						percentage: (response.manual.now >= response.manual.then) ?
							(response.manual.now === 0) ? 0 : 100 :
							(response.manual.now / response.manual.then) * 100
					},
					second: {
						value: response.manual.then,
						percentage: (response.manual.then >= response.manual.now) ?
							(response.manual.then === 0) ? 0 : 100 :
							(response.manual.then / response.manual.now) * 100
					}
				},
				{
                    heading: 'Total doses captured',
					first: {
						value: response.total.now,
						percentage: (response.total.now >= response.total.then) ?
							(response.total.now === 0) ? 0 : 100 :
							(response.total.now / response.total.then) * 100
					},
					second: {
						value: response.total.then,
						percentage: (response.total.then >= response.total.now) ?
							(response.total.then === 0) ? 0 : 100 :
							(response.total.then / response.total.now) * 100
					}
				}
			];
		});

		this.doseTrackLogged.next(doses);
	}

	public setDashboardStateValue(key: string, value: string) {
		let state = this.viewState.getValue();
		state[key] = value;
		this.viewState.next(state);

		let request = new UserPreferenceRequest(
			'dashboard_state',
			state
		);
        
	}
}
