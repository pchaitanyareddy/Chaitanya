import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { LabelService } from './label.service';
import { Customer } from '../models/customer';
import { CustomerRequest } from '../requests/customerrequest';
import { Pagination } from '../models/pagination';
import { CustomerType } from '../models/customertype';
import { User } from '../models/user';
import {CommonService} from '../services/commonService';
@Injectable()
export class CustomerService {
	constructor(private http: Http,
		private labelService: LabelService) {
	}

	public createCustomer(request: CustomerRequest): Observable<(any)> {
		return this.http.post(API_PATH + '/customer', request)
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getCustomers(page?: number, perPage?: number): Observable<(Pagination<Customer>)> {
		let params: URLSearchParams = new URLSearchParams();
		if (page) {
			params.set('page', String(page));
		}
		if (perPage) {
			params.set('per_page', String(perPage));
		}

		return this.http.get(API_PATH + '/customer/lists', { search: params })
			.map((res: Response) => {
				let response = res.json();
				response.items = [];
				res.json().items.forEach((item) => {
					this.labelService.getCustomerOverview(item.id).subscribe((labels) => item.labels = labels);
					response.items.push(item);
				});
				return response;
			})
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getCustomerTypesAll(): Observable<(CustomerType[])> {
		return this.http.get(API_PATH + '/customer/type/lists/all')
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

    public getCustomersAll(): Observable<(Customer[])> {
        return this.http.get(API_PATH + '/customer/lists/all')
        	.map((res: Response) => res.json())
        	.catch((error: any) => Observable.throw(error.json().message || 'Server error'));

    }

    public getUsersAll(): Observable<(User[])> {
       
        
        //return this.http.get('https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/user/list/medcon/' + 1 + '/all')
        return this.http.get(CommonService.API_PATH_V2_GET_MEDCON_USER_LIST_ALL+'user/list/medcon/' + 1 + '/all')
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
    }

	public getCustomer(id: number): Observable<(Customer)> {
		return this.http.get(API_PATH + '/customer/' + id)
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updateCustomer(id: number, request: CustomerRequest): Observable<(any)> {
		return this.http.put(API_PATH + '/customer/' + id, request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public updateMyCompany(id: number, request: any): Observable<(any)> {
		return this.http.put(API_PATH + '/customer/my-company/' + id, request)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public deleteCustomer(id: number): Observable<(any)> {
		return this.http.delete(API_PATH + '/customer/' + id)
			.map((res: Response) => res.status === 200)
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}
}
