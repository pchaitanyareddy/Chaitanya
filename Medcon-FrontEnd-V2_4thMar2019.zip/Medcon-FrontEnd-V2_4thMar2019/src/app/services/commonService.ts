﻿import { Response, Http, URLSearchParams } from '@angular/http';
import { saveAs } from 'file-saver';
import { Observable } from 'rxjs/Rx';
import { Router, ActivatedRoute } from '@angular/router';

export class CommonService {
    constructor(private http: Http, private router: Router) {
    }

    //public static API_URL_CREATE_MEDCON_USER_URL = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';

    public static API_PATH_V2_CREATE_MEDCON_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V1_UPDATE_MEDCON_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_MEDCON_USER_LIST = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_MEDCON_USER_LIST_ALL = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_SELECTED_MEDCON_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_MEDCON_USER_STATUS = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_MEDCON_USER_LOGIN_TIME = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_MEDCON_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_COMPANY = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_COMPANY = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_COMPANIES = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_ALL_COMPANIES = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_ROLES = 'https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_PRIVILEGES = 'https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_PRIVILEGES = 'https://dxsvri6c3i.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_REGIMEN = 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_REGIMEN = 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_REGIMEN = 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_ALL_REGIMENS = 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_TRIAL_GROUP = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_TRIAL_GROUP = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_TRIAL_GROUP = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_ALL_TRIAL_GROUPS = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_SITE = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_SITE = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_SITES = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_ALL_SITES = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_MEASUREMENT = 'https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_MEASUREMENT = 'https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_MEASUREMENTS = 'https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_ALL_MEASUREMENTS = 'https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_DRUG = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_DRUG = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_DRUGS = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_ALL_DRUGS = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_OF_COUNTRIES = 'https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_OF_STATES = 'https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_OF_RACES = 'https://adt18nasck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_LIST_ALL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_UPDATE = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_TRIAL_OPTION = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_PATIENT_ALERTS = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_IMPORT_PATIENTS = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_VALIDATE_CONTAINER = 'https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER = 'https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev';
    public static API_PATH_V2_GET_SELECTED_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_PATIENT_USER = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_MEDCON_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_PATIENT_USER = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_PROFILE = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_USER_PROFILE = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_PREFERENCES = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_PREFERENCES = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_PATIENT_DETAILS = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_SUMMARY = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_PATIENT_DOSAGE_LIST = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_PATIENT_SUMMARY_LIST = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_PATIENT_OVERVIEW_DASHBOARD = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_PATIENT_LIST = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_COMPANY = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_COMPANY = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_COMPANY_OVERVIEW = 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_REGIMEN = 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_REGIMEN = 'https://zhbh3gq3ck.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_GROUP_NOTIN_TRAIL = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_TRIAL_GROUP = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_TRIAL_GROUP = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_SITE = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SITE_NOTIN_TRAIL = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_SITE = 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_MEASUREMENT_STATUS = 'https://mlb9vl5jra.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_DRUGS = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_DRUGS = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_OVERVIEW = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_DRUG_REGIMEN_VIEW = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRITRATE_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_DRUG_REGIMEN_PAIR = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_PATIENTS = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_PATIENTS_CONTAINER = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_PATIENTS_TRITRATE = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIAL_CONTAINER = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_TRIAL_OPTIONS = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_PATIENT_ALERTS = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_PATIENT_ALERTS = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_ASSOCIATE_TRAILGROUP = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_ADD_ASSOCIATE_TRAILGROUP = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DISASSOCIATE_TRAILGROUP = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_ASSOCIATE_SITE = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DISSOCIATE_SITE = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TRIALGROUP_UNDER_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_ADD_ASSOCIATE_SITE = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LIST_SITES_UNDER_TRIAL = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_ATTACH_PATIENT_TO_CONTAINER_MOBILE = 'https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev';
    public static API_PATH_V2_GET_CONTAINER_INFO_FOR_ATTACH_PATIENT_HISTORY = 'https://1senq8suqa.execute-api.us-east-1.amazonaws.com/dev';
    public static API_PATH_V2_UPLOAD_DOSE = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DOSE_OVERVIEW = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DOSE_HISTORY = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DOSE_TRACK = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_ADHERENCE_INFO = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_COMPALIANCE_INFO = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_COMMITTED_DOSE = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DATA_REPORT = 'https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_DOSAGE_WINDOW = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_DOSAGE_WINDOW = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_ALERT_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_ALERT_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_NOTIFICATION_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_NOTIFICATION_MESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_TIME_ZONE = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_ALL_TIME_ZONE = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_SELECTED_TIME_ZONE = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_LIST_NOTIFICATION = 'https://fy94ir6gxh.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_COMMIT_LABEL_PURCHASE = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_PURCHASE_LABEL = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_LIST_LABEL_PURCHASE = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_LABEL_DETAILS = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_UPDATE_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_LIST_LABEL_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_SELECTED_LABEL_COMMITMENT = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_EXPORT_LABEL_DATA = 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_EDIT_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_LIST_BROADCAST_MESSAGE = 'https://lv41c92qrl.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TITRATE_REPORT = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_LABEL_REPORT = 'https://74dxesudb2.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_SETTING_ALERTMESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_CREATE_SETTING_NOTIFICATIONMESSAGES = 'https://uk5tz1dufj.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_GET_ALL_DRUG = 'https://x70bddcqb4.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_MEDCON_USER_LIST = 'https://8y33w148di.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_VIEW_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_EDIT_DRUG_REGIMEN_PAIR_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_EDIT_TRIAL_PATIENT_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_EDIT_TRIAL_CONTAINERS_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_EDIT_ASSOCIATE_TRIALGROUP_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_TRIAL_EDIT_ASSOCIATE_SITE_LIST = 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_SELECTING_TRIAL_GROUP_FOR_TRIAL_LIST = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_SELECTING_TRAIL_FOR_PATIENT_LIST = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_SELECTING_PATIENT_LIST_FOR_CONTAINER = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_DELETE_PATIENT_UNDER_TRIAL_EDIT = 'https://qd7zrem01a.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_SELECTING_LOCATION_LIST_FORM_TRAIL = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_SELECTING_PATIENT_LIST_FORM_LOCATION = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_SELECTING_DRUG_LIST_FORM_TRAIL = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static API_PATH_V2_SELECTING_REGIMEN_LIST_FORM_DRUG = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';
    public static MEDCON_V2_S3_BUCKET_URL ='https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/'
    public static API_PATH_V2_UPDATE_BULK_CONTAINER_STATUS = 'https://pnq0mvxp0l.execute-api.us-east-1.amazonaws.com/dev/';


    public onRefresh(companyId, viewName) {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url + '?';

        this.router.navigateByUrl(currentUrl)
            .then(() => {
                this.router.navigated = false;
                if (companyId != '')
                    this.router.navigate(['/', companyId, viewName]);
                else
                    this.router.navigate(['/' + viewName]);
            });
    }
}