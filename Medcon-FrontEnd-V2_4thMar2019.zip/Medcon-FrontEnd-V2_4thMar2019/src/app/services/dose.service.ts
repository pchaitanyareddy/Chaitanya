import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import {CommonService} from '../services/commonService';
@Injectable()
export class DoseService {
	constructor(private http: Http) {
	}

	public getOverview(trialId?: number, companyId?: number): Observable<(any)> {
		
        

        //return this.http.get('https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/overview?companyId=' + companyId)
        let apiUrl = '';
        if (trialId != 0)
            apiUrl = CommonService.API_PATH_V2_DOSE_OVERVIEW + 'dose/overview?companyId=' + companyId + '&trialId=' + trialId;
        else
            apiUrl = CommonService.API_PATH_V2_DOSE_OVERVIEW + 'dose/overview?companyId=' + companyId;
        return this.http.get(apiUrl)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));

	}

	public getCustomerOverview(customerId: number): Observable<(any)> {
		return this.http.get(API_PATH + '/dose/overview/customer/' + customerId)
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

    public getAdherenceInfo(trialId?: number, companyId?: number): Observable<(any)> {
		
        
        //return this.http.get('https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/adherence?companyId=' + companyId)
        let apiUrl = '';
        if (trialId != 0)
            apiUrl = CommonService.API_PATH_V2_ADHERENCE_INFO + 'dose/adherence?companyId=' + companyId + '&trialId=' + trialId;
        else
            apiUrl = CommonService.API_PATH_V2_ADHERENCE_INFO + 'dose/adherence?companyId=' + companyId;
        return this.http.get(apiUrl)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getComplianceInfo(trialId?: number, companyId?: number): Observable<(any)> {
		
        
        //return this.http.get('https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/compliance?companyId=' + companyId)
        let apiUrl = '';
        if (trialId != 0)
            apiUrl = CommonService.API_PATH_V2_COMPALIANCE_INFO + 'dose/compliance?companyId=' + companyId + '&trialId=' + trialId;
        else
            apiUrl = CommonService.API_PATH_V2_COMPALIANCE_INFO + 'dose/compliance?companyId=' + companyId; 
        return this.http.get(apiUrl)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

    public getTrackLogged(companyId: number, trialId:number): Observable<(any)> {
		

        
        
        //return this.http.get('https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/dosagetrack?companyId=' + companyId)
        let apiUrl = '';
        if (trialId != 0)
            apiUrl = CommonService.API_PATH_V2_DOSE_TRACK + 'dose/dosagetrack?companyId=' + companyId + '&trialId=' + trialId;
        else
            apiUrl = CommonService.API_PATH_V2_DOSE_TRACK + 'dose/dosagetrack?companyId=' + companyId; 
        return this.http.get(apiUrl)
			.map((res: Response) => res.json())
			.catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}

	public getDosageHistory(companyId:number,trialId?:number): Observable<(any)> {
		
        
        //return this.http.get('https://imkjr9tsib.execute-api.us-east-1.amazonaws.com/dev/dose/dosagehistory?companyId=' + companyId)

        let apiUrl = '';
        if (trialId != 0)
            apiUrl = CommonService.API_PATH_V2_DOSE_HISTORY + 'dose/dosagehistory?companyId=' + companyId + '&trialId=' + trialId;
        else
            apiUrl = CommonService.API_PATH_V2_DOSE_HISTORY + 'dose/dosagehistory?companyId=' + companyId; 

        return this.http.get(apiUrl)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().message || 'Server error'));
	}
}
