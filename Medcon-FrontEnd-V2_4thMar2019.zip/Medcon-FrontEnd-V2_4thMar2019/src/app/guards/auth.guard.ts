import { Injectable } from '@angular/core';
import {
	Router,
	CanActivate,
	ActivatedRouteSnapshot,
	RouterStateSnapshot,
	CanActivateChild
} from '@angular/router';
import { Observable } from 'rxjs';
import { CurrentUserService } from '../services/currentuser.service';
import { UserRole } from '../models/userrole';
import * as _ from 'lodash';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {

	constructor(private router: Router, private currentUserService: CurrentUserService) {
	}

	public canActivate(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

		let observable = this.currentUserService.getRole().flatMap((result) => {
			if (result === UserRole.Patient) {
				return Observable.of(false);
			}
			if ('roles' in route.data) {
				let roles = route.data.roles;
				return Observable.of(_.includes(roles, result));
			}
			return Observable.of(true);
		});

		observable.subscribe(
			(allow) => {
				if (!allow) {
					this.router.navigate(['']);
				}
			},
			(error) => {
				this.router.navigate(['']);
			});

		return observable;
	}

	public canActivateChild(childRoute: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
		return this.canActivate(childRoute, state);
	}
}
