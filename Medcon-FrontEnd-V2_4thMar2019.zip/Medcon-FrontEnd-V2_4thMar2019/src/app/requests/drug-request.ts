export class DrugRequest {
    constructor(
        public name: string,
        public alias: string,
        public image: string,
        public medicationAmount: number,
        public userId: number,
        public medicationTypeId: number

    ) {
    }
}