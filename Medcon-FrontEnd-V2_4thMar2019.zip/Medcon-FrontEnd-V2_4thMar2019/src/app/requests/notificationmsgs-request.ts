﻿export class NotificationsmsgsRequest {
    constructor(
        public txtMissedDose: string,
        public txtOverDose: string,
        public txtLateDose: string,
        public txtUnderDose: string,
        public txtExcessDose: string,
        public txtthreshold: string
        //public trialNotifications: any
    ) {
    }
}