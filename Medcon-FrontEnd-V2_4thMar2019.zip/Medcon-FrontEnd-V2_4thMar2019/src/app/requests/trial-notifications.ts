﻿export class TrialNotificationsRequest {
    constructor(public trialId: number,
        public missedDoseText: string,
        public missedDoseOccurances: number,
        public overDoseText: string,
        public overDoseOccurances: number,
        public lateDoseText: string,
        public lateDoseOccurances: number,
        public underDoseText: string,
        public underDoseOccurances: number,
        public excessiveManualDosesText: string,
        public excessiveManualDosesOccurances: number,
        public notificationType: string
    ) {
    }
}