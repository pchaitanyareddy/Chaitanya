﻿export class BroadcastMessagesRequest {
    constructor(
        public trialId: number,
        public messageTitle: string,
        public broadcastMessage: any,
        public companyId: number
    ) {
    }
}
