﻿export class TrialGroupRequest {
    constructor(
        
        public trialGroupName: string,
        //public createdBy: number=null,
        //public createdDate: string =null
        public userId?: number
    ) {
    }
}
