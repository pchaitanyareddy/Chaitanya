﻿export class TrailGroupAssociateRequest {
    constructor(
        public trailGroupId?: number,
        public userId?: number
    
    ) {
    }
}
