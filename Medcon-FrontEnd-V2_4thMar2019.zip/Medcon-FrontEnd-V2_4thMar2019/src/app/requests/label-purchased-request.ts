﻿export class LabelPurchasedRequest {
    constructor(
        public purchased: number,
        public userId:number
        //public companyName: string,
        //public companyId?: number,
    ) {

    }
}
