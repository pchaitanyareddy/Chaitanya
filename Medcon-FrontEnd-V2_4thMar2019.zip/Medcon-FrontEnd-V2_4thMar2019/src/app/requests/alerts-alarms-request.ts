export class AlertsAlarmsRequest {
	constructor(public alerts: any) {
	}
}
