export class CustomerRequest {
	constructor(public name: string,
		public type: number) {
	}
}
