﻿export class SettingsAlertMsgsRequest {
    constructor(
        public thresholdAlert: number,
        public txtthreshold: string,
        public onTimeDoseAlert: number,
        public txtOntimeDose: string,
        public preDoseAlert: number,
        public txtPreDose: string
        //public trialNotifications: any
    ) {
    }
}