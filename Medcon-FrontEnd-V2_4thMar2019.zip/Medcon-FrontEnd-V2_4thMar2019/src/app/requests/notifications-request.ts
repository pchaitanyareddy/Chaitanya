﻿export class NotificationsRequest {
    constructor(
        public listOfTrails: string,
        public missedDose: number,
        public missedDoseOccurrence: number,
        public overDose: number,
        public overDoseOccurrence: number,
        public lateDose: number,
        public lateDoseOccurrence: number,
        public underDose: number,
        public underDoseOccurrence: number,
        public excessiveManualDose: number,
        public excessiveManualDoseOccurrence: number,
        public notificationType: string,
        public userId: number
      
    ) {
    }
}