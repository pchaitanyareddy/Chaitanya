export class TrialRequest {
    constructor(
        public name: string,
		public startDate: string,
        public endDate: string,
        public userId: number,
        public trailGroupId?: number
    ) {
	}
}
