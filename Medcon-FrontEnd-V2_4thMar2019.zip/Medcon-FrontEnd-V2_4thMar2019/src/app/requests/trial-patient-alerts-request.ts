﻿export class TrialPatientAlertsRequest {
    constructor(
        
        public preDoseAlertText: string,
        public preDoseAlertTime: number,
        public onTimeDoseAlertText: string,
        public thresholdDueAlertText: string,
        public thresholdDueAlertTime: number,
        public thresholdWindowText: string,
        public thresholdWindowAlertTime: number,
        public userId: number
        //public preDoseAlertDays: number,
        //public preDoseAlertHours: number,
        //public preDoseAlertMinutes: number,
        //public thresholdDueAlertDays: number,
        //public thresholdDueAlertHours: number,
        //public thresholdDueAlertMinutes: number,
        //public thresholdWindowAlertDays: number,
        //public thresholdWindowAlertHours: number,
        //public thresholdWindowAlertMinutes: number
    ) {
    }
}
