export class PatientUploadRequest {
	constructor(public numbers: any,
        public trialId: number,
        //public companyId: number =0,
        public ignoreDuplicates: boolean,
        public userId?: number,
        public companyId?:number
    ) {
	}
}
