﻿export class MeasureDeleteRequest {
    constructor(
        public status: boolean,
        public userId?: number
    ) {
    }
}
