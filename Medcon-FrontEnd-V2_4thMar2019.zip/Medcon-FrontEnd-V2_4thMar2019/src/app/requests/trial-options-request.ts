export class TrialOptionsRequest {
    constructor(
        public patient_enrollement_target: number,
        public trial_adherence_target: number,
        public minimum_patient_adherence_target: number,
        
        public turn_off_manual_dosing: number,
        public userId: number
    ) {
	}
}
