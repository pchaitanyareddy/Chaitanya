export class UserMedConCreateRequest {
	constructor(public givenName: string,
		public familyName: string,
		public email?: string) {
	}
}
