﻿export class CompanyEditRequest {
    constructor(

        public companyName: string,
        public companyType: string,
        public companyAdherenceTarget: number,
        public address: string,
        public countryId: number,
        public stateId: number,
        public cityName: string,
        public zipcode: number,
        public phoneNumber: number,
        public userId: number

        //public countryName?: string,
        //public stateName?: string
        //public createdBy: string,
        //public createdDate: string,
        //public lastUpdatedBy: string,
        //public lastUpdatedDate: string,
        //public active: string,
        //public allowToEdit: number,
        //public allowToDelete: number
    ) {
    }
}
