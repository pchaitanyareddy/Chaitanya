﻿export class TrialgroupAddAssociateRequest {
    constructor(
        public trialGroupName?: string,
        public companyId?: number,
        public userId?: number

    ) {
    }
}
