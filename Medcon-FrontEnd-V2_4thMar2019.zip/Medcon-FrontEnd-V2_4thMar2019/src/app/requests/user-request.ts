export class UserRequest {
    

    constructor(
        //public sub:string,
        public userId: number,
        public firstName: string,
        public lastName: string,
        public emailAddress: string,
        public roleId: number,
        public roleName: string,
        public phoneNumber: string,
        public companyId:number,
        //public password: string,
        //public dateOfBirth: Date,
        //public gender: string,
        //public raceName: string,
        //public createdBy: number,
        //public createdDate: Date,
        //public lastUpdatedBy: number,
        //public lastUpdatedDate: Date,
        //public active: string
    )
    {
        

    } 
		
}
