export class ReportScheduleRequest {
	constructor(public trialId: number,
		public cron: any) {
	}
}
