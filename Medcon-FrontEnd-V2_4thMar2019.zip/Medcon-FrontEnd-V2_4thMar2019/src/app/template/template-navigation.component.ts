import { Component, HostListener, OnInit, Compiler } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserLoginService } from '../services/cognito/cognito.service';
import { TemplateService } from '../services/template.service';
import { CurrentUserService } from '../services/currentuser.service';
import { CustomerService } from '../services/customer.service';
import { CognitoUser } from '../models/cognito-user';
import { UserRole } from '../models/userrole';
import { Customer } from '../models/customer';
import { CompanyService } from '../services/company.service';
import { Privileges } from '../models/privileges';
import { PrivilegesService } from '../services/privileges.service';
import { LocalStorageService } from '@angular2-localstorage/LocalStorageEmitter'
import { SessionStorage } from '@angular2-localstorage/WebStorage'
import { LocationStrategy } from '@angular/common';
import { UserProfile } from '../models/UserProfile';

@Component({
	selector: 'navigation-template',
    templateUrl: './template-navigation.component.html?v=${new Date().getTime()}'
})

export class TemplateNavigationComponent implements OnInit {
	public UserRole: typeof UserRole = UserRole;
	public date = new Date();
	public userMenuExtended = false;
	public user: CognitoUser = new CognitoUser(-1, '', '', -1);
	public customer: Customer;
    allCompanyList: any;
    allCompanyListWithCompanyType: any = [];
    public selectedCompanyId: number;
    public currentUserRole: UserRole;
    privilegesList1: any;
    public privilegesFilterList: any;
    selectedRoleId: number;
    public isDashBoardHasAccess: boolean;
    public isDataReportsHasAccess: boolean;
    public isPatientReportsHasAccess: boolean;
    public isTrialsHasAccess: boolean;
    public isTrialGroupHasAccess: boolean;
    public isNotificationHasAccess: boolean;
    public isManageUserHasAccess: boolean;
    public isManageMedconUserHasAccess: boolean;
    public isPrivilegesHasAccess: boolean;
    public isManageCompanyHasAccess: boolean;
    public isLabelsHasAccess: boolean;
    public isManageSitesHasAccess: boolean;
    public isPatientAlertHasAccess: boolean;
    public isScheduleHasAccess: boolean;
    public isImportPatientHasAccess: boolean;
    public isBroadcastMessagesHasAccess: boolean;
   
    public isMeasurementHasAccess: boolean;
    public isSettingsHasAccess: boolean;
    public isManageDrugHasAccess: boolean;
    public isManageRegimenHasAccess: boolean;
    public isManageCustomerUsersHasAccess: boolean;
    public isCustomersHasAccess: boolean;
    public isOverviewMenuVisible: boolean;
    public isReportingMenuVisible: boolean;
    public isClinicalTrialsMenuVisible: boolean;
    public isUserManagementMenuVisible: boolean;
    public isAdministrationMenuVisible: boolean;
    public privileges: Privileges;
    public isExportMenuHasAccess: boolean;
    public isPrivilegesMenuHasAccess: boolean;
    usersList: any;
    selectCompany: string;
    loggedInUserRole: number;
    loggedInUserRoleName: string;
    userProfileCompanyName: string;
    public userProfile: UserProfile;
    isLoading: boolean;
	constructor(private router: Router,
		private templateService: TemplateService,
		public userService: UserLoginService,
		public currentUserService: CurrentUserService,
        private customerService: CustomerService,
        private companyService: CompanyService,
        private privilegesService: PrivilegesService,
        private route: ActivatedRoute,
        private url: LocationStrategy,
        private _compiler: Compiler
      ) {
		setInterval(() => {
			this.date = new Date();
        }, 32000);

	}

	// Toggle navigation menu
	public toggleNavigationMenu(): void {
		this.templateService.navigationMenuExtended = !this.templateService.navigationMenuExtended;
	}

	// Toggle User Menu
	public toggleUserMenu(event) {
		this.userMenuExtended = !this.userMenuExtended;
	}

	public logout() {
		this.userService.logout();
		this.router.navigate(['/']);
	}

    public ngOnInit(): void {
    this._compiler.clearCache();
    this.privileges = this.route.snapshot.data['privileges'];
    this.privilegesList1 = this.privileges;
    
    this.isDashBoardHasAccess=false;
    this.isDataReportsHasAccess = false;
    this.isPatientReportsHasAccess = false;
    this.isTrialsHasAccess = false;
    this.isTrialGroupHasAccess = false;
    this.isNotificationHasAccess = false;
    this.isManageUserHasAccess = false;
    this.isManageMedconUserHasAccess = false;
    this.isPrivilegesHasAccess = false;
    this.isManageCompanyHasAccess = false;
    this.isLabelsHasAccess = false;
    this.isManageSitesHasAccess = false;
    this.isPatientAlertHasAccess = false;
    this.isScheduleHasAccess = false;
    this.isImportPatientHasAccess = false;
    this.isBroadcastMessagesHasAccess = false;
    this.isMeasurementHasAccess = false;
    this.isSettingsHasAccess = false;
    this.isOverviewMenuVisible = false;
    this.isReportingMenuVisible = false;
    this.isClinicalTrialsMenuVisible = false;
    this.isUserManagementMenuVisible = false;
    this.isAdministrationMenuVisible = false;
    this.isExportMenuHasAccess = false;
        this.selectedCompanyId = 1;
        this.selectCompany = "Medcon";//this.allCompanyList[0].companyName;
        this.userProfileCompanyName = localStorage.getItem('GLOBAL_USER_PROFILE_COMPANY_NAME');
		this.currentUserService.getRole().subscribe(
			(role) => this.user.role = role,
			(err) => console.log(err)
		);
        
        this.currentUserRole = this.user.role;
        
		this.currentUserService.getUserAttributes().subscribe(
			(attributes) => {
				this.user.email = attributes['email'];
				this.user.name = attributes['name'];
                this.user.customerId = Number(attributes['custom:customer_id']); //This is companyId for all medcon users
                this.selectedCompanyId = this.user.customerId;
                
                this.loggedInUserRole = this.user.role;
                
                this.loggedInUserRoleName = localStorage.getItem("LOGGED_IN_USER_ROLE");
                if (this.loggedInUserRoleName != 'MedCon Admin') {
                    this.selectCompany = localStorage.getItem("GLOBAL_COMPANY_NAME");
                            
                        }
                
                
                if (this.loggedInUserRoleName === 'MedCon Admin')
                {

                    if (this.usersList != null)
                        this.user.customerId = this.usersList[0].userId; //As this user is medcon admin, we r getting userId instead of companyId
                }
                if (this.loggedInUserRoleName === 'MedCon Admin' || this.loggedInUserRoleName === 'Label User') {
                   
                   
                    this.companyService.getAllCompanies().subscribe(
                        (response) => {
                            this.allCompanyList = response;
                            
                        },
                        (err) => {
                           

                        });

                }
			},
			(err) => {
				console.log(err);
            });
        if (localStorage.getItem('GLOBAL_COMPANY_ID') == "undefined" || Number(localStorage.getItem('GLOBAL_COMPANY_ID'))==0) {
            
            if (this.loggedInUserRoleName != 'MedCon Admin')
                localStorage.setItem('GLOBAL_COMPANY_ID', String(this.selectedCompanyId));
            else if (this.loggedInUserRoleName == 'MedCon Admin') {
                this.selectedCompanyId = 1;
                this.selectCompany = "Medcon";//this.allCompanyList[0].companyName;
                localStorage.setItem('GLOBAL_COMPANY_ID', String(this.selectedCompanyId));
                localStorage.setItem('GLOBAL_COMPANY_NAME', String(this.selectCompany));
            }

        }
        else 
        {
           
            this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
            
            this.selectCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        }
       

	}

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-user-menu') {
			this.userMenuExtended = false;
		}
    }

    onChange(selectedValue) {
        this.selectedCompanyId = Number(selectedValue);
        localStorage.setItem('GLOBAL_COMPANY_ID', String(this.selectedCompanyId));
        this.performCompanyWiseNavigation(this.selectedCompanyId);
        
        if (this.allCompanyList != null) {
            for (var i = 0; i < this.allCompanyList.length; i++) {
                if (this.allCompanyList[i].companyId == this.selectedCompanyId) {
                    this.selectCompany = this.allCompanyList[i].companyName;
                }
            }

        }
        
        localStorage.setItem('GLOBAL_COMPANY_NAME', String(this.selectCompany));
        
        
    }

    public ngAfterViewInit(): void {
        
        
        if (this.privilegesList1 != null) {
            for (let i = 0; i < this.privilegesList1.length; i++) {
                //alert(this.privilegesList1[0].status);
                let moduleName = this.privilegesList1[i].moduleName;
                let add = this.privilegesList1[i].add;
                let status = (this.privilegesList1[i].status == true && this.privilegesList1[i].view==true)?true:false;
               
                if (moduleName == "Dashboard") {
                    
                    this.isDataReportsHasAccess = status;
                    this.isOverviewMenuVisible = status;
                    this.isDashBoardHasAccess = status;
                }

                if (moduleName == "Reports") {

                    this.isDataReportsHasAccess = status;
                    this.isReportingMenuVisible = status;
                }

               

                if (moduleName == "Trials") {

                    this.isTrialsHasAccess = status;
                    this.isClinicalTrialsMenuVisible = status;
                }

                if (moduleName == "Trial Groups") {

                    this.isTrialGroupHasAccess = status;
                    this.isClinicalTrialsMenuVisible = status;
                }

                if (moduleName == "Notification") {

                    this.isNotificationHasAccess = status;
                    this.isClinicalTrialsMenuVisible = status;
                }

                if (moduleName == "Manage Users") {

                    this.isManageUserHasAccess = status;
                    this.isUserManagementMenuVisible = status;
                }


                if (moduleName == "Manage Medcon Users") {

                    this.isManageMedconUserHasAccess = status;
                    this.isUserManagementMenuVisible = status;
                }

                if (moduleName == "Privileges" && add=="1" ) {

                    this.privileges = status;
                    this.isUserManagementMenuVisible = status;
                    this.isPrivilegesMenuHasAccess = status;
                }

                if (moduleName == "Manage Company") {

                    this.isManageCompanyHasAccess = status;
                   
                }

                if (moduleName == "Labels") {

                    this.isLabelsHasAccess = status;
                   
                }
                
                if (moduleName == "Manage Sites") {

                    this.isManageSitesHasAccess = status;
                    
                }

                if (moduleName == "Manage Drugs") {

                    this.isManageDrugHasAccess = status;
                    
                }

                if (moduleName == "Manage Regimen") {

                    this.isManageRegimenHasAccess = status;
                    
                }

                if (moduleName == "Patient Alerts") {

                    this.isPatientAlertHasAccess = status;
                   
                }

                if (moduleName == "Schedules") {

                    this.isScheduleHasAccess = status;
                    
                }

                if (moduleName == "Import Patient" && add == "1") {

                    this.isImportPatientHasAccess = status;
                    
                }

                if (moduleName == "Broadcast Messages") {

                    this.isBroadcastMessagesHasAccess = status;
                    
                }

                if (moduleName == "Settings") {

                    this.isSettingsHasAccess = status;
                    
                }

                if (moduleName == "Measurement") {

                    this.isMeasurementHasAccess = status;
                    
                }

                if (moduleName == "Export") {

                    this.isExportMenuHasAccess = status;
                    
                }

                if (this.isManageCompanyHasAccess == true || this.isLabelsHasAccess == true || this.isManageSitesHasAccess == true
                    || this.isManageDrugHasAccess == true || this.isManageRegimenHasAccess == true || this.isImportPatientHasAccess == true
                    || this.isBroadcastMessagesHasAccess == true || this.isMeasurementHasAccess == true ||
                    this.isSettingsHasAccess == true || this.isExportMenuHasAccess==true
                 )
                {
                   
                    this.isAdministrationMenuVisible = true;
                }

                if (this.isTrialsHasAccess == false && this.isTrialGroupHasAccess == false && this.isNotificationHasAccess == false)
                {
                    this.isClinicalTrialsMenuVisible = false;
                }

                if (this.isManageUserHasAccess == false && this.isPrivilegesMenuHasAccess==false) {
                    this.isUserManagementMenuVisible = false;
                }
            }
        }



        
    }

    public performCompanyWiseNavigationOld(companyId)
    {
       
        if (this.router.url.indexOf("/dashboard") != -1)
        {
            this.router.navigate(['/dashboard']);

        }
        else if (this.router.url.indexOf("/reports") != -1) {
            this.router.navigate(['/reports']);

        }
        else if (this.router.url.indexOf("/patient-report") != -1) {
            this.router.navigate(['/patient-report']);

        }
        else if (this.router.url.indexOf("/trials") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/trials', '');
        }
        else if (this.router.url.indexOf("/trialgroup") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/trialgroup', '');
        }
        else if (this.router.url.indexOf("/notifications") != -1) {
           
            this.url.pushState(null, null, '/' + companyId + '/notifications', '');
        }
        else if (this.router.url.indexOf("/users") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/users', '');


        }
        else if (this.router.url.indexOf("/privileges") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/privileges', '');
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId!=1 ) {
           
            this.url.pushState(null, null, '/customers/' + companyId + '/view', '');
            
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId == 1) {
           
            this.url.pushState(null, null, '/' + companyId + '/company', '');
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId == 1) {
            
            this.url.pushState(null, null, '/' + companyId + '/company', '');
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId != 1) {

            this.url.pushState(null, null, '/customers/' + companyId + '/view', '');
        }
        else if (this.router.url.indexOf("/labels-committed") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/labels-committed', '');
        }
        else if (this.router.url.indexOf("/sites") != -1) {
           
            this.url.pushState(null, null, '/' + companyId + '/sites', '');
        }
        else if (this.router.url.indexOf("/drugs") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/drugs', '');
        }
        else if (this.router.url.indexOf("/regimens") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/regimens', '');
        }
        else if (this.router.url.indexOf("/import-patient") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/import-patient', '');
        }
        else if (this.router.url.indexOf("/broadcast-Messages") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/broadcast-Messages', '');
        }
        else if (this.router.url.indexOf("/measurement") != -1) {
           
            this.url.pushState(null, null, '/' + companyId + '/measurement', '');
        }
        else if (this.router.url.indexOf("/settings") != -1) {
           
            this.url.pushState(null, null, '/' + companyId + '/settings', '');
        }
        else if (this.router.url.indexOf("/export") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/export', '');
        }


        location.reload();

    }


    public performCompanyWiseNavigation(companyId)
    {
        if (this.router.url.indexOf("/dashboard") != -1) {
            
            this.onRefresh('', 'dashboard');

        }
        else if (this.router.url.indexOf("/reports") != -1) {
            
            this.onRefresh('', 'reports');

        }
        else if (this.router.url.indexOf("/patient-report") != -1) {
           
            this.onRefresh('', 'patient-report');

        }
        else if (this.router.url.indexOf("/Label-Report") != -1) {
            
            this.onRefresh('', 'Label-Report');

        }
        else if (this.router.url.indexOf("/titration-Report") != -1) {
            
            this.onRefresh('', 'titration-Report');

        }
        else if (this.router.url.indexOf("/trials") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1 || this.router.url.indexOf("/view") != -1)) {
            this.router.navigate(['/', companyId, 'trials']);
           
        }
        else if (this.router.url.indexOf("/trials") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1 || this.router.url.indexOf("/view") == -1)) {
            
            this.onRefresh(companyId, 'trials');
        }
        else if (this.router.url.indexOf("/trialgroup") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'trialgroup']);
            
        }
        else if (this.router.url.indexOf("/trialgroup") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
           
            this.onRefresh(companyId, 'trialgroup');
        }
        else if (this.router.url.indexOf("/notifications") != -1) {
           
            this.onRefresh(companyId, 'notifications');
        }
        else if (this.router.url.indexOf("/users") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
           
            this.router.navigate(['/', companyId, 'users']);
           


        }
        else if (this.router.url.indexOf("/users") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            
            this.onRefresh(companyId, 'users');

        }
        else if (this.router.url.indexOf("/privileges") != -1) {
            this.router.navigate(['/', companyId, 'privileges']);
            
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId != 1) {
            
            this.router.navigate(['/customers', companyId, 'view']);
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId == 1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'company']);
           
        }
        else if (this.router.url.indexOf("/company") != -1 && companyId == 1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
           
            this.onRefresh(companyId, 'company');
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId == 1) {

           
            this.router.navigate(['/', companyId, 'company']);
        }
        else if (this.router.url.indexOf("/customers") != -1 && companyId != 1) {
           
            this.url.pushState(null, null, '/customers/' + companyId + '/view', '');
            location.reload();
            
        }
        else if (this.router.url.indexOf("/labels-committed") != -1) {
            
            this.onRefresh(companyId, 'labels-committed');
        }
        else if (this.router.url.indexOf("/sites") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'sites']);
            
        }
        else if (this.router.url.indexOf("/sites") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            
            this.onRefresh(companyId, 'sites');
        }
        else if (this.router.url.indexOf("/drugs") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1)) {
            this.router.navigate(['/', companyId, 'drugs']);
            
        }
        else if (this.router.url.indexOf("/drugs") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1)) {
            
            this.onRefresh(companyId, 'drugs');
        }
        else if (this.router.url.indexOf("/regimens") != -1 && (this.router.url.indexOf("/edit") != -1 || this.router.url.indexOf("/new") != -1 || this.router.url.indexOf("/view") != -1)) {
            this.router.navigate(['/', companyId, 'regimens']);
           
        }
        else if (this.router.url.indexOf("/regimens") != -1 && (this.router.url.indexOf("/edit") == -1 || this.router.url.indexOf("/new") == -1 || this.router.url.indexOf("/view") == -1)) {
            
            this.onRefresh(companyId, 'regimens');
        }
        else if (this.router.url.indexOf("/import-patient") != -1) {
           
            this.onRefresh(companyId, 'import-patient');
        }
        else if (this.router.url.indexOf("/broadcast-Messages") != -1) {
            
            this.onRefresh(companyId, 'broadcast-Messages');
        }
        else if (this.router.url.indexOf("/measurement") != -1) {
            
            this.onRefresh(companyId, 'measurement');
        }
        else if (this.router.url.indexOf("/settings") != -1) {
            
            this.url.pushState(null, null, '/' + companyId + '/settings', '');
            
            location.reload();
        }
        else if (this.router.url.indexOf("/export") != -1) {
            
            this.onRefresh(companyId,'export');
        }
        else if (this.router.url.indexOf("/patients/new") != -1) {
            
            this.onRefresh(companyId, 'trials');
        }

    }

    onRefresh_Old() {
  this.router.routeReuseStrategy.shouldReuseRoute = function(){return false;};

  let currentUrl = this.router.url + '?';

  this.router.navigateByUrl(currentUrl)
    .then(() => {
      this.router.navigated = false;
      this.router.navigate([this.router.url]);
    });
    }

    //10th July 2018
    onRefresh(companyId,viewName) {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url + '?';

        this.router.navigateByUrl(currentUrl)
            .then(() => {
                this.router.navigated = false;
                if (companyId!='')
                    this.router.navigate(['/', companyId, viewName]);
                else
                    this.router.navigate(['/' + viewName]);
            });
    }

    //end 10th july 2018

    //26th June 2018 

    navigateToMenuItem(menuItem)
    {
        
        
        if (this.router.url.indexOf("/" + menuItem) == -1)
        {
            
            if (!$('#datatable_processing').is(':visible')) {
                this.isLoading = true;
            }
            
            this.router.navigate(['/', this.selectedCompanyId, menuItem]);
            
        }
        else
        {
            if (!$('#datatable_processing').is(':visible')) {
                this.isLoading = true;
            }
            this.onRefresh(this.selectedCompanyId, menuItem);
        }

        
        
    }
    navigateToCompanyView(menuItem) {
        if (this.router.url.indexOf("/" + menuItem) == -1) {

            this.isLoading = true;
            this.router.navigate(['/customers', this.selectedCompanyId, 'view']);

        }

    }

    navigateToReportMenuItem(menuItem) {
        if (this.router.url.indexOf("/" + menuItem) == -1) {

            if (!$('#datatable_processing').is(':visible')) {
                this.isLoading = true;
            }
            this.router.navigate(['/', menuItem]);

        }
    }

    //12th July 2018
    redirectToDashBoard()
    {

        if (this.loggedInUserRoleName != 'Label User') //to do not display dashboard for label user
        {
            this.isLoading = true;
            this.router.navigate(['/dashboard']);

        }

    }

    //End

    
}
