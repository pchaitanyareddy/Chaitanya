// Angular
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http, XHRBackend, RequestOptions } from '@angular/http';
import { NgModule, ApplicationRef } from '@angular/core';
import { removeNgStyles, createNewHosts, createInputTransfer } from '@angularclass/hmr';
import { RouterModule } from '@angular/router';
// Template
import { TemplateNavigationComponent } from './template/template-navigation.component';
// Components
import { LoginComponent } from './routes/login/login.component';
import { DashboardComponent } from './routes/dashboard/dashboard.component';
import { DataReportsComponent } from './routes/reports/data-reports.component';
import { PrivilegesComponent } from './routes/privileges/privileges-list.component';
import { PatientReportComponent } from './routes/patient-report/patient-report.component';
import { ImportPatientComponent } from './routes/import-patient/import-patient.component';
import { TrialGroupListComponent } from './routes/trialgroup/trialgroup-list.component';
import { TrialGroupNewComponent } from './routes/trialgroup/trialgroup-new.component';
import { TrialGroupEditComponent } from './routes/trialgroup/trialgroup-edit.component';
import { CompanyListComponent } from './routes/company/company-list.component';
import { CompanyNewComponent } from './routes/company/company-new.component';
import { CompanyEditComponent } from './routes/company/company-edit.component';
import { LabelsCommittedComponent } from './routes/labels-committed/labels-committed.component';
import { MeasurementListComponent } from './routes/measurement/measure-list.component';
import { MeasurementNewComponent } from './routes/measurement/measure-new.component';
import { MeasurementEditComponent } from './routes/measurement/measure-edit.component';
import { BroadcastMessagesListComponent } from './routes/broadcast-Messages/broadcast-Messages-list.component';
import { NotificationsListComponent } from './routes/notifications/notifications-list.component';
import { NotificationsNewComponent } from './routes/notifications/notifications-new.component';
import { NotificationsEditComponent } from './routes/notifications/notifications-edit.component';
import { SettingsListComponent } from './routes/settings/settings-list.component';
import { ExportListComponent } from './routes/export/export-list.component';
import { LabelReportComponent } from './routes/Label-Report/labelReport.component';
import { TitrationReportComponent } from './routes/titration-Report/titrationReport.component';
import { BroadcastMessagesNewComponent } from './routes/broadcast-Messages/broadcast-Message-new.component';
import { BroadcastMessagesEditComponent } from './routes/broadcast-Messages/broadcast-Message-edit.component';
import {
	WidgetDailyTrackComponent,
	WidgetWeeklyTrackComponent,
	WidgetMonthlyTrackComponent,
	WidgetDosageHistoryComponent,
	WidgetDosageAdherenceComponent,
	WidgetDailyDosesLoggedComponent,
	WidgetWeeklyDosesLoggedComponent,
	WidgetMonthlyDosesLoggedComponent,
	WidgetDailyPncComponent,
	WidgetWeeklyPncComponent,
	WidgetMonthlyPncComponent,
	WidgetDailyAdherenceInfoComponent,
	WidgetWeeklyAdherenceInfoComponent,
	WidgetMonthlyAdherenceInfoComponent
} from './routes/dashboard/widgets';
import {
	//CustomersListComponent,
	//CustomerNewComponent,
	//CustomerEditComponent,
	CustomerViewComponent
} from './routes/customers';
import { SiteNewComponent, SiteListComponent, SiteEditComponent } from './routes/sites';
import {
	TrialsListComponent,
	TrialNewComponent,
	TrialEditComponent,
	TrialViewComponent
} from './routes/trials';
import {
	UsersListComponent,
	UserEditComponent,
    UserNewComponent
 //   ,
	//MedConUsersListComponent,
	//MedConUserNewComponent,
	//MedConUserEditComponent
} from './routes/users';
import { PatientNewComponent } from './routes/patients';
import { DrugsListComponent, DrugNewComponent, DrugEditComponent } from './routes/drugs';
import { RegimenListComponent, RegimenNewComponent, RegimenEditComponent } from './routes/regimen';
import { AlertsAlarmsComponent } from './routes/alerts-alarms/alerts-alarms-list.component';

import { PageNotFoundComponent } from './routes/errors/page-not-found.component';
// Directives
import { ClickStopPropagationDirective } from './directives/click-stop-propagation.directive';
// Guards
import { PendingChangesGuard } from './guards/pending-changes.guard';
// Services
import { AuthGuard } from './guards/auth.guard';
import { UserLoginService, UserParametersService, CognitoUtil } from './services/cognito/cognito.service';
import { AwsUtil } from './services/aws.service';
import { EmitterService } from './emitter.service';
import { CurrentUserService } from './services/currentuser.service';
import { TemplateService } from './services/template.service';
import { DashboardService } from './services/dashboard.service';
import { CustomerService } from './services/customer.service';
import { SiteService } from './services/site.service';
import { LabelService } from './services/label.service';
import { TrialService } from './services/trial.service';
import { UserService } from './services/user.service';
import { PatientService } from './services/patient.service';
import { DoseService } from './services/dose.service';
import { DrugService } from './services/drug.service';
import { RegimenService } from './services/regimen.service';
import { AlertAlarmService } from './services/alert-alarms.service';
import { SettingsService } from './services/settings.service';
import { ReportService } from './services/report.service';
import { PrivilegesService } from './services/privileges.service';
import { PatientReportService } from './services/patient-report.service';
import { TrialGroupService } from './services/trialgroup.service';
import { CompanyService } from './services/company.service';
import { MeasureService } from './services/measure.service';
import { BroadcastMessagesService } from './services/broadcastMessages.service';
import { NotificationsService } from './services/notifications.service';
import { ExportService } from './services/export.service';
// Bootstrap for Angular
import {
	TabsModule,
	ProgressbarModule,
	ButtonsModule,
	PopoverModule,
	TypeaheadModule,
	AlertModule,
	ModalModule,
	PaginationModule
} from 'ngx-bootstrap';
import { ChartsModule } from 'ng2-charts';
import { MyDatePickerModule } from 'mydatepicker';
/*
 * Platform and Environment providers/directives/pipes
 */
import { ENV_PROVIDERS } from './environment';
import { ROUTES } from './app.routes';
// App is our top level component
import { AppComponent } from './app.component';
import { APP_RESOLVER_PROVIDERS } from './app.resolver';
import { AppState, InternalStateType } from './app.service';
import { HomeComponent } from './home';
import { AboutComponent } from './about';
import { NoContentComponent } from './no-content';
import { XLargeDirective } from './home/x-large';
import '../styles/custom.scss';
import { HttpService } from './services/http.service';
import { DynamicFormQuestionComponent } from './template/dynamic-form-question.component';
import { PipeModule } from './pipes/pipe.module';

export function httpFactory(xhrBackend: XHRBackend, requestOptions: RequestOptions,
	cognito: CognitoUtil): Http {
	return new HttpService(xhrBackend, requestOptions, cognito);
}

// Application wide providers
const APP_PROVIDERS = [
	...APP_RESOLVER_PROVIDERS,
	AppState,

	EmitterService,
	CognitoUtil,
	AwsUtil,
	UserLoginService,
	UserParametersService,
	AuthGuard,
	PendingChangesGuard,
	CurrentUserService,
	TemplateService,
	DashboardService,
	CustomerService,
	SiteService,
	LabelService,
	TrialService,
	UserService,
	PatientService,
	DoseService,
	DrugService,
	RegimenService,
	AlertAlarmService,
	SettingsService,
	ReportService,
	{
		provide: Http,
		useFactory: httpFactory,
		deps: [XHRBackend, RequestOptions, CognitoUtil]
    },
    PrivilegesService,
    PatientReportService,
    TrialGroupService,
    CompanyService,
    MeasureService,
    BroadcastMessagesService,
    NotificationsService,
    ExportService
];

type StoreType = {
	state: InternalStateType,
	restoreInputValues: () => void,
	disposeOldHosts: () => void
};

/**
 * `AppModule` is the main entry point into Angular2's bootstraping process
 */
@NgModule({
	bootstrap: [AppComponent],
	declarations: [
		AppComponent,
		TemplateNavigationComponent,
		LoginComponent,
		DashboardComponent,
		DataReportsComponent,
		WidgetDailyTrackComponent,
		WidgetWeeklyTrackComponent,
		WidgetMonthlyTrackComponent,
		WidgetDosageHistoryComponent,
		WidgetDosageAdherenceComponent,
		WidgetDailyDosesLoggedComponent,
		WidgetWeeklyDosesLoggedComponent,
		WidgetMonthlyDosesLoggedComponent,
		WidgetDailyPncComponent,
		WidgetWeeklyPncComponent,
		WidgetMonthlyPncComponent,
		WidgetDailyAdherenceInfoComponent,
		WidgetWeeklyAdherenceInfoComponent,
		WidgetMonthlyAdherenceInfoComponent,
		//CustomersListComponent,
		//CustomerNewComponent,
		//CustomerEditComponent,
		CustomerViewComponent,
		SiteNewComponent,
        SiteEditComponent,
        SiteListComponent,
		TrialsListComponent,
		TrialNewComponent,
		TrialEditComponent,
		TrialViewComponent,
		UsersListComponent,
		UserEditComponent,
		UserNewComponent,
		//MedConUsersListComponent,
		//MedConUserNewComponent,
		//MedConUserEditComponent,
		PatientNewComponent,
		
		DrugsListComponent,
		DrugNewComponent,
		DrugEditComponent,
		RegimenListComponent,
		RegimenNewComponent,
		RegimenEditComponent,
		AlertsAlarmsComponent,
        SettingsListComponent,
        
		PageNotFoundComponent,
		DynamicFormQuestionComponent,
        ClickStopPropagationDirective,
        PrivilegesComponent,
        PatientReportComponent,
        ImportPatientComponent,
        TrialGroupListComponent,
        TrialGroupNewComponent,
        TrialGroupEditComponent,
        CompanyListComponent,
        CompanyNewComponent,
        CompanyEditComponent,
        LabelsCommittedComponent,
        MeasurementListComponent,
        MeasurementEditComponent,
        BroadcastMessagesListComponent,
        NotificationsListComponent,
        NotificationsNewComponent,
        NotificationsEditComponent,
        ExportListComponent,
        LabelReportComponent,
        TitrationReportComponent,
        MeasurementNewComponent,
        BroadcastMessagesNewComponent,
        BroadcastMessagesEditComponent
	],
	imports: [ // import Angular's modules
		BrowserModule,
		FormsModule,
		ReactiveFormsModule,
		HttpModule,
		ProgressbarModule.forRoot(),
		TabsModule.forRoot(),
		ButtonsModule.forRoot(),
		PopoverModule.forRoot(),
		TypeaheadModule.forRoot(),
		AlertModule.forRoot(),
		ModalModule.forRoot(),
		PaginationModule.forRoot(),
		ChartsModule,
		MyDatePickerModule,
        RouterModule.forRoot(ROUTES, { useHash: true }),
        //RouterModule.forRoot(routes, { onSameUrlNavigation: �reload� })]
		PipeModule.forRoot()
	],
	providers: [ // expose our Services and Providers into Angular's dependency injection
		ENV_PROVIDERS,
		APP_PROVIDERS
	]
})
export class AppModule {

	constructor(public appRef: ApplicationRef,
		public appState: AppState) {
	}

	public hmrOnInit(store: StoreType) {
		if (!store || !store.state) {
			return;
		}
		console.log('HMR store', JSON.stringify(store, null, 2));
		// set state
		this.appState._state = store.state;
		// set input values
		if ('restoreInputValues' in store) {
			let restoreInputValues = store.restoreInputValues;
			setTimeout(restoreInputValues);
		}

		this.appRef.tick();
		delete store.state;
		delete store.restoreInputValues;
	}

	public hmrOnDestroy(store: StoreType) {
		const cmpLocation = this.appRef.components.map((cmp) => cmp.location.nativeElement);
		// save state
		const state = this.appState._state;
		store.state = state;
		// recreate root elements
		store.disposeOldHosts = createNewHosts(cmpLocation);
		// save input values
		store.restoreInputValues = createInputTransfer();
		// remove styles
		removeNgStyles();
	}

	public hmrAfterDestroy(store: StoreType) {
		// display new elements
		store.disposeOldHosts();
		delete store.disposeOldHosts;
	}

}
