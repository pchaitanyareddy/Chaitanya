﻿import { Component, OnInit, ViewChild, ChangeDetectorRef, Compiler } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { MeasureService } from '../../services/measure.service';
import { Customer } from '../../models/customer';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Measurement } from '../../models/measurement';
import { UserRole } from '../../models/userrole';
import { Pagination } from '../../models/pagination';
import { Router, ActivatedRoute } from '@angular/router';
import { MeasureRequest } from '../../requests/measure-request';
import { MeasureDeleteRequest } from '../../requests/measureDelete-request';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { DrugService } from '../../services/drug.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');

@Component({
    templateUrl: './measure-new.component.html?v=${new Date().getTime()}',
    styleUrls: ['./drugs-list.component.scss']
})

export class MeasurementNewComponent implements OnInit {
    public form: FormGroup;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public Measurements: Pagination<Measurement>;
    public measure: FormGroup;
    public userId: number;
    public showErrors: boolean;
    public UserRole: typeof UserRole = UserRole;
    public drugToDelete: any;
    public successMessage: string;
    public errorMessage: string;
    public measurementId: number;
    public measureDelete: number;
    public customer: Customer;
    public sort = { field: 'name', order: 'desc' };
    public maxSize: number = 5;
    public currentPage: number = 1;
    measurementList: any;
    selectedCompanyId: number;
    isEditForm: boolean;
    public drugImage = 'assets/images/medication-type-default.png';
    public drugImageBase64: string;
    isLoading: boolean;
    selectedMedicationType: string;
    selectedUnitOfMeasure: string;
    selectedMedicationTypeName: string;
    public allmedicationTypeList: any;
    public allmedicationTypeFilteredList: any;
    
    public selectedMedicationTypeId: number;
    public distinctMedicationTypesList: any;
    constructor(public templateService: TemplateService,
        private measureService: MeasureService,
        public router: Router,
        private route: ActivatedRoute,
        private cognitoUtil: CognitoUtil,

        private fb: FormBuilder,
        private drugService: DrugService,
        private changeDetectorRef: ChangeDetectorRef,
        private reportService: ReportService,
        private url: LocationStrategy,
        private _compiler: Compiler
    ) {
    }

    public ngOnInit(): void {
        this._compiler.clearCache();
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.Measurements = this.route.snapshot.data['Measurements'];
        this.userId = this.route.snapshot.params['customer_id'];
        this.selectedMedicationTypeName = 'Tablet';
        this.measure = this.fb.group({
            medicationTypeName: [this.selectedMedicationTypeName, [Validators.required]],
            image: [''],
            unitOfMeasure: ['', Validators.required]
        });

        
        
        
        this.allmedicationTypeFilteredList = ['MG'];

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }


        
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Measurement')

        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        
        this.selectedCompanyId = localStorage.getItem("GLOBAL_COMPANY_ID");

    }

   
    loadDrugImage(selectedImage) {
       

        if (selectedImage == null || selectedImage == '')
            this.drugImage = 'assets/images/medication-type-default.png';
        else {
            this.drugImage = CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage;
            this.IsValidImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage, "newDrugImageId");
            this.drugImageBase64 = selectedImage;
        }
        

    }
    public ngAfterViewInit(): void {
        this.drugImageBase64 = "";
        

        
        this.drugService.getAllMedicationType((localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allmedicationTypeList = response;
                //To get the distinct medication type names
                var lookup = {};
                var items = response;
                var result = [];

                for (var item, i = 0; item = items[i++];) {
                    var name = item.name;

                    if (!(name in lookup)) {
                        lookup[name] = 1;
                        result.push(item);
                    }
                }
                this.distinctMedicationTypesList = result;
               //End To get the distinct medication type names

                if (this.allmedicationTypeList != undefined)
                    this.loadDrugImage(this.allmedicationTypeList[0].image);
            },
            (err) => {
                this.errorMessage = err;

            });

    }


    public onSubmit(): void {
        var unitOfMeasure = this.measure.value.unitOfMeasure.trim();
        if (this.measure.invalid) {
            this.showErrors = true;
            

        }
        else if (unitOfMeasure == '') {
            this.errorMessage = "Please enter valid  unit of measure"
            this.measure.controls['unitOfMeasure'].setValue('');
            $(window).scrollTop(5);
        }
        else {
            this.isLoading = true;
            this.selectedMedicationType = (this.selectedMedicationType == null) ? 'Tablet' : this.selectedMedicationType;
            //Update measurment into db

            
                let request = new MeasureRequest(
                    
                    this.selectedMedicationType,
                    unitOfMeasure,
                    this.drugImageBase64, //uncomment when API is ready
                    Number(this.userId)
                );
                this.measureService.createMeasure(request).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.measure.markAsPristine();
                        this.successMessage = "successfully Added ";
                        $(window).scrollTop(5);
                       
                        $("#datatable").dataTable().fnDestroy();
                        
                        this.back();
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });
                



            


        }

    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.measureService
            .getMeasure(this.measurementId, event.page, event.itemsPerPage)
            .subscribe((Measurements) => this.Measurements = Measurements);
    }

    public sortResults(field): void {
        let oppositeSort = (this.sort.order === 'asc') ? 'desc' : 'asc';
        let order = (this.sort.field === field) ? oppositeSort : 'asc';
        this.sort = { field, order };

        this.measureService.getMeasure(this.measurementId, null, null, field, order)
            .subscribe((Measurements) => this.Measurements = Measurements);
    }
    public editAndPopulateFormValues(measureObject) {
        this.isEditForm = true;
        this.measure = this.fb.group({
            medicationType: ['Tablet', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            unitOfMeasure: ['MG', Validators.required]
        });
    }
    public back(): void {
        this.isLoading = true;
        
        this.router.navigate(['/', this.selectedCompanyId, 'measurement']);
    }

    public goBack(): void {
        this.measure.markAsPristine();
        this.measure.value.medicationTypeName = '',
            this.measure.value.UnitOfMeasure = '',
            this.router.navigate([]);
    }

    
    public deleteItem(id): void {
        
        this.measureDelete = id;
        this.deleteModal.show();
    }
    public hideDeleteModal(): void {

        this.deleteModal.hide();
    }

    public confirmDelete(): void {

        
        let status = false;
        let request = new MeasureDeleteRequest(
            status,
            Number(this.userId)
        );
        this.measureService.deleteMeasurement(this.measureDelete, request)
            .subscribe(
            (response) => {

                this.successMessage = "Successfully deleted Measurement";
                this.hideDeleteModal();
                $(window).scrollTop(5);
                $("#datatable").dataTable().fnDestroy();
               

            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public fileChange(input) {
        this.processImage(input.target.files);
    }

    private processImage(files, index = 0) {
        let reader = new FileReader();

        if (index in files) {
            this.readFile(files[index], reader, (result) => {
                // Create an img element and add the image file data to it
                let img = document.createElement('img');
                img.src = result;

                // Send this img to the resize function (and wait for callback)
                this.measureService.resizeImage(img, (croppedImage) => {

                    // This is the file you want to upload.
                    // Either as a base64 string or img.src = croppedImage if you prefer a file.
                    this.drugImage = croppedImage;
                    this.drugImageBase64 = croppedImage;
                });
            });
        } else {
            // When all files are done this forces a change detection
            this.changeDetectorRef.detectChanges();
        }
    }

    private readFile(file, reader, callback) {
        reader.onload = () => {
            callback(reader.result);
        };

        reader.readAsDataURL(file);
    }

    clearData() {

       this.measure.reset();       
       this.ngOnInit();
       this.ngAfterViewInit();
    }

    IsValidImageUrl(url, imageId): boolean {
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            
            flag = true;
        }).on("error ", function () {
            
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            flag = false;

        });
        return flag;

    }






    testImage(url, callback, timeout) {
        alert('Entered')

        timeout = timeout || 5000;
        var timedOut = false, timer;
        var img = new Image();
        img.onerror = img.onabort = function () {
            if (!timedOut) {
                clearTimeout(timer);
                callback(url, "error");
                alert('Error file');
            }
        };
        img.onload = function () {
            if (!timedOut) {
                clearTimeout(timer);
                callback(url, "success");
                alert('sucess');
            }
        };
        img.src = url;
        timer = setTimeout(function () {
            timedOut = true;
            callback(url, "timeout");
        }, timeout);
    }


    record(url, result): string {
        alert(result);
        
        return result;
    }
   
    onChange_MedicationType(selectedValue) {

        
        let selectedImage = '';
        
        this.selectedMedicationTypeName = selectedValue
        this.selectedMedicationType = null;

        if (this.allmedicationTypeList != null) {
            for (var i = 0; i < this.allmedicationTypeList.length; i++) {
                if (this.allmedicationTypeList[i].name == this.selectedMedicationTypeName) {
                    this.selectedMedicationType = this.allmedicationTypeList[i].name;
                   
                    selectedImage = this.allmedicationTypeList[i].image;
                    break;
                    
                }
            }

            this.allmedicationTypeFilteredList = this.allmedicationTypeList.filter(
                medtypes => medtypes.measure === this.selectedUnitOfMeasure);

            var unique = {};
            var distinct = [];
            this.allmedicationTypeFilteredList.forEach(function (x) {
                if (!unique[x.measure]) {
                    distinct.push(x.measure);
                    unique[x.measure] = true;
                }
            });
            
            this.allmedicationTypeFilteredList = distinct;
            
            this.loadDrugImage(selectedImage);
            
        }
    }


}
 

