﻿import { Component, OnInit, ViewChild, ChangeDetectorRef, Compiler } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { MeasureService } from '../../services/measure.service';
import { Customer } from '../../models/customer';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Measurement } from '../../models/measurement';
import { UserRole } from '../../models/userrole';
import { Pagination } from '../../models/pagination';
import { Router, ActivatedRoute } from '@angular/router';
import { MeasureRequest } from '../../requests/measure-request';
import { MeasureDeleteRequest } from '../../requests/measureDelete-request';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { DrugService } from '../../services/drug.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');

@Component({
    templateUrl: './measure-list.component.html?v=${new Date().getTime()}',
    styleUrls: ['./drugs-list.component.scss']
})

export class MeasurementListComponent implements OnInit {
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public Measurements: Pagination<Measurement>;
    public measure: FormGroup;
    public userId: number;
    public showErrors: boolean;
    public UserRole: typeof UserRole = UserRole;
    public drugToDelete: any;
    public successMessage: string;
    public errorMessage: string;
    public measurementId: number;
    public measureDelete: number;
    public customer: Customer;
    public sort = { field: 'name', order: 'desc' };
    public maxSize: number = 5;
    public currentPage: number = 1;
    measurementList: any;
    isEditForm: boolean;
    public drugImage = 'assets/images/medication-type-default.png';
    public drugImageBase64: string;
    isLoading: boolean;
    selectedMedicationType: string;
    selectedUnitOfMeasure: string;
    selectedCompanyId: number;
    errorMessage_DtableError: string;
    errorCount: number;
    endTime: number;
    constructor(public templateService: TemplateService,
        private measureService: MeasureService,
        public router: Router,
        private route: ActivatedRoute,
        private cognitoUtil: CognitoUtil,
        private fb: FormBuilder,
        private drugService: DrugService,
        private changeDetectorRef: ChangeDetectorRef,
        private reportService: ReportService,
        private url: LocationStrategy,
        private _compiler: Compiler
    ) {
    }

    public ngOnInit(): void {
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.endTime = this.reportService.getTokenEndTime();
        this.errorCount = 0;
        this._compiler.clearCache();
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.Measurements = this.route.snapshot.data['Measurements'];
        this.userId = this.route.snapshot.params['customer_id'];
        this.measure = this.fb.group({
            medicationTypeName: ['', [Validators.required]],
            image: [''],
            unitOfMeasure: ['', Validators.required]
        });


        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }


        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Measurement')

        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        
        this.selectedCompanyId = Number(localStorage.getItem("GLOBAL_COMPANY_ID"));
    }

    measurementReload() {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            this.errorMessage_DtableError = "Company is changed so page is refreshing..."
            this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/measurement', '');
            location.reload();

        }

    }

    public ngAfterViewInit(): void {
        this.drugImageBase64 = "";
        

        this.loadMeasurementList();
    }



    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.measureService
            .getMeasure(this.measurementId, event.page, event.itemsPerPage)
            .subscribe((Measurements) => this.Measurements = Measurements);
    }

    public sortResults(field): void {
        let oppositeSort = (this.sort.order === 'asc') ? 'desc' : 'asc';
        let order = (this.sort.field === field) ? oppositeSort : 'asc';
        this.sort = { field, order };

        this.measureService.getMeasure(this.measurementId, null, null, field, order)
            .subscribe((Measurements) => this.Measurements = Measurements);
    }
    public editAndPopulateFormValues(measureObject) {
        
        this.isEditForm = true;
        this.measure = this.fb.group({
            medicationType: ['Tablet', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            unitOfMeasure: ['MG', Validators.required]
        });
    }

    public goBack(): void {
        this.measure.markAsPristine();
        this.measure.value.medicationTypeName = '',
            this.measure.value.UnitOfMeasure = '',
            this.router.navigate([]);
    }

    performDataTableRefresh() {
        this.reportService.isTokenExpired(this.endTime,'MeasurementList');
        if (localStorage.getItem("MeasurementList_IS_TOKEN_EXPIRED") == 'Y') {
            //alert('Expired');
            localStorage.setItem("MeasurementList_IS_TOKEN_EXPIRED", "N");
            this.endTime = this.reportService.getTokenEndTime();
            this.reportService.isTokenExpired(this.endTime, 'MeasurementList');
            $(window).scrollTop(5);
            this.errorMessage_DtableError = "Refreshing page...";
            $("#pnlAlertWarning").css("display", "block");
            setTimeout(function () {
                $('#pnlAlertWarning').fadeOut('fast');
            }, 3000);
            //alert('Refreshing page...');
            this.reportService.onRefresh(localStorage.getItem('GLOBAL_COMPANY_ID'), 'measurement');
            
        }

    }

    public loadMeasurementList(): void {
        $("#datatable_measurement").dataTable().fnDestroy();
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                
                $('#datatable_measurement')
                .on('order.dt', function () {

                    //self.performDataTableRefresh();

                })
                    .on('search.dt', function () {
                        //alert('search');
                        //self.performDataTableRefresh();
                    })
                    .on('page.dt', function () {

                        //self.performDataTableRefresh();

                    })
                    .DataTable({
                    "processing": true,
                    "serverSide": true,
                    "stateSave": true,
                    stateSaveParams: function (settings, data) {
                        delete data.search;
                        data.start = 0;
                    },
                    'ajax': {

                        
                        'url': CommonService.API_PATH_V2_LIST_ALL_MEASUREMENTS + 'measurement/list',
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        error: function (xhr, error, code) {
                            //self.errorCount = 1;
                            //if (localStorage.getItem("MEASURE_ERROR_COUNT") == undefined)
                            //    localStorage.setItem("MEASURE_ERROR_COUNT", String(self.errorCount));
                            //else if (localStorage.getItem("MEASURE_ERROR_COUNT") != undefined) {
                            //    self.errorCount = Number(localStorage.getItem("MEASURE_ERROR_COUNT")) + 1;

                            //}
                            //if (self.errorCount == 1 && (xhr.status == 0 || xhr.status == 401)) {
                            //    $(window).scrollTop(5);
                            //    self.errorMessage_DtableError = "Refreshing page...";
                            //    $("#pnlAlertWarning").css("display", "block");
                            //    setTimeout(function () {
                            //        $('#pnlAlertWarning').fadeOut('fast');
                            //    }, 3000);
                            //    //self.loadMeasurementList();
                            //    localStorage.setItem("MEASURE_ERROR_COUNT", undefined);
                            //    self.reportService.onRefresh(localStorage.getItem('GLOBAL_COMPANY_ID'), 'measurement');
                            //}
                            //else {

                            //    let errorMessage = '';
                            //    if (xhr.responseJSON != undefined)
                            //        errorMessage = xhr.responseJSON.message;
                            //    else
                            //        errorMessage = 'Server error occured';
                            //    self.errorMessage = errorMessage;
                            //    $('.dataTables_processing', $('#datatable_measurement').closest('.dataTables_wrapper')).hide();
                            //    localStorage.setItem("MEASURE_ERROR_COUNT", '0');
                            //}
                        }
                    }
                    
                    ,
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 4]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_LIST_ALL_MEASUREMENTS + 'measurement/list?draw=2&columns%5B0%5D%5Bdata%5D=trailGroupName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=createdBy&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=createdDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=id&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=trailCount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() + '&search%5Bregex%5D=false&_=1525343677314'
                                self.reportService.ExportAll(apiUrl, 'Measurment List');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 3]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "medicationType" },
                        { "data": "medicationMeasure" },
                        
                        { "data": "status" },
                       
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                localStorage.setItem('medicationMeasure', full.medicationMeasure);
                                localStorage.setItem('medicationType', full.medicationType);
                                localStorage.setItem('measurementId1', full.id);
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    
                                    if (full.status == 0 ) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Measurement this Measurement is deleted already\" disabled  id=\"" + full.id + ",editItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> <button title=\"Cannot Delete this Measurement this is already deleted\" disabled id=\"" + full.id + ",deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.drugCount > 0){
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Measurement this is Associated with Drug\" disabled  id=\"" + full.id + ",editItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> <button title=\"Cannot Delete this Measurement this is Associated with Drug\" disabled id=\"" + full.id + ",deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                  
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.id + ",editItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button><button  id=\"" + full.id + ",deleteItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Measurement this Measurement is deleted already\" disabled  id=\"" + full.id + ",editItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button></div>";
                                    }
                                    else if (full.drugCount > 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Measurement it is Associated with Drug\" disabled  id=\"" + full.id + ",editItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button></div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.id + ",editItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button></div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Delete this Measurement this is already deleted\" disabled id=\"" + full.id + ",deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.drugCount > 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Delete this Measurement this is Associated with Drug\" disabled id=\"" + full.id + ",deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.id + ",deleteItem" + "," + full.medicationType + "," + full.medicationMeasure + "," + full.bucketKey + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else {
                                    return "";
                                }
                            }
                        }

                    ]
                    ,
                    "columnDefs": [
                    
                        {
                            "targets": [2],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        },
                        {
                            "render": (data, type, full) => {
                                if (full.bucketKey != null) {

                                    
                                        
                                        return '<img id=' + full.id + '  src='+CommonService.MEDCON_V2_S3_BUCKET_URL + full.bucketKey + ' onerror=\"imgError(this);\" ></img><span>' + full.medicationType + '</span>';
                                    
                                }
                                else
                                    return '<img id=' + full.id +' src="../../../assets/images/medication-type-default.png"></img><span>' + full.medicationType + '</span>';
                            },
                            "targets": [0],
                            'searchable': false,
                        }
                        
                    ]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    }
                });

                $('#datatable_measurement').on('click', 'td button', function () {

                    var attId = $(this).attr('id');
                    var buttonId = attId.split(",")[0];
                    var buttonName = attId.split(",")[1];
                    var medicationType = attId.split(",")[2];
                    var medicationMeasure = attId.split(",")[3];
                    var drugBucketKey = attId.split(",")[4];
                   
                    var measurementId = buttonId;
                 localStorage.setItem('Measurement_Id', measurementId)
                 
                   
                 if (buttonName == "deleteItem") {
                     
                     this.selectedMedicationType = medicationType;
                     this.selectedUnitOfMeasure = medicationMeasure;
                     $("#divConfirmMessage").text('Are you sure you want to delete this measurement [ ' + medicationType + ' ] [ ' + medicationMeasure + ' ] ?');
                     self.deleteItem(measurementId);
                    }
                
                 if (buttonName == "editItem") {
                     
                        self.editMeasure(measurementId, medicationType, medicationMeasure, drugBucketKey);
                       
                    }

                });
            }
        });

    }
    public editMeasure(measurementId, medicationType, medicationMeasure, drugBucketKey): void {
        
       
        localStorage.setItem(measurementId + '_MEDICATION_TYPE', medicationType);
        localStorage.setItem(measurementId + '_MEDICATION_MEASURE', medicationMeasure);
        localStorage.setItem(measurementId + '_DRUGBUCKET_KEY', drugBucketKey);
        
        if (measurementId != 'undefined') {
            this.isLoading = true;
            this.router.navigate(['/', this.selectedCompanyId, 'measurement', measurementId, 'edit']);
        }

       
        $('#medicationTypeName').val(medicationMeasure);
        $('#unitOfMeasure').val(medicationType);
        $('#btnSubmit').text('Update Measurement');
       
      
    }

    public deleteItem(id): void {
       
        this.measureDelete = id;
        this.deleteModal.show();
    }
    public hideDeleteModal(): void {
       
        this.deleteModal.hide();
    }

    public confirmDelete(): void {

        
        let status = false;
        let request = new MeasureDeleteRequest(
            status,
            Number(this.userId)
        );
        this.measureService.deleteMeasurement(this.measureDelete, request)
            .subscribe(
            (response) => {
              
                this.successMessage = "Successfully deleted Measurement";
                this.hideDeleteModal();
                $(window).scrollTop(5);
                $("#datatable_measurement").dataTable().fnDestroy();
                this.loadMeasurementList();
               
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }
    
    public fileChange(input) {
		this.processImage(input.target.files);
    }

    private processImage(files, index = 0) {
        let reader = new FileReader();

        if (index in files) {
            this.readFile(files[index], reader, (result) => {
                // Create an img element and add the image file data to it
                let img = document.createElement('img');
                img.src = result;

                // Send this img to the resize function (and wait for callback)
                this.measureService.resizeImage(img, (croppedImage) => {
                    
                    // This is the file you want to upload.
                    // Either as a base64 string or img.src = croppedImage if you prefer a file.
                    this.drugImage = croppedImage;
                    this.drugImageBase64 = croppedImage;
                });
            });
        } else {
            // When all files are done this forces a change detection
            this.changeDetectorRef.detectChanges();
        }
    }

    private readFile(file, reader, callback) {
        reader.onload = () => {
            callback(reader.result);
        };

        reader.readAsDataURL(file);
    }

    clearData() {

        this.measure.reset();
        $('#imageMeasurement').attr("src", 'assets/images/medication-type-default.png');
        $('#btnSubmit').text('Submit');
        this.drugImageBase64 = "";
    }

    IsValidImageUrl(url,imageId): boolean
    {
        let flag = false;
        $("#"+imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            
            flag = true;
        }).on("error ", function () {
            
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            flag = false;

        });
        return flag;
        
    }

    



    testImage(url, callback, timeout) {
        alert('Entered')

    timeout = timeout || 5000;
    var timedOut = false, timer;
    var img = new Image();
    img.onerror = img.onabort = function () {
        if (!timedOut) {
            clearTimeout(timer);
            callback(url, "error");
            alert('Error file');
        }
    };
    img.onload = function () {
        if (!timedOut) {
            clearTimeout(timer);
            callback(url, "success");
            alert('sucess');
        }
    };
    img.src = url;
    timer = setTimeout(function () {
        timedOut = true;
        callback(url, "timeout");
    }, timeout);
}


    record(url, result): string {
        alert(result);
        
         return result;
    }

    public AddMeasurement(): void {
        if (!$('#datatable_processing').is(':visible')) {
            this.isLoading = true;
        }
        this.router.navigate(['/', this.selectedCompanyId, 'measurement', 'new']);
    }

    
      
}
