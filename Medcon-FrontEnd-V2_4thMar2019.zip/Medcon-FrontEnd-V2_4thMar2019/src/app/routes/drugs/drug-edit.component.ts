import { ChangeDetectorRef, Component, HostListener, OnInit, Compiler } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { DrugService } from '../../services/drug.service';
import { Drug } from '../../models/drug';
import { DrugRequest } from '../../requests/drug-request';
import { Observable } from 'rxjs/Observable';
import { CommonService } from '../../services/commonService';
@Component({
    templateUrl: './drug-edit.component.html?v=${new Date().getTime()}'
})

export class DrugEditComponent implements OnInit {
	public drug: Drug;
	public form: FormGroup;
	public showErrors: boolean;
	public successMessage: string;
	public errorMessage: string;
	public medicationAmount: number;
	public unitOfMeasure: string;
	public medicationTypes: any;
	public selectedMedicationTypeId: any = 'Tablet';
    private drugImage: string;
    public allmedicationTypeList: any;
    public selectedMedicationType: any;
    public drugImageBase64: string;
    userId: number;
    selectedUnitOfMeasure: string;
    allmedicationTypeFilteredList: any;
    isLoading: boolean;
    selectedMedicationTypeIdFinalVal: number;
    public distinctMedicationTypesList: any;
    public isResetButtonClicked: boolean;
	constructor(public templateService: TemplateService,
		private router: Router,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private drugService: DrugService,
        private changeDetectorRef: ChangeDetectorRef,
        private _compiler: Compiler
    ) {
	}

    public ngOnInit() {
        this.isResetButtonClicked = false;
        this._compiler.clearCache();
        this.isLoading = false;
		this.drug = this.route.snapshot.data['drug'];

		if (this.drug.inUse) {
			this.goBack();
		}
        
            this.form = this.fb.group({
                name: [this.drug.name, Validators.required],
                alias: [this.drug.alias, Validators.required],
                image: [''],
                medicationAmount: [this.drug.amount, Validators.required],
                unitOfMeasure: [this.drug.unit, Validators.required],
                medicationTypeId: [this.drug.medicationId, Validators.required]
            });
            
            if (this.drug.bucketKey != null) {
                this.drugImage = CommonService.MEDCON_V2_S3_BUCKET_URL + this.drug.bucketKey; //'https://s3.amazonaws.com/medcon-api-drugs-v2-dev-drugimages-4tb0ljduq777/' + this.drug.bucketKey;
                this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + this.drug.bucketKey, "editDrugImageId");

            }
            else
                this.drugImage = '../../../assets/images/medication-type-default.png';
        
            

        
        this.selectedUnitOfMeasure = this.drug.unit;
        this.allmedicationTypeFilteredList = [this.drug.unit];
        this.selectedMedicationType = this.drug.medicationtype;
        this.selectedMedicationTypeIdFinalVal = this.drug.medicationId;
       
        if (localStorage.getItem("DRUG_ID_" + this.drug.id) >0) {
           
            $("#name").attr("disabled", "disabled");
            $("#alias").attr("disabled", "disabled");
            $("#medicationTypeId").attr("disabled", "disabled");
            $("#unitOfMeasure").attr("disabled", "disabled");
            $("#medicationAmount").attr("disabled", "disabled");
           
        }
        else {
            
            $("#name").removeAttr("disabled");
            $("#alias").removeAttr("disabled");
            $("#medicationTypeId").removeAttr("disabled");
            $("#unitOfMeasure").removeAttr("disabled");
            $("#medicationAmount").removeAttr("disabled");   


            
        }

    }


    SetAndValidateImageUrl(url, imageId): void {
        
        let flag = false;
        $("#" + imageId).attr("src", url);
        $("#" + imageId).on("load", function () {
            
        }).on("error ", function () {
            
            $("#" + imageId).attr("src", "../../../assets/images/medication-type-default.png");
            

        });
        

    }

    public onSubmit() {
        var drugNameCheck = this.form.value.name.trim();
		if (this.form.invalid) {
			this.showErrors = true;
        }
        else if (drugNameCheck == '') {
            this.showErrors = true;
            this.errorMessage = "Please enter valid Drug name "
            this.form.controls['name'].setValue('');
            $(window).scrollTop(5);
        }
        else if ($('#unitOfMeasure').val() == '' || $('#unitOfMeasure').val() ==null)
        {
            this.showErrors = true;
            this.errorMessage = 'Please select Unit of Measure';
        }
        else {
            
            this.isLoading = true;
            this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));
			
            if (this.drugImageBase64 == undefined)
                this.drugImageBase64 = "";
            let request = new DrugRequest(
                drugNameCheck,
                this.form.value.alias,
                this.drugImageBase64,
                Number(this.form.value.medicationAmount),
                
                Number(this.userId),
               
                Number(this.selectedMedicationTypeIdFinalVal)

            );

			this.drugService.updateDrug(this.drug.id, request).subscribe(
                (response) => {
                    this.isLoading = false;
					this.form.markAsPristine();
                    this.successMessage = 'Drug has been successfully updated';
                    $(window).scrollTop(5);
                    this.goBack();
				},
                (err) => {
                    this.isLoading = false;
					this.errorMessage = err;
				});
		}
	}

	public fileChange(input) {
		this.processImage(input.target.files);
	}

	public alertClosed(): void {
		this.successMessage = null;
		this.errorMessage = null;
	}

    public goBack(): void {
        this.isLoading = true;
		this.form.markAsPristine();
		this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'drugs']);
	}

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}

    private processImage(files, index = 0) {
        let reader = new FileReader();

        if (index in files) {
            this.readFile(files[index], reader, (result) => {
                // Create an img element and add the image file data to it
                let img = document.createElement('img');
                img.src = result;

                // Send this img to the resize function (and wait for callback)
                this.drugService.resizeImage(img, (croppedImage) => {

                    // This is the file you want to upload.
                    // Either as a base64 string or img.src = croppedImage if you prefer a file.
                    this.drugImage = croppedImage;
                    this.drugImageBase64 = croppedImage;
                });
            });
        } else {
            // When all files are done this forces a change detection
            this.changeDetectorRef.detectChanges();
        }
    }

	private readFile(file, reader, callback) {
		reader.onload = () => {
			callback(reader.result);
		};

		reader.readAsDataURL(file);
    }

    public ngAfterViewInit() {

        this.drugService.getAllMedicationType((localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
            (response) => {
                this.allmedicationTypeList = response;
                //To get the distinct medication type names
                var lookup = {};
                var items = response;
                var result = [];

                for (var item, i = 0; item = items[i++];) {
                    var name = item.name;

                    if (!(name in lookup)) {
                        lookup[name] = 1;
                        result.push(item);
                    }
                }
                this.distinctMedicationTypesList = result;
               //End To get the distinct medication type names
                if (this.allmedicationTypeList != undefined) {
                    
                    this.allmedicationTypeFilteredList = this.allmedicationTypeList.filter(
                        medtypes => medtypes.name === this.selectedMedicationType);

                    var unique = {};
                    var distinct = [];
                    this.allmedicationTypeFilteredList.forEach(function (x) {
                        if (!unique[x.measure]) {
                            distinct.push(x.measure);
                            unique[x.measure] = true;
                        }
                    });
                   
                    this.allmedicationTypeFilteredList = distinct;

                   
                }

                
            },
            (err) => {
                this.errorMessage = err;

            });
    }
    onChange_UnitOfMeasure(selectedValue) {

        let selectedImage = '';
        this.selectedMedicationType = (this.selectedMedicationType == null) ? 'Tablet' : this.selectedMedicationType;
        if (this.allmedicationTypeList != null) {
            for (var i = 0; i < this.allmedicationTypeList.length; i++) {
                if (this.allmedicationTypeList[i].measure == selectedValue && this.allmedicationTypeList[i].name == this.selectedMedicationType) {
                    this.selectedMedicationTypeIdFinalVal = this.allmedicationTypeList[i].id;
                    if (this.allmedicationTypeList[i].image != null)
                        selectedImage = this.allmedicationTypeList[i].image;
                    else
                        selectedImage = '';
                }


            }
            this.loadDrugImage(selectedImage);
        }

        

    }
    onChange_MedicationType(selectedValue) {
       
        this.selectedMedicationType = selectedValue;
        let selectedImage = '';
       
        if (this.allmedicationTypeList != null) {
            for (var i = 0; i < this.allmedicationTypeList.length; i++) {
                
                if (this.allmedicationTypeList[i].name == this.selectedMedicationType) {
                    
                    selectedImage = this.allmedicationTypeList[i].image;
                    this.selectedMedicationTypeIdFinalVal = this.allmedicationTypeList[i].id;
                    this.selectedUnitOfMeasure = this.allmedicationTypeList[i].measure;

                    if (this.isResetButtonClicked) {
                        selectedImage = this.drug.bucketKey;
                        this.isResetButtonClicked = false;
                    }
                    
                    break;
                }
            }

            this.allmedicationTypeFilteredList = this.allmedicationTypeList.filter(
                medtypes => medtypes.name === this.selectedMedicationType);

            var unique = {};
            var distinct = [];
            this.allmedicationTypeFilteredList.forEach(function (x) {
                if (!unique[x.measure]) {
                    distinct.push(x.measure);
                    unique[x.measure] = true;
                }
            });
            //alert(distinct[0]);
            this.allmedicationTypeFilteredList = distinct;
            this.loadDrugImage(selectedImage);
            
        }

        

    }

    clearData() {
        
        this.form.reset();
        this.ngOnInit();
        this.ngAfterViewInit();
        this.selectedMedicationType = this.drug.medicationtype;
        this.form.controls['medicationTypeId'].setValue(this.selectedMedicationType);
        this.form.controls['image'].setValue('');
        
        this.isResetButtonClicked = true;
    }

    loadDrugImage(selectedImage) {
        //if (this.allmedicationTypeList != undefined) {
        //alert(selectedImage);
        if (selectedImage == null || selectedImage == '') {
            this.drugImage = 'assets/images/medication-type-default.png';
            this.drugImageBase64 = '';
        }
        else {
            this.drugImage = CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage;
            this.SetAndValidateImageUrl(CommonService.MEDCON_V2_S3_BUCKET_URL + selectedImage, "newDrugImageId");
            this.drugImageBase64 = selectedImage;
        }
        //}

    }

   
}
