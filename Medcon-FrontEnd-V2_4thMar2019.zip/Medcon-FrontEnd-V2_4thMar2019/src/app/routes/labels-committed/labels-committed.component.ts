﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { LabelCommittedRequest } from '../../requests/label-committed-request';
import { LabelPurchasedRequest } from '../../requests/label-purchased-request';
import { ModalDirective } from 'ngx-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { UserService } from '../../services/user.service';
import { Observable } from 'rxjs/Observable';
import { UserRole } from '../../models/userrole';
import { CurrentUserService } from '../../services/currentuser.service';
import { CognitoUser } from '../../models/cognito-user';
import { LabelService } from '../../services/label.service';
import { Customer } from '../../models/customer';
import { Label } from '../../models/labels';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { CompanyService } from '../../services/company.service';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { TrialService } from '../../services/trial.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
import { LocationStrategy } from '@angular/common';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
enum Roles {
    'Medcon Admin',
    'Customer Admin',
    'Label User',
    'Customer User',
    'Patient'
}



@Component({
    templateUrl: './labels-committed.component.html?v=${new Date().getTime()}'
})

export class LabelsCommittedComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('viewSummaryModal') public viewSummaryModal: ModalDirective;
    @ViewChild('labelDetailsModal') public labelDetailsModal: ModalDirective;
    public customer: Customer;
    public addPurchasedForm: FormGroup;
    public formLabelsCommitted: FormGroup;
    public showErrors: boolean;
    public showErrors_addPurchasedForm: boolean;
    public errorMessage: string;
    public successMessage: string;
    public labels: any;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    companyOptions: string[];
    defaultRole;
    defaultCompany;
    loggedInCompany;
    selectedCompany;
    isEditForm: boolean;
    selectedCompanyId: number;
    public UserRole: typeof UserRole = UserRole;
    public loggedInUserRole: string;
    public currentUserRole: UserRole;
    toggoleShowHide: string = "hidden";
    companyList: any;
    labelsCommittedList: any;
    public labelToDelete: Label;
    public selectedCustomerId: number;
    public yearList = [];;
    public labelDetailsList: any;
    public defaultYear: any;
    selectedLabelId: number;
    selectedYear: number;
    private yy: number;
    globalCompanyId: number;
    public startDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };

    public endDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    isLoading: boolean;
    companyIdToDelete: number;
    yearToDelete: number;
    errorMessage_DtableError: string;
    errorCount: number;
    endTime: number;
    constructor(public templateService: TemplateService,
        public router: Router,
        public labelService: LabelService,
        public currentUserService: CurrentUserService,
        public companyService: CompanyService,
        private reportService: ReportService,
        private cognitoUtil: CognitoUtil,
        private fb: FormBuilder,
        private trialService: TrialService,
        private route: ActivatedRoute,
        private url: LocationStrategy) {
    }

    public ngOnInit() {
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.endTime = this.reportService.getTokenEndTime();
        this.errorCount = 0;
        this.isLoading = false;
        this.isEditForm = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.customer = this.route.snapshot.data['customer'];
        this.currentUserRole = this.route.snapshot.data['role'];
        this.globalCompanyId = localStorage.getItem('GLOBAL_COMPANY_ID')

        this.currentUserService.getRole().subscribe((role) => {
            if (role === UserRole.MedConAdmin) {

                this.loggedInUserRole = "MedConAdmin";
            }
            
        }, (err) => {
           
        });

        this.formLabelsCommitted = this.fb.group({
            labelsCommitted: ['', [Validators.required]],
            currentYear: ['', [Validators.required]],
            company: ['']
        });

        this.addPurchasedForm = this.fb.group({
            labelPurchased: ['', [Validators.required]],
            company: ['']
        });

       
        var x = Roles;
        var options = Object.keys(Roles);
        this.options = options.slice(options.length / 2);
        this.defaultRole = this.options[1];
        
        //Code added by ramesh on 29th Jan 2018 to get all companies json list to fill dropdown

        if (this.loggedInUserRole == "MedConAdmin") {
            this.companyService.getAllCompanies().subscribe(
                (response) => {
                    this.companyList = response;
                    
                },
                (err) => {
                    this.errorMessage = err;

                });
        }
        else {
            
            this.companyService.getAllCompanies().subscribe(
                (response) => {
                    
                    this.companyList = response.filter(company => company.companyId === Number(localStorage.getItem('GLOBAL_COMPANY_ID')));
                },
                (err) => {
                    this.errorMessage = err;

                });

        }

        //End code added by ramesh on 29th Jan 2018 to get all companies json list to fill dropdown

        this.labelsCommittedList = [
        ]
        
        this.getYear();
        
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Labels')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'))
    }
    labelReload() {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            this.errorMessage_DtableError = "Company is changed so page is refreshing..."
            this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/labels-committed', '');
            location.reload();

        }
    }
    public yearChanged(selectedYear): void {
        this.selectedYear = selectedYear;
        
        $("#datatable_labels").dataTable().fnDestroy();
        this.loadLabelsCommittedList(selectedYear);

    }

    public ngAfterViewInit() {
        
        this.defaultYear = 0;//(new Date()).getFullYear();//'2018';
        this.selectedYear = this.defaultYear;
        
        $("#datatable_labels").dataTable().fnDestroy();
        this.loadLabelsCommittedList(this.defaultYear);

    }

    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

    public onSubmit() {
        if (this.formLabelsCommitted.invalid) {
            this.showErrors = true;
            return;
        }
        let userId = localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID');
        let companyId =  this.getCompanyIdCompanyName(this.formLabelsCommitted.value.company); //localStorage.getItem('GLOBAL_COMPANY_ID');
        let ID = localStorage.getItem('labelsCommittedID');
        if (!this.isEditForm) {

            if (this.globalCompanyId != 1) {
                let d = this.convertDate(this.formLabelsCommitted.value.currentYear.date).split('-');

                this.route.params.subscribe((params) => {
                    let request = new LabelCommittedRequest(
                        Number(this.formLabelsCommitted.value.labelsCommitted),
                        Number(userId),
                        
                        this.formLabelsCommitted.value.currentYear
                    );
                    this.isLoading = true;
                    this.labelService.updateCommitted(Number(this.globalCompanyId), request)
                        .subscribe(
                        (response) => {
                            this.isLoading = false;
                            this.formLabelsCommitted.markAsPristine();
                            this.successMessage = 'Label commitment has been successfully inserted.';
                            $("#datatable_labels").dataTable().fnDestroy();
                            this.loadLabelsCommittedList(this.defaultYear);
                            
                            this.clearData();
                        },
                        (err) => {
                            this.isLoading = false;
                            this.errorMessage = err;
                        }
                        );
                });
            }
            else {
                this.errorMessage = "Medcon company should not add labels"
            }

        }
        else if (this.isEditForm) {
            //if (this.globalCompanyId!=1){

            this.route.params.subscribe((params) => {
                let request = new LabelCommittedRequest(
                    Number(this.formLabelsCommitted.value.labelsCommitted),
                    Number(userId),
                    this.formLabelsCommitted.value.currentYear,
                    this.formLabelsCommitted.value.company,
                    Number(localStorage.getItem("SELECTED_COMPANY_ID"))


                );

                this.isLoading = true;
                this.labelService.updateCommittedById(Number(ID), request)
                    .subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.formLabelsCommitted.markAsPristine();
                        this.successMessage = 'Label commitment has been successfully updated.';
                        $("#datatable_labels").dataTable().fnDestroy();
                        this.loadLabelsCommittedList(this.defaultYear);

                        $('#company').removeAttr('disabled');
                        $('#currentYear').removeAttr('disabled');


                        this.clearData();
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });
            });
        //}
        //    else {
        //        this.errorMessage="Should not update Labels from Medcon "
        //    }
        }
    }
     
    public addPurchased() {
        let userId = localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID');
        let companyId = this.getCompanyIdCompanyName(this.addPurchasedForm.value.company);//localStorage.getItem('GLOBAL_COMPANY_ID');

        if (this.addPurchasedForm.invalid) {
            this.showErrors_addPurchasedForm = true;
            return;
        }
        if (this.globalCompanyId != 1) {
            this.route.params.subscribe((params) => {
                let request = new LabelPurchasedRequest(
                    Number(this.addPurchasedForm.value.labelPurchased),
                    Number(userId)

                );

                this.labelService.addLabelPurchased(Number(this.globalCompanyId), request)
                    .subscribe(
                    (response) => {
                        this.addPurchasedForm.markAsPristine();
                        this.successMessage = 'Label purchased has been successfully updated.';
                        
                        $("#datatable_labels").dataTable().fnDestroy();
                        this.loadLabelsCommittedList(this.defaultYear);
                        this.addPurchasedForm.reset();
                        this.clearFields_AddPurchased();
                        
                    },
                    (err) => {
                        this.errorMessage = err;
                    }
                    );
            });
        }
        else {
            this.errorMessage ="Medcon company should not purchase labels"
        }

    }

    public alertClosed(): void {
        this.errorMessage = null;
    }

    public goBack(): void {
        
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'labels-committed']);
    }

    

    public enableAddPurchasedSection(): void {

        this.toggoleShowHide = "visible";
    }

    public disableAddPurchasedSection(): void {

        this.toggoleShowHide = "hidden";

    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

        if (event.valid) {
            if (field === 'start') {
                this.setEndDateDisableUntil(date.date);
            } else if (field === 'end') {
                this.setStartDateDisableSince(date.date);
            }
        }
    }

    private dateForView(date: string): any {
        let stripZero = ((value) => {
            return (value < 9) ? value.replace('0', '') : value;
        });

        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
        } else {
            return '';
        }
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.startDateOptions);
        copy.disableSince = date;
        this.startDateOptions = copy;
    }

    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }

    public deleteItem(id): void {
        
        this.selectedLabelId = id;
        this.deleteModal.show();
        this.labelDetailsModal.hide();
    }


    public confirmDelete(): void {
                
        this.isLoading = true;
        
        this.labelService
            .deleteCommitment(this.selectedLabelId, this.companyIdToDelete, this.yearToDelete)
            .subscribe(
            (response) => {
                
                this.isLoading = false;
                this.hideDeleteModal();
                
                $("#datatable_labels").dataTable().fnDestroy();
                this.loadLabelsCommittedList(this.selectedYear);
            },
            (err) => {
                this.isLoading = false;
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public hideDeleteModal(): void {
        this.labelToDelete = null;
        this.deleteModal.hide();
    }

    public viewLabelDetails(companyId): void {

        this.labelDetailsModal.show();
    }

    public hideLabelDetailsModal(): void {

        this.labelDetailsModal.hide();
    }



    public editAndPopulateFormValues(labelObject) {
        this.isEditForm = true;
        //Added by ramesh on 8th Oct 2017
        let createdDate = new Date();
        let day = createdDate.getDate();
        let month = createdDate.getMonth() + 1;
        let year = createdDate.getFullYear();
        let today = year + '-' + month + '-' + day;
        //End
        this.formLabelsCommitted = this.fb.group({
            labelsCommitted: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            currentYear: [this.dateForView(today), Validators.required],
            company: ['', [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]]
        });
        this.selectedCompany = this.companyList[1].companyName;//"ABC Pharma Global";//labelObject.companyName;
        

    }

    onChange(selectedValue) {
        this.selectedCompanyId = Number(selectedValue);
        

    }

    public EditLabel(buttonId, companyName, labelsCommitted, currentYear, createdDate, companyId): void {

        let date = this.trialService.convertDateToCalendarFormat(createdDate);
        localStorage.setItem('labelsCommittedID', buttonId);
        this.isEditForm = true;
        $('#labelsCommitted').val(labelsCommitted);
        $('#labelsCommitted').addClass("inputEdit");
        $('#company').val(companyName);
        $('#company').attr('disabled', 'disabled');
        $('#currentYear').attr('disabled', 'disabled');

        $('#btnSubmit').text('Update');
      
        this.selectedCompany = companyName;
        

        this.formLabelsCommitted = this.fb.group({

            labelsCommitted: [labelsCommitted, Validators.required],
            currentYear: [createdDate, Validators.required],
            company: [companyName, Validators.required],

        });

        localStorage.setItem("SELECTED_COMPANY_ID", companyId);
        localStorage.setItem("SELECTED_LABEL_COMMMITTED_VALUE", labelsCommitted);
    }

    performDataTableRefresh(year) {
        this.reportService.isTokenExpired(this.endTime,'LabelsCommitted');
        if (localStorage.getItem("LabelsCommitted_IS_TOKEN_EXPIRED") == 'Y') {
            //alert('Expired');
            localStorage.setItem("LabelsCommitted_IS_TOKEN_EXPIRED", "N");
            this.endTime = this.reportService.getTokenEndTime();
            this.reportService.isTokenExpired(this.endTime,'LabelsCommitted');
            $(window).scrollTop(5);
            this.errorMessage_DtableError = "Refreshing page...";
            $("#pnlAlertWarning").css("display", "block");
            setTimeout(function () {
                $('#pnlAlertWarning').fadeOut('fast');
            }, 3000);
            //alert('Refreshing page...');
            this.loadLabelsCommittedList(year);
            //this.authorizationToken = self.getNewIdToken();
        }

    }

    public loadLabelsCommittedList(year): void {
        $("#datatable_labels").dataTable().fnDestroy();
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                
                $('#datatable_labels')
                    .on('order.dt', function () {

                        //self.performDataTableRefresh(year);

                    })
                    .on('search.dt', function () {
                        //alert('search');
                        //self.performDataTableRefresh(year);
                    })
                    .on('page.dt', function () {

                        //self.performDataTableRefresh(year);

                    })
                    .DataTable({
                    "processing": true,
                    "serverSide": true,
                    "stateSave": true,
                    stateSaveParams: function (settings, data) {
                        delete data.search;
                        data.start = 0;
                    },
                    "rowId": "companyId",
                    'ajax': {

                        //'url': 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/commit/list/' + year + '/all',
                        'url': CommonService.API_PATH_V2_GET_LIST_LABEL_COMMITMENT + 'label/commit/list/' + year + '/all?companyIds='+localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        error: function (xhr, error, code) {
                            //self.errorCount = self.errorCount + 1;
                            //if (self.errorCount == 1 && (xhr.status == 0 || xhr.status == 401)) {
                            //    $(window).scrollTop(5);
                            //    self.errorMessage_DtableError = "Refreshing page...";
                            //    $("#pnlAlertWarning").css("display", "block");
                            //    setTimeout(function () {
                            //        $('#pnlAlertWarning').fadeOut('fast');
                            //    }, 3000);
                            //    self.loadLabelsCommittedList(year);
                            //}
                            //else {

                            //    let errorMessage = '';
                            //    if (xhr.responseJSON != undefined)
                            //        errorMessage = xhr.responseJSON.message;
                            //    else
                            //        errorMessage = 'Server error occured';
                            //    self.errorMessage = errorMessage;
                            //    $('.dataTables_processing', $('#datatable_labels').closest('.dataTables_wrapper')).hide();
                            //}
                        }
                    }
                    
                    ,
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3, 4]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_GET_LIST_LABEL_COMMITMENT + 'label/commit/list/' + year + '/all' + '?companyIds=' + localStorage.getItem('GLOBAL_COMPANY_ID') + '&draw=1&columns%5B0%5D%5Bdata%5D=companyName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=created&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=labelsCommitted&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=labelsPurchased&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=labelsUsed&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=labelsRemaining&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=iD&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=8&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=false&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1530012411063'
                                self.reportService.ExportAll(apiUrl, 'Labels Committed');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "companyName" },
                        { "data": "created" },
                        { "data": "labelsCommitted" },
                        { "data": "labelsPurchased" },
                        { "data": "labelsUsed" },
                        { "data": "labelsRemaining" },
                        
                        { "data": "status" },
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                localStorage.setItem('companyName', full.companyName);
                                localStorage.setItem('labelsCommitted', full.labelsCommitted);
                                localStorage.setItem('labelsPurchased', full.labelsPurchased);
                                var todayDate = new Date();
                                var year = todayDate.getFullYear();
                                if (year > full.created) {
                                   
                                    return "<div class=\"btn-action\"><button id=\"" + full.iD + "_viewItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "_" + full.companyId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</button></div>";
                                }
                               else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Label As it is already deleted\" disabled  id=\"" + full.iD + "_editItem\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> <button title=\"Cannot Delete this Label As it is already deleted\" disabled id=\"" + full.iD + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                   
                                    else {
                                        return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "_" + full.companyId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button><button  id=\"" + full.iD + "_deleteItem" +  "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created +"\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Label As it is already deleted\" disabled  id=\"" + full.iD + "_editItem\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> </div>";
                                    }
                                  
                                    else {
                                        return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "_" + full.companyId +  "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button></div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"> <button title=\"Cannot Delete this Label As it is already deleted\" disabled id=\"" + full.iD + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                  
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.iD + "_deleteItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if ((self.currentUserRole == UserRole.CustomerUser) && (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 ) )
                                {
                                    return "<div class=\"btn-action\"><button id=\"" + full.iD + "_editItem" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "_" + full.companyId +  "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</button></div>";

                                }
                                else {
                                    return "";
                                }
                            }
                        },
                        

                    ]
                    ,
                    "columnDefs": [

                        {
                            "targets": [3],
                            render: function (data, type, full, meta) {
                                return "<u  id=\"" + full.iD + "_purchaseClick" + "_" + full.companyName + "_" + full.labelsCommitted + "_" + full.labelsPurchased + "_" + full.created + "_" + full.companyId +"\" style=\"cursor: pointer;\">_" + data + " </u></div>";
                               

                            }
                        }
                        ,
                        
                        {
                            "targets": [6],
                            render: function (data, type, row) {
                                return data == '1' ? 'Active' : 'Inactive'
                            }
                        }

                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    }
                    
                });
            }
        });
        
        $('#datatable_labels').on('click', 'td button', function () {
            
            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            var companyName = attId.split("_")[2];
            var labelsCommitted = attId.split("_")[3];
            var labelsPurchased = attId.split("_")[4];
            var createdDate = attId.split("_")[5];
            var companyId = attId.split("_")[6];
            this.selectedLabelId = buttonId;

            if (buttonName == "editItem") {

                self.EditLabel(buttonId, companyName, labelsCommitted, labelsPurchased, createdDate, companyId);
                $('#btnSubmit,#btnCancel').css("visibility", "visible");
                $('#btnReset').css("visibility", "visible");
            }

            if (buttonName == "deleteItem") {
                
                self.companyIdToDelete = self.getCompanyIdCompanyName(companyName);
                self.yearToDelete = Number(createdDate);
                
                self.deleteItem(buttonId);
                
            }

            if (buttonName == 'viewItem')
            {
                $('#btnSubmit,#btnCancel,#btnReset').css("visibility", "hidden");
                 self.EditLabel(buttonId, companyName, labelsCommitted, labelsPurchased, createdDate, companyId);
            }


            
        });
        $('#datatable_labels tbody').on('click', 'tr td u', function () {
           
            var attId = $(this).attr('id');
           
            var createdDate = attId.split("_")[5];
            var selectedRowCompanyId = attId.split("_")[6];
            
            self.LoadLabelData(selectedRowCompanyId, createdDate);

        });




    }


    public LoadLabelData(companyId, committedYear): void {

        
        this.isLoading = true;
        this.labelService.getLabelDetails(companyId, committedYear).subscribe(
            (response) => {
                this.isLoading = false;
               
                let status = (response.status) == 1 ? "Active" : "Inactive";
                $("#spnCompanyName").text(response.companyName);
                $("#spnStatus").text(status);
                $("#spnRemaining").text(response.remaining);
                $("#spnPurchased").text(response.purchased);
                $("#spnCommitted").text(response.committed);
                $("#spnUsed").text(response.used);
                
                this.LoadLabelPurchaseData(companyId, committedYear);
                this.labelDetailsModal.show();
                
            },
            (err) => {
                this.errorMessage = err;

            });

    }

    public LoadLabelPurchaseData(companyId,year): void {

        this.isLoading = true;
        this.labelService.getLabelPurchase(companyId,year).subscribe(
            (response) => {
                this.isLoading = false;
                this.labelDetailsList = response



            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });

    }


    getCompanyIdCompanyName(companyName):number
    {
        let companyId = 0;
        if (this.companyList != null) {
            for (var i = 0; i < this.companyList.length; i++) {
                if (this.companyList[i].companyName == companyName) {
                    companyId = this.companyList[i].companyId;
                }
            }

        }
        return companyId;
    }

    clearFields() {
        
       

            let selectedLabelCommittedValue = localStorage.getItem("SELECTED_LABEL_COMMMITTED_VALUE");
            this.formLabelsCommitted.controls["labelsCommitted"].setValue(selectedLabelCommittedValue);
        

    }

    clearFields_AddPurchased() {
        
        this.addPurchasedForm = this.fb.group({
            labelPurchased: ['', [Validators.required]],
            company: [localStorage.getItem('GLOBAL_COMPANY_NAME'), Validators.required],
        });

    }
    clearData() {

        $('#labelsCommitted').removeClass("inputEdit");
        $('#btnReset').css("visibility", "hidden");
       
        $('#company').removeAttr('disabled');
        $('#currentYear').removeAttr('disabled');

        $('#btnSubmit').text('Submit');
        this.formLabelsCommitted.controls["labelsCommitted"].setValue("");
        this.formLabelsCommitted.controls["currentYear"].setValue(0);
        this.isEditForm = false;

    }

    getYear() {
        var today = new Date();
        this.yy = today.getFullYear()-2;
        for (var i = this.yy; i <= (this.yy + 100); i++) {
            this.yearList.push(i);
        }
    }
    
}
