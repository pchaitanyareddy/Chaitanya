﻿import { PrivilegesRequest } from '../../requests/privileges-request';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { PrivilegesService } from '../../services/privileges.service';
import { Observable } from 'rxjs/Observable';
import { Pagination } from '../../models/pagination';
import { FormsModule } from '@angular/forms';
import { Privileges } from '../../models/privileges';
import { UserRole } from '../../models/userrole';
import { CurrentUserService } from '../../services/currentuser.service';
import { UserService } from '../../services/user.service';
import { LocationStrategy } from '@angular/common';
enum Roles {
    'Medcon Admin',
    'Customer Admin',
    'Label User',
    'Customer User',
    'Patient'
}


@Component({
    templateUrl: './privileges-list.component.html?v=${new Date().getTime()}'
})

export class PrivilegesComponent implements OnInit {
    public privileges: Pagination<Privileges>;
    public privilegesForm: FormGroup;
    public showErrors: boolean;
    public errorMessage: string;
    public successMessage: string;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    defaultRole;
    privilegesList: any;
    allRoleList: any;
    selectedAll: any;
    selectedCheckboxes: Array<any> = [];
    selectedRow: string;
    selectedRows: string;
    selectedRowCount: number;
    public customerId: number;
    public UserRole: typeof UserRole = UserRole;
   
    public roleId: number;
    loggedInUserRole: string;
    selectedRoleId: number;
    selectedRoleName: string;
    rowLevelCheckboxSelected: boolean;
    isLoading: boolean;
    constructor(public templateService: TemplateService,
        public router: Router,
        public privilegesService: PrivilegesService,
        public currentUserService: CurrentUserService,
        public userService: UserService,
        private fb: FormBuilder,
        private url: LocationStrategy,
        private route: ActivatedRoute) {

        this.currentUserService.getRole().subscribe((role) => {
            if (role === UserRole.MedConAdmin) {
                this.roleId = UserRole.MedConAdmin;
                this.loggedInUserRole = "MedConAdmin";
            }
            
        }, (err) => {
           
        });
        this.selectedRoleId = 1;
        
    }


    public ngOnInit() {
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.isLoading = false;
       
        this.privileges = this.route.snapshot.data['privileges'];
        this.customerId = this.route.snapshot.params['customer_id'];
        this.privilegesForm = this.fb.group({
            
            role: ['CustomerUser', [Validators.required]]
        });

        var x = Roles;
        var options = Object.keys(Roles);
        this.options = options.slice(options.length / 2);
       
        this.privilegesList = this.privileges;
        this.userService.getAllRoles().subscribe(
            (response) => {
                this.allRoleList = response;

            },
            (err) => {
                this.errorMessage = err;

            });
        
    }

    public resetPrivileges()
    {
        location.reload();
    }

    public onSubmit() {
        let selectedCheckboxRow = 0;
        let jsonHeader= '[';
        let jsonFooter= ']';
        
        this.selectedRow = "";
        this.selectedCheckboxes = [];
        this.selectedRows = "";
        this.selectedRowCount = 0;

        for (let i = 0; i < this.privilegesList.length; i++) {
         
                let status = (<HTMLInputElement>document.getElementsByClassName("chkSelected")[i]).checked;
                if (status)
                    selectedCheckboxRow = Number(selectedCheckboxRow) +1
                let view = ((<HTMLInputElement>document.getElementsByClassName("chkView")[i]).checked) ? "1" : "0";
                let add = ((<HTMLInputElement>document.getElementsByClassName("chkAdd")[i]).checked) ? "1" : "0";
                let edit = ((<HTMLInputElement>document.getElementsByClassName("chkEdit")[i]).checked) ? "1" : "0";
                let deleteAction = ((<HTMLInputElement>document.getElementsByClassName("chkDelete")[i]).checked) ? "1" : "0";
                let roleName = this.privilegesForm.value.role;
                if (view == "0" && add == "0" && edit == "0" && deleteAction == "0")
                    status = false;
                
                this.selectedRow = "{\"status\":" + status + "," + "\"moduleName\":" + "\""+this.privilegesList[i].moduleName + "\""+"," + "\"edit\":" + edit + "," + "\"add\":" + add + "," + "\"view\":" + view + "," + "\"id\":" + this.privilegesList[i].id + "," +"\"delete\":" + deleteAction+"}";
                if (this.selectedRows.length > 0) {

                    this.selectedRows = this.selectedRows + "," + this.selectedRow;
                }
                else {
                    this.selectedRows = this.selectedRow;
                }

                this.selectedRowCount++;

                
            
        }
        
        if (selectedCheckboxRow == 0) {
            this.errorMessage = 'Please select atleast one module.';
            $(window).scrollTop(5);
        }

        else {
            //To get the selected role name


            let finalJsonString = jsonHeader + this.selectedRows + jsonFooter;

            this.route.params.subscribe((params) => {
                let request = new PrivilegesRequest(
                    finalJsonString
                );
                this.isLoading = true;
                this.privilegesService.updatePrivileges(finalJsonString, this.selectedRoleId).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.privilegesForm.markAsPristine();
                        this.successMessage = 'Privileges has been successfully updated';

                        $(window).scrollTop(5);

                        location.reload();

                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });
            });
        }
        
    }

    public alertClosed(): void {
        this.errorMessage = null;
    }

    public goBack(): void {
        this.privilegesForm.markAsPristine();
       
        this.router.navigate(['/', 'dashboard']);
    }

    selectAll() {
        
        for (var i = 0; i < this.privilegesList.length; i++) {
            this.privilegesList[i].status = this.selectedAll;
            this.privilegesList[i].view = this.selectedAll;
            this.privilegesList[i].add = this.selectedAll;
            this.privilegesList[i].edit = this.selectedAll;
            this.privilegesList[i].deleteAction = this.selectedAll;

            this.alterFewPermissions(i, this.selectedAll);
        }
    }
    checkIfAllSelected(rowIndex, selectedValue) {
        this.selectedAll = this.privilegesList.every(function (item: any) {
            return item.status == true;
        })

        this.alterFewPermissions(rowIndex, selectedValue);

    }

    alterFewPermissions(rowIndex, selectedValue)
    {
        if (this.selectedRoleId == 5 && this.privilegesList[rowIndex].moduleName != 'Privileges') { //customer user, add edit delete always zero due to  customer user has only readonly access except privileges
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = 0;
            this.privilegesList[rowIndex].delete = 0;
        }
       
        else if ((this.selectedRoleId != 1 && this.privilegesList[rowIndex].moduleName == 'Privileges') || (this.selectedRoleId == 5 && this.privilegesList[rowIndex].moduleName == 'Import Patient')) { //other than medcon admin, for privileges module name, all permissions are zero
           
            this.privilegesList[rowIndex].view = 0;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = 0;
            this.privilegesList[rowIndex].delete = 0;
        }
        else if (this.selectedRoleId == 1 && this.privilegesList[rowIndex].moduleName == 'Trials') { //For Medcon admin, restirct privileges to AddTrial
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = selectedValue;
            this.privilegesList[rowIndex].delete = selectedValue;
        }
        else if (this.selectedRoleId == 4 && this.privilegesList[rowIndex].moduleName != 'Import Patient' && this.privilegesList[rowIndex].moduleName != 'Export') { //label user
            this.privilegesList[rowIndex].view = 0;
            this.privilegesList[rowIndex].add = 0;
            this.privilegesList[rowIndex].edit = 0;
            this.privilegesList[rowIndex].delete = 0;
        }
        else if (this.privilegesList[rowIndex].moduleName == 'Broadcast Messages' ) { //for all user roles
            
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = selectedValue;
            this.privilegesList[rowIndex].edit = selectedValue;
            this.privilegesList[rowIndex].delete = 0;
        }
        else {
            //alert('else');
            this.privilegesList[rowIndex].view = selectedValue;
            this.privilegesList[rowIndex].add = selectedValue;
            this.privilegesList[rowIndex].edit = selectedValue;
            this.privilegesList[rowIndex].delete = selectedValue;
        }

    }

    changeStatusCheckbox(id, permissionType, selectedValue, rowIndex) {
       
        if (permissionType == 'View') {
            this.privilegesList[rowIndex].view = selectedValue;
            
        }
        else if (permissionType == 'Add') {
           
            this.privilegesList[rowIndex].add = selectedValue;
           
        }
        else if (permissionType == 'Edit') {
           
            this.privilegesList[rowIndex].edit = selectedValue;
           
        }
        else if (permissionType == 'Delete') {
           
            this.privilegesList[rowIndex].delete = selectedValue;
        }
        if (selectedValue == false && ($('#chkViewPermission_' + id).is(":checked") || $('#chkAddPermission_' + id).is(":checked") || $('#chkEditPermission_' + id).is(":checked") || $('#chkDeletePermission_' + id).is(":checked")))
        {
            this.privilegesList[rowIndex].status = true; //if any one of the checkbox(either add, view, edit , delete) selected, then flag is true

        }
        else
            this.privilegesList[rowIndex].status = selectedValue;

        if ((this.selectedRoleId == 5 && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Dashboard' && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Reports' && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Export' && permissionType == 'View' && selectedValue == false)
            || (this.privilegesList[rowIndex].moduleName == 'Import Patient' && permissionType == 'Add' && selectedValue == false)
        )
        {
            this.privilegesList[rowIndex].status = false;

        }

    }

    onChange(selectedValue) {
       
        this.selectedRoleId = Number(selectedValue);
       
        this.selectedRoleName = null;
        //To get selected role name
        if (this.allRoleList != null) {
            for (var i = 0; i < this.allRoleList.length; i++) {
                if (this.allRoleList[i].roleId == this.selectedRoleId) {
                    this.selectedRoleName = this.allRoleList[i].roleName;
                }
            }

        }

        
        this.selectedAll = false;
        if (selectedValue == 4) //"Label User"
        {
            
            this.isLoading = true;
            this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
                (response) => {
                    this.privilegesList = response;
                    this.isLoading = false;
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });

        }
        
        else if ((selectedValue == "2") || (selectedValue == "3") || (selectedValue == "5"))
        {
            this.isLoading = true;
            this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
                (response) => {
                    this.privilegesList = response;
                    this.isLoading = false;
                },
                (err) => {
                    this.errorMessage = err;
                    this.isLoading = false;
                });

        
        }
        else if (selectedValue == "1") {  //Medcon Admin


            this.privilegesList = this.privileges;

        }
    }

    public getPrivilegesByRoleId(roleId)
    {
        let privilegesListReturnJson: any;

        this.privilegesService.getPrivileges(this.selectedRoleId).subscribe(
            (response) => {
                privilegesListReturnJson = response;

            },
            (err) => {
                this.errorMessage = err;

            });

        return privilegesListReturnJson;

    }

    public prepareJsonString()
    {
        [
            {
                "status": true,
                "moduleName": "Patient",
                "edit": 0,
                "add": 1,
                "view": 1,
                "id": 1,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Data Reports",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 2,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Trials",
                "edit": 0,
                "add": 0,
                "view": 1,
                "id": 3,
                "delete": 0
            },
            {
                "status": true,
                "moduleName": "Trial Group",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 4,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Pharmaceutical Company",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 5,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Label Manufacturer",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 6,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Drugs",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 7,
                "delete": 112
            },
            {
                "status": true,
                "moduleName": "Regimen",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 8,
                "delete": 111
            },
            {
                "status": true,
                "moduleName": "Alerts",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 9,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Schedules",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 10,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Import",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 11,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Notifications",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 12,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Users",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 13,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Customers",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 14,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "Manage Customer Users",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 15,
                "delete": 1
            },
            {
                "status": true,
                "moduleName": "MCC Settings",
                "edit": 1,
                "add": 1,
                "view": 1,
                "id": 16,
                "delete": 1
            }
        ]



    }

    onRefresh(companyId, viewName) {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url + '?';

        this.router.navigateByUrl(currentUrl)
            .then(() => {
                this.router.navigated = false;
                if (companyId != '')
                    this.router.navigate(['/', companyId, viewName]);
                else
                    this.router.navigate(['/' + viewName]);
            });
    }
}
