import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-weekly-adherence-info',
	templateUrl: './widget-adherence-info.component.html'
})

export class WidgetWeeklyAdherenceInfoComponent implements OnInit {
	public stats: any;

	constructor(private dashboardService: DashboardService) {
	}

	public ngOnInit(): void {
		this.dashboardService.doseAdherenceInfo.subscribe((value) => {
			if (value) {
				this.stats = value.weekly;
			}
		});
	}
}
