import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-weekly-doses-logged',
	templateUrl: './widget-doses-logged.component.html'
})

export class WidgetWeeklyDosesLoggedComponent implements OnInit {
	public label1 = 'This week';
	public label2 = 'Last week';
	public doses: any;

	constructor(private dashboardService: DashboardService) {
	}

	public ngOnInit(): void {
		this.dashboardService.doseTrackLogged.subscribe((value) => {
			if (value) {
				this.doses = value.weekly;
			}
		});
	}
}
