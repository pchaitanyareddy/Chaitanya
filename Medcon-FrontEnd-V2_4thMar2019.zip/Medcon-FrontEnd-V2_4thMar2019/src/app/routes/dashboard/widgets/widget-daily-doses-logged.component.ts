import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-daily-doses-logged',
	templateUrl: './widget-doses-logged.component.html'
})

export class WidgetDailyDosesLoggedComponent implements OnInit {
	public label1 = 'Today';
	public label2 = 'Yesterday';
	public doses: any;

	constructor(private dashboardService: DashboardService) {
	}

	public ngOnInit(): void {
		this.dashboardService.doseTrackLogged.subscribe((value) => {
			if (value) {
				this.doses = value.daily;
			}
		});
	}
}
