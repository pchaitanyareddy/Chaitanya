import { Component, HostListener, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-weekly-track',
	templateUrl: './widget-weekly-track.component.html',
	styleUrls: ['../dashboard.component.scss']
})

export class WidgetWeeklyTrackComponent implements OnInit {
	public showMenu = false;
	public activeOption;
	public options = [
		{
			id: 'doses-logged',
			name: 'Doses Captured'
		},
		{
			id: 'patient-non-compliance',
			name: 'Patient Non-Compliance'
		},
		{
			id: 'adherence-info',
			name: 'Adherence Info'
		}
	];

	constructor(private dashboardService: DashboardService) {
	}

    public ngOnInit() {
        let selectedOptionId = localStorage.getItem("WEEKLY_TRACK_OPTION"); //state.weeklyTrack
		this.dashboardService.viewState.subscribe((state) => {
            let savedOption = this.options.filter((option) => option.id === selectedOptionId);
            this.activeOption = (savedOption[0]) ? savedOption[0] : this.options[0];
		});
	}

    public toggleMenuOption(optionID): void {
        localStorage.setItem("WEEKLY_TRACK_OPTION", optionID);
		this.showMenu = false;
        this.activeOption = this.options.filter((option) => option.id === optionID)[0];
        //alert(this.activeOption.id);
		//this.dashboardService.setDashboardStateValue('weeklyTrack', this.activeOption.id);
	}

	public toggleMenu(): void {
		this.showMenu = !this.showMenu;
	}

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-menu-weekly') {
			this.showMenu = false;
		}
	}
}
