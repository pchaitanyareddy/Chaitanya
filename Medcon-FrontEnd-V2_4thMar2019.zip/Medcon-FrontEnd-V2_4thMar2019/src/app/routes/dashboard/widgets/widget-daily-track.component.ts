import { Component, HostListener, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-daily-track',
	templateUrl: './widget-daily-track.component.html',
	styleUrls: ['../dashboard.component.scss']
})

export class WidgetDailyTrackComponent implements OnInit {
	public showMenu = false;
	public activeOption;
	public options = [
		{
			id: 'doses-logged',
			name: 'Doses Captured'
		},
		{
			id: 'patient-non-compliance',
			name: 'Patient Non-Compliance'
		},
		{
			id: 'adherence-info',
			name: 'Adherence Info'
		}
	];

	constructor(private dashboardService: DashboardService) {
	}

    public ngOnInit() {
        let selectedOptionId = localStorage.getItem("DAILY_TRACK_OPTION");
        //if (selectedOptionId == undefined)
        //    selectedOptionId = state.dailyTrack;
		this.dashboardService.viewState.subscribe((state) => {
            let savedOption = this.options.filter((option) => option.id === selectedOptionId);
			this.activeOption = (savedOption[0]) ? savedOption[0] : this.options[0];
		});
	}

    public toggleMenuOption_DailyTrack(optionID): void {
        localStorage.setItem("DAILY_TRACK_OPTION", optionID);
		this.showMenu = false;
		this.activeOption = this.options.filter((option) => option.id === optionID)[0];
		//this.dashboardService.setDashboardStateValue('dailyTrack', this.activeOption.id);
	}

    public toggleMenu_DailyTrack(): void {
		this.showMenu = !this.showMenu;
	}

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-menu-daily') {
			this.showMenu = false;
		}
	}
}
