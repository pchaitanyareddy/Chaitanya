import { Component, HostListener, OnInit } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
	selector: 'widget-dosage-adherence',
    templateUrl: './widget-dosage-adherence.component.html?v=${new Date().getTime()}',
    styleUrls: ['./widget-dosage-adherence.component.scss?v=${new Date().getTime()}']
})

export class WidgetDosageAdherenceComponent implements OnInit {
	public showMenu = false;
    public activeOption: any;
    public defaultOption_DAdh: string;
    public selectedOption: string;
	public options = [
		{
			id: 'daily',
			name: 'Daily'
		},
		{
			id: 'weekly',
			name: 'Weekly'
		},
		{
			id: 'monthly',
			name: 'Monthly'
		}
    ];

    public options1 = [
        {
            id: 'DosageAdherence',
            name: 'Dosage Adherence'
        },
        {
            id: 'PatientMinimumAdherence',
            name: 'Patient Minimum Adherence'
        }
        //      ,
        //{
        //	id: 'monthly',
        //	name: 'Monthly'
        //}
    ];

	// Area graph values
	public chartData: any;
	public chartLabels = {
		daily: [
			'6D', '5D', '4D', '3D', '2D', 'Yday', 'Tday'
		],
		weekly: [
			'6W', '5W', '4W', '3W', '2W', 'Last week', 'This week'
		],
		monthly: [
			'6M', '5M', '4M', '3M', '2M', 'Last Month', 'This Month'
		]
	};
	public lineChartData: any[] = [
		{ data: [0, 0, 0, 0, 0, 0, 0], label: 'Adherence %' },
		{ data: [0, 0, 0, 0, 0, 0, 0], label: 'Target %' }
	];
	public lineChartLabels = [];

	// Graph setup
	public lineChartOptions: any = {
		responsive: true,
		maintainAspectRatio: false,
		scales: {
			yAxes: [{
				display: true,
				ticks: {
					stepValue: 10,
					max: 100
				}
			}]
		},
	};
	public lineChartColors: any[] = [
		{ // purple
			backgroundColor: 'rgba(127,63,152,0)',
			borderColor: 'rgba(127,63,152,1)',
			pointBackgroundColor: 'rgba(127,63,152,1)',
			pointBorderColor: '#fff',
			pointHoverBackgroundColor: '#fff',
			pointHoverBorderColor: 'rgba(127,63,152,0.8)'
		},
		{ // green
			backgroundColor: 'rgba(26,187,156,0)',
			borderColor: 'rgba(26,187,156,1)',
			pointBackgroundColor: 'rgba(26,187,156,1)',
			pointBorderColor: '#fff',
			pointHoverBackgroundColor: '#fff',
			pointHoverBorderColor: 'rgba(26,187,156,1)'
		}
	];
	public lineChartLegend: boolean = true;
	public lineChartType: string = 'line';

	constructor(private dashboardService: DashboardService) {
	}

    public ngOnInit() {
        
        this.selectedOption = 'DosageAdherence';
        $('#spnGraphTitle').html('Dosage Adherence');
		this.dashboardService.viewState.subscribe((state) => {
			let savedOption = this.options.filter((option) => option.id === state.dosageAdherence);
			this.activeOption = (savedOption[0]) ? savedOption[0] : this.options[1];
			this.lineChartLabels = this.chartLabels[this.activeOption.id];
		});

		this.dashboardService.dosageHistory.subscribe((value) => {
			if (value) {
				this.chartData = value;
                this.toggleMenuOption_DosageAdherence('daily', 'DosageAdherence',false, false);
			}
        });
        this.defaultOption_DAdh = 'Daily';
        //$('ul#pnlRightMenu').find('li.active').data('interest');
        
        if (localStorage.getItem("SELECTED_DASHBOARD_TRIAL") == "undefined" || localStorage.getItem("SELECTED_DASHBOARD_TRIAL") == "all")
        $("#anchOption_PatientMinimumAdherence").css("display", "none");
    }

    public ngAfterViewInit(): void {
        
        if (localStorage.getItem("SELECTED_DASHBOARD_TRIAL") == "undefined" || localStorage.getItem("SELECTED_DASHBOARD_TRIAL") == "all")
        $("#anchOption_PatientMinimumAdherence").css("display", "none");
    }
   

    public toggleMenuOption_DosageAdherence(optionID, selectedOption: string, updateServer?: boolean, isClicked?: boolean): void {
       
        if (optionID == "daily") {
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Weekly"]').prop('checked', false);
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Monthly"]').prop('checked', false);
        }
        else if (optionID == "weekly") {
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Daily"]').prop('checked', false);
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Monthly"]').prop('checked', false);
        }
        else if (optionID == "monthly") {
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Daily"]').prop('checked', false);
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Weekly"]').prop('checked', false);
        }

        this.showMenu = false;
        if (!isClicked)
            this.activeOption = this.options.filter((option) => option.id === optionID)[0];
        else {
            //alert(optionID);
            this.activeOption = this.options1.filter((option) => option.id === optionID)[0];
        }

		if (updateServer !== false) {
			this.dashboardService.setDashboardStateValue('dosageAdherence', this.activeOption.id);
		}
        if (selectedOption == 'DosageAdherence') {
            this.lineChartLabels = this.chartLabels[this.activeOption.id];
            setTimeout(() => {
                this.lineChartData = [
                    { data: this.chartData[this.activeOption.id].adherence, label: 'Adherence %' },
                    { data: this.chartData[this.activeOption.id].target, label: 'Target %' }
                ];
            });
        }
        else if (selectedOption == 'PatientMinimumAdherence') {
            this.lineChartLabels = this.chartLabels[this.activeOption.id];
            setTimeout(() => {
                this.lineChartData = [
                    { data: this.chartData[this.activeOption.id].patient_adherence_target, label: 'Adherence %' },
                    { data: this.chartData[this.activeOption.id].target, label: 'Target %' }
                ];
            });
        }
	}

    public toggleMenu_DosageAdherence(): void {
        this.showMenu = !this.showMenu;
       
    }

    dropdownChangeEvent(selectedValue) {
        this.selectedOption = selectedValue;
        if (selectedValue == 'PatientMinimumAdherence')
        {
            $('#spnGraphTitle').html('Patient Minimum Adherence');
            this.dashboardService.viewState.subscribe((state) => {
                let savedOption = this.options.filter((option) => option.id === state.patientMinimumAdherence);
                this.activeOption = (savedOption[0]) ? savedOption[0] : this.options[1];
                this.lineChartLabels = this.chartLabels[this.activeOption.id];
            });

            this.dashboardService.dosageHistory.subscribe((value) => {
                if (value) {
                    this.chartData = value;
                    this.toggleMenuOption_DosageAdherence('daily', 'PatientMinimumAdherence',false, false);
                }
            });
            this.defaultOption_DAdh = 'Daily';

        }
        else if (selectedValue == 'DosageAdherence') {
            $('#spnGraphTitle').html('Dosage Adherence');
            this.dashboardService.viewState.subscribe((state) => {
                let savedOption = this.options.filter((option) => option.id === state.dosageAdherence);
                this.activeOption = (savedOption[0]) ? savedOption[0] : this.options[1];
                this.lineChartLabels = this.chartLabels[this.activeOption.id];
            });

            this.dashboardService.dosageHistory.subscribe((value) => {
                if (value) {
                    this.chartData = value;
                    this.toggleMenuOption_DosageAdherence('daily', 'DosageAdherence', false, false);
                }
            });
            this.defaultOption_DAdh = 'Daily';

        }

    }

    selected(selectedValue) {

        if (selectedValue == "daily") {
           
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Weekly"]').prop('checked', false);
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Monthly"]').prop('checked', false);
        }
        else if (selectedValue == "weekly") {
            
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Daily"]').prop('checked', false);
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Monthly"]').prop('checked', false);
        }
        else if (selectedValue == "monthly") {
            
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Daily"]').prop('checked', false);
            $('input:radio[id="pnlDosageAdherenceRadBtns"][name="Weekly"]').prop('checked', false);
        }


        this.showMenu = false;
        //this.activeOption = this.options1.filter((option) => option.id === optionID)[0];
        //if (updateServer !== false) {
        //    this.dashboardService.setDashboardStateValue('dosageHistory', this.activeOption.id);
        //}
        //Code added by ramesh on 19th Mar 2018
        
        if (this.selectedOption == 'DosageAdherence') {
            this.lineChartLabels = this.chartLabels[selectedValue];
            setTimeout(() => {
                this.lineChartData = [
                    { data: this.chartData[selectedValue].adherence, label: 'Adherence %' },
                    { data: this.chartData[selectedValue].target, label: 'Target %' }
                ];
            });

        }
        else if (this.selectedOption == 'PatientMinimumAdherence') {
            this.lineChartLabels = this.chartLabels[selectedValue];
            setTimeout(() => {
                this.lineChartData = [
                    { data: this.chartData[selectedValue].patient_adherence_target, label: 'Adherence %' },
                    { data: this.chartData[selectedValue].target, label: 'Target %' }
                ];
            });
        }

    }

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-menu-da') {
			this.showMenu = false;
		}
	}
}
