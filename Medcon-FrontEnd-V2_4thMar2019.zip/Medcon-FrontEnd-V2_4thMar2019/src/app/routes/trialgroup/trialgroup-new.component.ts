﻿import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialGroupService } from '../../services/trialgroup.service';
import { SettingsService } from '../../services/settings.service';
import { Customer } from '../../models/customer';
import { TrialGroupRequest } from '../../requests/trialgroup-request';
import { Site } from '../../models/site';
import {TrialGroup} from  '../../models/trailgroup';
import { Observable } from 'rxjs/Observable';

@Component({
    templateUrl: './trialgroup-new.component.html?v=${new Date().getTime()}'
})

export class TrialGroupNewComponent implements OnInit {
    public form: FormGroup;
    public showErrors: boolean;
    public customer: Customer;
    public sites: Site[];
    public userId: TrialGroup;
    public trailCount: number;
    public successMessage: string;
    public errorMessage: string;
    isLoading: boolean;
   

    constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        public router: Router,
        private fb: FormBuilder,
        private trialGroupService: TrialGroupService,
        private settingsService: SettingsService) {
    }

    public ngOnInit(): void {
        this.isLoading = false;
        this.customer = this.route.snapshot.data['customer'];
        this.sites = this.route.snapshot.data['sites'];
      
        this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));



        this.trailCount = Number(this.route.snapshot.params['trailCount'])

        this.form = this.fb.group({
            trialGroupName: ['', Validators.required]

            
        });
    }

    public onSubmit() {
        var trialGroupNameCheck = this.form.value.trialGroupName.trim();
       
        if (this.form.invalid) {
            this.showErrors = true;
        }
        else if (trialGroupNameCheck == '') {
            this.errorMessage = "Please enter valid Trial Group Name"
            this.form.controls['trialGroupName'].setValue('');
            $(window).scrollTop(5);
        }else {
            this.isLoading = true;
            let request = new TrialGroupRequest(
                trialGroupNameCheck,
                this.userId
            );
            
            this.trialGroupService.createTrialGroup(request, Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.form.markAsPristine();
                    this.successMessage = "Successfully Created TrailGroup ";
                    this.goBack();
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                });
        }
    }

    public alertClosed(): void {
        this.errorMessage = null;
    }

    public goBack(): void {
        this.isLoading = true;
        this.form.markAsPristine();
       
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'trialgroup']);
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.form.dirty;
    }

    

    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }
}
