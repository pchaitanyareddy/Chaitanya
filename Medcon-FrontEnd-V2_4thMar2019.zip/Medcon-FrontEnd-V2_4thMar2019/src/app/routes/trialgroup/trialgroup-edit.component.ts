﻿import { Component, HostListener, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import 'rxjs/add/operator/switchMap';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { TemplateService } from '../../services/template.service';
import { TrialGroupService } from '../../services/trialgroup.service';
import { TrialGroup } from '../../models/trialgroup';
import { UserRole } from '../../models/userrole';
import { TrialGroupRequest } from '../../requests/trialgroup-request';
import { Observable } from 'rxjs/Observable';
import _ from 'lodash';

@Component({
    templateUrl: './trialgroup-edit.component.html?v=${new Date().getTime()}'
    
})

export class TrialGroupEditComponent implements OnInit {
    public deleteType: string;
    public deleteObject: any;
    public trialGroup: TrialGroup;
    public trailGroupName: TrialGroup;
    public containerLimit = 5;
    public activeContainer: Object;
    public trialGroupEdit: FormGroup;
    public dataMatrixCodes = [];
    public showErrors: boolean;
    public error: any;
    public assignDrugRegimenError: String;
    public assignDrugRegimenSuccess: boolean;
    public drugRegimenPairs = [];
    public userId: UserRole;
    public UserRole: typeof UserRole = UserRole;
    public sites: Site[];
    public successMessage: string;
    public errorMessage: string;
    public durationError: boolean;
    public earlyDosingThreshholdError: boolean;
    public days = [];
    public hours = [];
    public minutes = [];
    public trailGroupId: number;
    public trailCount: number;
    isLoading: boolean;
    loggedInUserId: number;
    public createdDateOptions: IMyOptions = {
        dateFormat: 'mm/dd/yyyy',
    };
    
    constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        private router: Router,
        private fb: FormBuilder,
        private trialGroupService: TrialGroupService,
        private changeDetectorRef: ChangeDetectorRef) {
    }

    public ngOnInit(): void {
        this.isLoading = false;
      
        let createdDate = new Date();
        let day = createdDate.getDate();
        let month = createdDate.getMonth() + 1;
        let year = createdDate.getFullYear();
        let today = year + '-' + month + '-' + day;
        //End

       
        this.trialGroup = this.route.snapshot.data['trialGroup'];
        this.userId = Number(this.route.snapshot.params['customer_id'])
        this.loggedInUserId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'));
        this.trailGroupId = Number(this.route.snapshot.params['id'])
        

        
        
        var createDate = this.trialGroup.createdDate.split("/"); //ex: 03/31/2018
        var trialGroupStartDate = createDate[2] + '-' + createDate[0] + '-' + createDate[1]; //2018-01-03
        
        this.trialGroupEdit = this.fb.group({
            
            trialGroupName: [this.trialGroup.trialGroupName, Validators.required],
            createdBy: [this.trialGroup.createdBy],
            createdDate: [this.dateForView(trialGroupStartDate)],
        });

        // Make sure start date can't come after end date
      

        let copy: IMyOptions = this.getCopyOfDateOptions(this.createdDateOptions);
        copy.componentDisabled = true;
        this.createdDateOptions = copy;
    }

    

    public cancelForm(): void {
        this.isLoading = true;
        this.trialGroupEdit.markAsPristine();
        this.router.navigate([this.userId, 'trialgroup']);
    }

   

    public onSubmit() {
        var trialGroupNameCheck = this.trialGroupEdit.value.trialGroupName.trim();
        if (this.trialGroupEdit.invalid) {
            this.showErrors = true;
        }
        else if (trialGroupNameCheck == '') {
            this.errorMessage = "Please enter valid Trial Group Name"
            this.trialGroupEdit.controls['trialGroupName'].setValue('');
            $(window).scrollTop(5);
        }
        else {
            this.isLoading = true;
            let request = new TrialGroupRequest(
                
                trialGroupNameCheck,
                Number(this.loggedInUserId)
                
               
            );

            this.trialGroupService
                .updateTrialGroup(this.trailGroupId, request)
                .subscribe(
                (response) => {
                    this.isLoading = false;
                    this.trialGroupEdit.markAsPristine();
                    this.successMessage = 'Trial Group has been successfully updated';
                    this.goBack();
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                }
                );
        }
    }


    public drugSelected(drug): void {
        this.assignDrug = drug.item;
    }

    public regimenSelected(regimen): void {
        this.assignRegimen = regimen.item;
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
        this.assignDrugRegimenSuccess = false;
        this.assignDrugRegimenError = null;
        this.error = null;
    }

    public onDateChange(event: IMyInputFieldChanged, field): void {
        let d = event.value.split('/');
        let date = this.dateForView(d[2] + '-' + d[0] + '-' + d[1]);

        if (event.valid) {
               this.setStartDateDisableSince(date.date);
            
        }
    }

    private dateForView(date: string): any {
        let stripZero = ((value) => {
            return (value < 9) ? value.replace('0', '') : value;
        });

        if (date) {
            let d = date.split('-');
            return { date: { year: d[0], month: stripZero(d[1]), day: stripZero(d[2]) } };
        } else {
            return '';
        }
    }
    
    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.trialGroupEdit.dirty;
    }

    private setStartDateDisableSince(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.createdDateOptions);
        copy.disableSince = date;
        this.createdDateOptions = copy;
    }

    private getCopyOfDateOptions(date): IMyOptions {
        return JSON.parse(JSON.stringify(date));
    }

    private setEndDateDisableUntil(date) {
        let copy: IMyOptions = this.getCopyOfDateOptions(this.endDateOptions);
        copy.disableUntil = date;
        this.endDateOptions = copy;
    }

    public goBack(): void {
        this.trialGroupEdit.markAsPristine();
        this.router.navigate([this.userId, 'trialgroup']);
    }
  
    private convertDate(date: any): string {
        return (date) ? date.year + '-' + date.month + '-' + date.day : '';
    }

   

    resetData()
    {

        this.ngOnInit();
    }

    
}
