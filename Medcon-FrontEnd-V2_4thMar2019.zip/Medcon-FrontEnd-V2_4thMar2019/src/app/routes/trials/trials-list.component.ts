import { Component, OnInit, ViewChild, AfterViewInit,Inject,HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LocationStrategy } from '@angular/common';
import { URLSearchParams } from '@angular/http';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { Trial } from '../../models/trial';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { TrialService } from '../../services/trial.service';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
import { DOCUMENT } from "@angular/platform-browser";
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './trials-list.component.html?v=${new Date().getTime()}'
})

export class TrialsListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public trials: Pagination<Trial>;
    //public UserRole: typeof UserRole = UserRole;
    //public currentUserRole: UserRole;
    public customer: Customer;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public deleteContainers: string;
    public deletePatients: string;
    public trialToDelete: Trial;

    public maxSize: number = 5;
    public currentPage: number = 1;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    selectedCompanyId: number;
    isLoading: boolean;
    errorMessage_DtableError: string;
    errorCount: number;
    endTime: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private router: Router,
        private customerService: CustomerService,
        private reportService: ReportService,
        private privilegesService: PrivilegesService,
        private url: LocationStrategy,
        private cognitoUtil: CognitoUtil,
        private trialService: TrialService,
        @Inject(DOCUMENT) private document: Document
    ) {
    }
    //@HostListener("document:click", ['$event'])
    //onDocumentClick(event: Event): void {
    //    alert('dsadasd');

    //        $("#check").click(function ($event) {
    //            this.show = !this.show
    //    if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
    //        this.errorMessage_DtableError = "Company is changed so page is refreshing..."
    //       this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/trials', '');
    //        location.reload();

    //    }
    //    });

        
    //    //this.show = !this.show
    //    //if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
    //    //    this.errorMessage_DtableError = "Company is changed so page is refreshing..."
    //    //    this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/trials', '');
    //    //    location.reload();

    //    //}
    //}

    trialReload()
    {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            this.errorMessage_DtableError = "Company is changed so page is refreshing..."
           this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/trials', '');
            location.reload();

        }

    }

    
    public ngOnInit(): void {
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.endTime = this.reportService.getTokenEndTime();
        this.errorCount = 0;
        this.isLoading = false;
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        this.privileges = this.route.snapshot.data['privileges'];
        //this.currentUserRole = this.route.snapshot.data['role'];
        //this.customer = this.route.snapshot.data['customer'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.privilegesList = this.privileges;
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Trials')

        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        localStorage.setItem('IS_ALLOWED_TO_VIEW', this.privilegesByModule[0].view);
        localStorage.setItem('IS_ALLOWED_TO_ADD', this.privilegesByModule[0].add);

        //4th Jan 2019
        this.updateBulkContainerStatus();
    }

    public updateBulkContainerStatus()
    {

        this.trialService
            .updateBulkContainerStatus()
            .subscribe(
            (response) => {
                
            },
            (err) => {
               
            }
            );
    }

    public ngAfterViewInit(): void {
        

        this.loadTrialsList();
    }

    public viewTrial(trial): void {
        this.router.navigate(['/', this.selectedCustomerId, 'trials', trial.id, 'view']);
    }

    public customerChanged(): void {
        this.trialService.getTrials(this.selectedCustomerId, null, null).subscribe((trials) => {
            this.trials = trials;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/trials', '');
        });
    }

    

    public hideDeleteModal(): void {
        this.trialToDelete = null;
        this.deleteModal.hide();
    }

    public confirmDelete(): void {
        this.isLoading = true;
        let trial = this.trialToDelete;
        this.trialService
            .deleteTrial(Number(localStorage.getItem('ID')))
            .subscribe(
            (response) => {
              
                this.successMessage = 'trial has been successfully deleted';
                this.isLoading = false;
                $("#datatable_trialList").dataTable().fnDestroy();
                this.loadTrialsList();
            },
            (err) => {
                this.isLoading = false;
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.trialService.getTrials(event.page, event.itemsPerPage).subscribe((trials) => this.trials = trials);
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public formatDate(date: string): string {
        return this.trialService.formatDate(date);
    }

    performDataTableRefresh() {
        //alert(localStorage.getItem("IS_TOKEN_EXPIRED"));
        this.reportService.isTokenExpired(this.endTime,'TrialsList');
        if (localStorage.getItem("TrialsList_IS_TOKEN_EXPIRED") == 'Y') {
            //alert('Expired');
            localStorage.setItem("TrialsList_IS_TOKEN_EXPIRED", "N");
            this.endTime = this.reportService.getTokenEndTime();
            this.reportService.isTokenExpired(this.endTime,'TrialsList');
            $(window).scrollTop(5);
            this.errorMessage_DtableError = "Refreshing page...";
            $("#pnlAlertWarning").css("display", "block");
            setTimeout(function () {
                $('#pnlAlertWarning').fadeOut('fast');
            }, 3000);
            //alert('Refreshing page...');
            this.loadTrialsList();
            //this.authorizationToken = self.getNewIdToken();
        }

    }

    public loadTrialsList(): void {
     
        $("#datatable_trialList").dataTable().fnDestroy();


        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                
                $('#datatable_trialList')
                    .on('order.dt', function () {

                        //self.performDataTableRefresh();

                    })
                    .on('search.dt', function () {
                        //alert('search');
                        //self.performDataTableRefresh();
                    })
                    .on('page.dt', function () {

                        //self.performDataTableRefresh();

                    })
                    .DataTable({
                    
                    "processing": true,
                    "serverSide": true,
                    "stateSave": true,
                    stateSaveParams: function (settings, data) {
                        delete data.search;
                        data.start = 0;
                    },
                    "rowId": "Id",
                    'ajax': {
                        //'url': 'https://jkoaqep6tf.execute-api.us-east-1.amazonaws.com/dev/trial/list/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'url': CommonService.API_PATH_V2_TRIAL_LIST+'trial/list/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        error: function (xhr, error, code) {
                            //self.errorCount = self.errorCount + 1;
                            //if (self.errorCount == 1 && (xhr.status == 0 || xhr.status == 401)) {
                            //    $(window).scrollTop(5);
                            //    self.errorMessage_DtableError = "Refreshing page...";
                            //    $("#pnlAlertWarning").css("display", "block");
                            //    setTimeout(function () {
                            //        $('#pnlAlertWarning').fadeOut('fast');
                            //    }, 3000);
                            //    self.loadTrialsList();
                            //}
                            //else {
                            //    let errorMessage = '';
                            //    if (xhr.responseJSON != undefined)
                            //        errorMessage = xhr.responseJSON.message;
                            //    else
                            //        errorMessage = 'Server error occured';
                            //    self.errorMessage = errorMessage;
                            //    $('.dataTables_processing', $('#datatable_trialList').closest('.dataTables_wrapper')).hide();
                            //}
                        }
                    }
                    
                    ,
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_TRIAL_LIST + 'trial/list/' + localStorage.getItem('GLOBAL_COMPANY_ID') + '?draw=1&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=startDate&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=endDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=labelsUsed&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=males&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=females&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=containers&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=status&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=false&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=Id&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=true&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B9%5D%5Bdata%5D=9&columns%5B9%5D%5Bname%5D=&columns%5B9%5D%5Bsearchable%5D=true&columns%5B9%5D%5Borderable%5D=false&columns%5B9%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B9%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() + '&search%5Bregex%5D=false&_=1535094371654'
                                self.reportService.ExportAll(apiUrl, 'Trial List');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0,1,2,3,4,5,6,7]
                            }
                        }

                    ],
                    
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "trialName" },
                        { "data": "startDate" },
                        { "data": "endDate" },
                        { "data": "labelsUsed" },
                        { "data": "males" },
                        { "data": "females" },
                        { "data": "containers" },
                        { "data": "status" },
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                               
                                var endDate = new Date(full.endDate);
                                var todayDate = new Date();
                                var trailStatus = todayDate < endDate


                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0 && trailStatus == false) {
                                        
                                        localStorage.setItem(full.Id+"_ViewTrial", "ViewTrial");
                                        
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/ViewTrial\"  title=\"Cannot Edit this Trial as it is already completed\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it has already deleted\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                    else if (full.status == 0) {
                                        localStorage.setItem(full.Id + "_ViewTrial", "ViewTrial");
                                       
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/ViewTrial\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it has already deleted\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                    else if (full.containers > 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already containers associated with it \"  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                    else if (full.containers == 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a><div id=\"disableDelete\"><button  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                    }
                                  
                                    else {
                                        localStorage.setItem(full.Id+"_ViewTrial", "ViewTrial");
                                        
                                        return "<div  class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/ViewTrial\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a><div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already completed\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script><div> </div>";
                                        
                                    }



                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if ((full.status == 0 || full.status==1) && trailStatus == false) {
                                        
                                        localStorage.setItem(full.Id + "_ViewTrial", "ViewTrial");
                                        
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/ViewTrial\"  title=\"Cannot Edit this Trial as it is already completed\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a></div>";
                                    }
                                    else if (full.containers > 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    else if (full.status == 0) {
                                        localStorage.setItem(full.Id + "_ViewTrial", "ViewTrial");
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/ViewTrial\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a></div>";
                                        
                                    }
                                    else if (full.containers == 0 && trailStatus == true) {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                    }
                                   
                                    else {
                                        return "<div  class=\"btn-action\"><a disabled title=\"Cannot Edit this Trial as it is already completed\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it has already deleted\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script></div> ";
                                    }
                                    else if (full.containers > 0 && trailStatus == true) {
                                        return "<div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already containers associated with it\"  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script> </div>";
                                    }
                                    else if (full.containers == 0 && trailStatus == true) {
                                        return "<div id=\"disableDelete\"><button  onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                   
                                    else {
                                        return "<div id=\"disableDelete\"><button disabled title=\"Cannot Delete this Trial as it is already completed\" onclick=\"DeleteFn('" + full.Id + "')\" id=\"" + full.Id + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(Id){  localStorage.setItem('ID', String(Id)); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script></div>";
                                    }
                                    
                                }
                                else if (Number(localStorage.getItem("IS_ALLOWED_TO_VIEW")) == 1  && Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0)
                                {
                                    
                                    localStorage.setItem(full.Id + "_ViewTrial", "ViewTrial");
                                    
                                    return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/trials/" + full.Id + "/ViewTrial\"   class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</a></div>";
                                }
                                else
                                {

                                    return "";
                                }
                            }
                        }

                    ],
                    "columnDefs": [

                        
                        {
                            "targets": [7],
                            "orderable": false,
                            render: function (data, type, row) {

                                var startDate = new Date(row.startDate);
                                var endDate = new Date(row.endDate);
                                var todayDate = new Date();
                                
                                if (startDate <= todayDate && todayDate <= endDate && row.status == 1) {
                                    return "<span class=\"btn-xs trial-status complete\" title=\"Active\">A</span>";

                                }
                                if (todayDate > endDate && row.status == 1) {
                                    return "<span class=\"btn-xs trial-status active\" title=\"Complete\">C</span>";

                                }
                                if (todayDate < startDate && row.status == 1) {
                                    return "<span class=\"btn-xs trial-status pending\" title=\"Pending\" >P</span>";

                                }
                                if (row.status == 0)
                                {
                                    return "<span class=\"btn-xs trial-status inactive\" title=\"Inactive\">I</span>";
                                }
                                
                            }
                        }
                    ],
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,

                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    }
                });
            }
        });


        $('#datatable_trialList tbody').on("click", 'tr', function (evt) {
            
            if (!$(evt.target).is("button") && !$(evt.target).is("a")) {
                var attId = $(this).attr('id');
                
                
                self.viewTrial_V2(attId);

            }

            if ($(evt.target).is("a") && $(evt.target).is('[disabled]') == false) {
                self.isLoading = true;
            }

        });


    }

    public viewTrial_V2(id): void {
        
        if (id != undefined) {
            this.isLoading = true;
            this.router.navigate(['/', this.selectedCompanyId, 'trials', id, 'view']);
        }
    }

    public ExportAll(): void {

        this.trialService.ExportAll();
    }
}
