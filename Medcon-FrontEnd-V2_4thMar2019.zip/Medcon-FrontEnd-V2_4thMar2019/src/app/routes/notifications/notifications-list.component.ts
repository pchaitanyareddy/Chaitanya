﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { NotificationsService } from '../../services/notifications.service';
import { Notifications } from '../../models/notifications';
import { NotificationsRequest } from '../../requests/notifications-request';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
import { Privileges } from '../../models/privileges';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './notifications-list.component.html?v=${new Date().getTime()}',
    styleUrls: ['./trial-edit.component.scss?v=${new Date().getTime()}']
})

export class NotificationsListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('patientAlertsHelpModal') public patientAlertsHelpModal: ModalDirective;
    public Notifications: Pagination<Notifications>;
    public notificationToDelete: Notifications;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public showErrors: boolean;
    public selectedCustomerId: number;
    public successMessage: string;
    public trailList: any;
    public allTrailsList: any;
    public errorMessage: string;
    public notification: FormGroup;
    public trial: Notifications;
    public userId: number;
    privilegesByModule: any;
    privilegesList: any;
    selectedTrialId: number;
    selectedNotificationID: number;
    selectedNotificationIDToDelete: number;
    public selectedTrial: any;
    public trailId: number;
   
    isNewForm: boolean;
    isEditForm: boolean;
    public maxSize: number = 5;
    public currentPage: number = 1;
    notificationsList: any;
    trialNotifications: any[];
    isLoading: boolean;
    loggedInUserId: number;
    public privileges: Privileges;
    selectedCompanyId: number;
    errorMessage_DtableError: string;
    errorCount: number;
    endTime: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private reportService: ReportService,
        private NotificationsService: NotificationsService,
        private fb: FormBuilder,
        private cognitoUtil: CognitoUtil,
        public router: Router,
        private url: LocationStrategy) {
        
    }
    public goBack(): void {
        this.addNewEditCheckOptions();
        this.loadDefaultValues();

        $('#pnlNotificationTypeEmail').removeClass("btn-group selected").addClass("btn-group");
        $('#pnlNotificationTypeSMS').removeClass("btn-group selected").addClass("btn-group");
    }
    public addNewEditCheckOptions(): void {
        $('#missedDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlMissedDose').removeClass("btn-group selected").addClass("btn-group");
        $('#overDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlOverDose').removeClass("btn-group selected").addClass("btn-group");
        $('#lateDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlLateDose').removeClass("btn-group selected").addClass("btn-group");
        $('#underDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlUnderDose').removeClass("btn-group selected").addClass("btn-group");
        $('#excessiveManualDoseOccurrence').attr('disabled', 'disabled');
        $('#pnlExcessiveManualDose').removeClass("btn-group selected").addClass("btn-group");
       

    }

    public ngOnInit(): void {
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.endTime = this.reportService.getTokenEndTime();
        this.errorCount = 0;
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.userId = this.route.snapshot.params['customer_id'];
        this.trailId = Number(this.route.snapshot.params['id'])
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Notification')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }


        this.notificationsList = [
            
        ]

        this.loggedInUserId = Number(localStorage.getItem("GLOBAL_LOGGED_IN_USER_ID"));
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'))
    }

    notificationReload() {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            this.errorMessage_DtableError = "Company is changed so page is refreshing..."
            this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/notifications', '');
            location.reload();

        }
    }

    public ngAfterViewInit(): void {
       

        this.loadNotificationList();
        this.selectedCompanyId = Number(localStorage.getItem("GLOBAL_COMPANY_ID"));
    }

    public onSubmit(): void {
        this.showErrors = false;
        this.errorMessage = "";
        
        let notificationType;
        if (this.notification.value.chkNotificationTypeEmail && this.notification.value.chkNotificationTypeSMS) {
            notificationType = 3;
        }
        else if (this.notification.value.chkNotificationTypeSMS) {
            notificationType = 2;
        }
        else if (this.notification.value.chkNotificationTypeEmail) {
            notificationType = 1;
        }

        //Code added on 24th July 2018 to validate occurances value, if it is zero, then display validation error
        let isValid;
        isValid = true;
        let missedDoseChkValue = Number(this.notification.value.missedDose);
        let missedDoseOccurrence = Number(this.notification.value.missedDoseOccurrence);
        let overDoseChkValue = Number(this.notification.value.overDose);
        let overDoseOccurrence = Number(this.notification.value.overDoseOccurrence);
        let lateDoseChkValue = Number(this.notification.value.lateDose);
        let lateDoseOccurrence = Number(this.notification.value.lateDoseOccurrence);
        let underDoseChkValue = Number(this.notification.value.underDose);
        let underDoseOccurrence = Number(this.notification.value.underDoseOccurrence);
        let excessiveManualDoseChkValue = Number(this.notification.value.excessiveManualDose);
        let excessiveManualDoseOccurrence = Number(this.notification.value.excessiveManualDoseOccurrence);
        if ((missedDoseChkValue == 1 && missedDoseOccurrence == 0) || (overDoseChkValue == 1 && overDoseOccurrence == 0)
            || (lateDoseChkValue == 1 && lateDoseOccurrence == 0) || (underDoseChkValue == 1 && underDoseOccurrence == 0)
            || (excessiveManualDoseChkValue == 1 && excessiveManualDoseOccurrence == 0)) {

            isValid = false;
            this.showErrors = true;
            this.errorMessage = "Please enter Occurrences value higher than zero";
            this.isLoading = false;
            $(window).scrollTop(5);
        }
        
        if (missedDoseChkValue == 0 && overDoseChkValue == 0
             && lateDoseChkValue == 0 && underDoseChkValue == 0 
            && excessiveManualDoseChkValue == 0) {

            isValid = false;
            this.showErrors = true;
            this.errorMessage = "Please select atleast one subscription";
            this.isLoading = false;
            $(window).scrollTop(5);
        }


        //End 24th July 2018
        
         
        if (this.notification.invalid) {
            this.showErrors = true;
            this.errorMessage ="Errors While Adding new Notifications";
        }
        else if (String(this.selectedTrialId) == 'NaN' || this.selectedTrialId == undefined) {

            this.showErrors = true;
            this.errorMessage = "Please Select Trial"
        }
        
        else if (this.isNewForm == true) {
            
            
            if (isValid) {
                
                this.isLoading = true;
                let request = new NotificationsRequest(
                   
                    this.notification.value.listOfTrails,
                    Number(this.notification.value.missedDose),
                    Number(this.notification.value.missedDoseOccurrence),
                    Number(this.notification.value.overDose),
                    Number(this.notification.value.overDoseOccurrence),
                    Number(this.notification.value.lateDose),
                    Number(this.notification.value.lateDoseOccurrence),
                    Number(this.notification.value.underDose),
                    Number(this.notification.value.underDoseOccurrence),
                    Number(this.notification.value.excessiveManualDose),
                    Number(this.notification.value.excessiveManualDoseOccurrence),
                    notificationType
                    
                );
                this.NotificationsService.createNotifications(this.selectedTrialId, request).subscribe(
                    (response) => {
                        this.notification.markAsPristine();
                        this.isLoading = false;
                        this.successMessage = "successfully Added ";
                        
                        $("#datatable_notification").dataTable().fnDestroy();
                        this.loadNotificationList();
                        this.notification.reset();
                        this.clearDataCSS();
                        this.addNewEditCheckOptions();

                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });

            }


        }

        else {
            if (isValid) {
                this.isLoading = true;
                let request = new NotificationsRequest(
                    
                    this.notification.value.listOfTrails,
                    Number(this.notification.value.missedDose),
                    Number(this.notification.value.missedDoseOccurrence),
                    Number(this.notification.value.overDose),
                    Number(this.notification.value.overDoseOccurrence),
                    Number(this.notification.value.lateDose),
                    Number(this.notification.value.lateDoseOccurrence),
                    Number(this.notification.value.underDose),
                    Number(this.notification.value.underDoseOccurrence),
                    Number(this.notification.value.excessiveManualDose),
                    Number(this.notification.value.excessiveManualDoseOccurrence),
                    notificationType
                    
                );
                let recordId = Number(localStorage.getItem('RECORD_ID'));
                this.NotificationsService.updateNotifications(this.selectedTrialId, request, recordId).subscribe(
                    (response) => {
                        this.isLoading = false;
                        this.notification.markAsPristine();

                        this.successMessage = "successfully Added ";
                       
                        $("#datatable_notification").dataTable().fnDestroy();
                        this.loadNotificationList();
                        
                    },
                    (err) => {
                        this.isLoading = false;
                        this.errorMessage = err;
                    });
            }


        }
    }




   

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    public deleteItem(id): void {
        this.selectedNotificationIDToDelete = id;
        this.deleteModal.show();
        this.isLoading = false;
    }

    public hideDeleteModal(): void {
        this.notificationToDelete = null;
        this.deleteModal.hide();
    }

    public confirmDelete(): void {
        this.isLoading = true;
        let recordId = Number(localStorage.getItem('RECORD_ID'));
        this.NotificationsService
            .deleteNotifications(this.selectedNotificationIDToDelete, recordId)
            .subscribe(
            (response) => {
                
                this.successMessage = "successfully deleted";
                this.hideDeleteModal();
                
                this.isLoading = false;
                $("#datatable_notification").dataTable().fnDestroy();
                this.loadNotificationList();
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }
    onChange_State(selectedValue) {
        this.selectedTrialId = Number(selectedValue);
        this.selectedTrial = null;
       
        if (this.allTrailsList != null) {
            for (var i = 0; i < this.allTrailsList.length; i++) {
                if (this.allTrailsList[i].id == this.selectedTrialId) {
                    this.selectedTrial = this.allTrailsList[i].name;
                }
            }

        }

    }

    public editNotification(id): void {
        if (id != 'undefined') {
            this.isLoading = true;
            this.router.navigate(['/', this.selectedCompanyId, 'notifications', id, 'edit']);
        }
        
        

    }
    public clearDataCSS() {
        $("#pnlMissedDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlOverDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlUnderDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlLateDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlExcessiveManualDose").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlNotificationTypeEmail").removeClass("btn-group selected").addClass("btn-group");
        $("#pnlNotificationTypeSMS").removeClass("btn-group selected").addClass("btn-group");
    }

    performDataTableRefresh() {
        this.reportService.isTokenExpired(this.endTime,'NotificationList');
        if (localStorage.getItem("NotificationList_IS_TOKEN_EXPIRED") == 'Y') {
            //alert('Expired');
            localStorage.setItem("NotificationList_IS_TOKEN_EXPIRED", "N");
            this.endTime = this.reportService.getTokenEndTime();
            this.reportService.isTokenExpired(this.endTime,'NotificationList');
            $(window).scrollTop(5);
            this.errorMessage_DtableError = "Refreshing page...";
            $("#pnlAlertWarning").css("display", "block");
            setTimeout(function () {
                $('#pnlAlertWarning').fadeOut('fast');
            }, 3000);
            //alert('Refreshing page...');
            this.loadNotificationList();
            //this.authorizationToken = self.getNewIdToken();
        }

    }

    public loadNotificationList(): void {
        $("#datatable_notification").dataTable().fnDestroy();
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {
                
                this.authorizationToken = token;
                
                $('#datatable_notification')
                    .on('order.dt', function () {

                        //self.performDataTableRefresh();

                    })
                    .on('search.dt', function () {
                        //alert('search');
                        //self.performDataTableRefresh();
                    })
                    .on('page.dt', function () {

                        //self.performDataTableRefresh();

                    })
                    .DataTable({
                    "processing": true,
                    "serverSide": true,
                    "stateSave": true,
                    stateSaveParams: function (settings, data) {
                        delete data.search;
                        data.start = 0;
                    },
                    'ajax': {
                        
                        
                        'url': CommonService.API_PATH_V2_GET_LIST_NOTIFICATION+'notifications/all?companyId=' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                       
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        error: function (xhr, error, code) {
                            //self.errorCount = self.errorCount + 1;
                            //if (self.errorCount == 1 && (xhr.status == 0 || xhr.status == 401)) {
                            //    $(window).scrollTop(5);
                            //    self.errorMessage_DtableError = "Refreshing page...";
                            //    $("#pnlAlertWarning").css("display", "block");
                            //    setTimeout(function () {
                            //        $('#pnlAlertWarning').fadeOut('fast');
                            //    }, 3000);
                            //    self.loadNotificationList();
                            //}
                            //else {

                            //    let errorMessage = '';
                            //    if (xhr.responseJSON != undefined)
                            //        errorMessage = xhr.responseJSON.message;
                            //    else
                            //        errorMessage = 'Server error occured';
                            //    self.errorMessage = errorMessage;
                            //    $('.dataTables_processing', $('#datatable_notification').closest('.dataTables_wrapper')).hide();
                            //}
                        }
                    }
                    
                    ,
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2,3, 4, 5]
                            },
                             action: function () {
                                 let apiUrl = CommonService.API_PATH_V2_GET_LIST_NOTIFICATION + 'notifications/all?companyId=' + localStorage.getItem('GLOBAL_COMPANY_ID') + '&draw=1&columns%5B0%5D%5Bdata%5D=trialName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=userName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=email&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=subscriptions&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=notificationType&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=trialId&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=true&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B7%5D%5Bdata%5D=notifId&columns%5B7%5D%5Bname%5D=&columns%5B7%5D%5Bsearchable%5D=true&columns%5B7%5D%5Borderable%5D=true&columns%5B7%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B7%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B8%5D%5Bdata%5D=8&columns%5B8%5D%5Bname%5D=&columns%5B8%5D%5Bsearchable%5D=true&columns%5B8%5D%5Borderable%5D=false&columns%5B8%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B8%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=4&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1530788744083'
                                self.reportService.ExportAll(apiUrl, 'Notification List');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            }}

                    ],
                    "order": [[4, "desc"]],
                    "columns": [
                        { "data": "trialName" },
                        { "data": "userName" },
                        { "data": "email" },
                        
                        { "data": "subscriptions"},
                        { "data": "notificationType" },
                       
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                
                            
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Notification Already Deleted\" disabled  id=\"" + full.trialId + "_edit_" + full.notifId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> <button title=\"Cannot Delete this Notification It is deleted already\" disabled id=\"" + full.trialId + "_deleteItem_" +  full.notifId +"\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_editItem_" + full.notifId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button><button  id=\"" + full.trialId + "_deleteItem_" + full.notifId+ "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Edit this Notification Already Deleted\" disabled  id=\"" + full.trialId + "_edit_" + full.notifId+ "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button> </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_editItem_" + full.notifId+ "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</button></div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"> <button title=\"Cannot Delete this Notification It is deleted already\" disabled id=\"" + full.trialId + "_deleteItem_" + full.notifId+ "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_deleteItem_" + full.notifId+ "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(iD){ localStorage.setItem('ID', companyId); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if ((self.currentUserRole == UserRole.CustomerUser) && Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0)
                                {
                                    return "<div class=\"btn-action\"><button  id=\"" + full.trialId + "_editItem_" + full.notifId+ "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> View</button> </div>";
                                }
                                else {
                                    return "";
                                }
                                
                            }

                        }


                    ]
                    ,
                    "columnDefs": [

                       
                        {
                            "targets": [4],
                            render: function (data, type, row) {
                                if (data == 1) {
                                    return 'Email'
                                }
                                else if (data == 2) {
                                    return 'SMS'
                                }
                                else {
                                    return 'Email, SMS'
                                }
                            }
                        }
                        
                    ]
                    , "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    }
                });
            }
        });
        $('#datatable_notification').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            var recordId = attId.split("_")[2];
            this.selectedNotificationIDToDelete = buttonId;
            localStorage.setItem('RECORD_ID', recordId);
            if (buttonName == "editItem")
            {
                self.editNotification(buttonId);
                self.isLoading = true;
            }
            if (buttonName == "deleteItem")
                self.deleteItem(buttonId);



        });

        


    }

    
    

    public loadDefaultValues(): void {

        this.notification = this.fb.group({

            listOfTrails: [''],
            missedDose: [''],
            txtMissedDose: [this.trialNotifications[0].message],
            missedDoseOccurrence: [''],
            overDose: [''],
            txtOverDose: [this.trialNotifications[1].message],
            overDoseOccurrence: [''],
            lateDose: [''],
            txtLateDose: [this.trialNotifications[2].message],
            lateDoseOccurrence: [''],
            underDose: [''],
            txtUnderDose: [this.trialNotifications[3].message],
            underDoseOccurrence: [''],
            excessiveManualDose: [''],
            txtExcesManualDose: [this.trialNotifications[4].message],
            excessiveManualDoseOccurrence: [''],
            chkNotificationTypeEmail: [''],
            chkNotificationTypeSMS: ['']
        });

    }

    public btnAddNewNotification(): void {
        
        if (!$('#datatable_processing').is(':visible')) {
            this.isLoading = true;
        }
        this.router.navigate(['/', this.selectedCompanyId, 'notifications', 'new']);
    }
}
