﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { ExportService } from '../../services/export.service';
import { Export } from '../../models/export';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { saveAs } from 'file-saver';
import { ReportService } from '../../services/report.service';
import { UserService } from '../../services/user.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './export-list.component.html?v=${new Date().getTime()}'
})

export class ExportListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public exports: Pagination<Export>;
    public UserRole: typeof UserRole = UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public user: any;
    public selectedCompanyId: any = 'all';
    public selectedCompany: string;
    public maxSize: number = 5;
    public currentPage: number = 1;
    exportList: any;
    privilegesByModule: any;
    privilegesList: any;
    companyList: any;
    public privileges: Privileges;
    public loggedInUserRole: string;
    errorMessage_DtableError: string;
    errorCount: number;
    endTime: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private exportService: ExportService,
        private cognitoUtil: CognitoUtil,
        private reportService: ReportService,
        private userService: UserService,
        private url: LocationStrategy) {

          }

    public ngOnInit(): void {
        this.endTime = this.reportService.getTokenEndTime();
        this.errorCount = 0;
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.exports = this.route.snapshot.data['trialGroups'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];
        this.selectedCompany = localStorage.getItem('GLOBAL_COMPANY_NAME');
        this.loggedInUserRole = localStorage.getItem("LOGGED_IN_USER_ROLE");
        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Export')

        this.userService.getAllCompanies().subscribe(
            (response) => {
                this.companyList = response;
                
            },
            (err) => {
                this.errorMessage = err;

            });

        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'))
    }
    exportReload() {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            this.errorMessage_DtableError = "Company is changed so page is refreshing..."
            this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/export', '');
            location.reload();

        }
    }

    public ngAfterViewInit(): void {


        this.loadExportLabelsData(Number(localStorage.getItem('GLOBAL_COMPANY_ID')));


    }

    public exportNow(companyId, trialId, drugRegimenId): void {
        
        try {
            let isFileSaverSupported = !!new Blob();
        } catch (e) {
            alert('Browser not supported');
            return;
        }

        

        var response = "Company Id, Trial Id, Drug Regimen Id"+"\n"+companyId + "," +trialId +"," + drugRegimenId;

        let blob = new Blob([decodeURIComponent(encodeURI(response))], {
            type: 'text/csv;charset=utf-8;'
        });

        let filename = 'Export Labels_' + companyId + '_' + trialId + '_' + drugRegimenId+'.csv';
        saveAs(blob, filename);
    }


    

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }

    onChange(selectedValue) {
        $("#datatable_export").dataTable().fnDestroy();
        this.selectedCompanyId = this.getCompanyIdCompanyName(selectedValue);
        this.loadExportLabelsData(this.selectedCompanyId);
        
    }

    getCompanyIdCompanyName(companyName): number {
        let companyId = 0;
        if (this.companyList != null) {
            for (var i = 0; i < this.companyList.length; i++) {
                if (this.companyList[i].companyName == companyName) {
                    companyId = this.companyList[i].companyId;
                }
            }

        }
        return companyId;
    }

    performDataTableRefresh(companyId) {
        this.reportService.isTokenExpired(this.endTime, 'ExportList');
        if (localStorage.getItem("ExportList_IS_TOKEN_EXPIRED") == 'Y') {
            //alert('Expired');
            localStorage.setItem("ExportList_IS_TOKEN_EXPIRED", "N");
            this.endTime = this.reportService.getTokenEndTime();
            this.reportService.isTokenExpired(this.endTime, 'ExportList');
            $(window).scrollTop(5);
            this.errorMessage_DtableError = "Refreshing page...";
            $("#pnlAlertWarning").css("display", "block");
            setTimeout(function () {
                $('#pnlAlertWarning').fadeOut('fast');
            }, 3000); 
            //alert('Refreshing page...');
            this.loadExportLabelsData(companyId);
            //this.authorizationToken = self.getNewIdToken();
        }

    }

    loadExportLabelsData(companyId)
    {
        $("#datatable_export").dataTable().fnDestroy();
        
        var self = this;

        this.cognitoUtil.getIdToken({
            callback() {
                / tslint:disable:no-empty /
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;

                $('#datatable_export')
                    .on('order.dt', function () {

                        //self.performDataTableRefresh(companyId);

                    })
                    .on('search.dt', function () {
                        //alert('search');
                        //self.performDataTableRefresh(companyId);
                    })
                    .on('page.dt', function () {
                        
                        //self.performDataTableRefresh(companyId);

                    })
                    .DataTable({
                    "processing": true,
                    "serverSide": true,
                    "stateSave": true,
                    stateSaveParams: function (settings, data) {
                        delete data.search;
                        data.start = 0;
                    },
                    'ajax': {

                        //'url': 'https://z3neud6k9l.execute-api.us-east-1.amazonaws.com/dev/label/exportdata?companyId=' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')),
                        'url': CommonService.API_PATH_V2_EXPORT_LABEL_DATA + 'label/exportdata?companyId=' + companyId,


                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        error: function (xhr, error, code) {
                            //self.errorCount = self.errorCount + 1;
                            //if (self.errorCount == 1 && (xhr.status == 0 || xhr.status == 401)) {
                            //    $(window).scrollTop(5);
                            //    self.errorMessage_DtableError = "Refreshing page...";
                            //    $("#pnlAlertWarning").css("display", "block");
                            //    setTimeout(function () {
                            //        $('#pnlAlertWarning').fadeOut('fast');
                            //    }, 3000); 
                            //    self.loadExportLabelsData(companyId);
                            //}
                            //else {

                            //    let errorMessage = '';
                            //    if (xhr.responseJSON != undefined)
                            //        errorMessage = xhr.responseJSON.message;
                            //    else
                            //        errorMessage = 'Server error occured';
                            //    self.errorMessage = errorMessage;
                            //    $('.dataTables_processing', $('#datatable_export').closest('.dataTables_wrapper')).hide();
                            //}
                        }
                    }
                    ,
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export',
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_EXPORT_LABEL_DATA + 'label/exportdata?companyId=' + companyId + '&draw=1&columns%5B0%5D%5Bdata%5D=companyName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=companyId&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=trialName&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=trialId&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=drugRegimenName&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=drugRegimenId&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() + '&search%5Bregex%5D=false&_=1535546403868'
                                self.reportService.ExportAll(apiUrl, 'Export Label');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            }
                        }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "companyName" },
                        { "data": "companyId" },
                        { "data": "trialName" },
                        { "data": "trialId" },
                        { "data": "drugRegimenName" },

                        { "data": "drugRegimenId" }

                        ,
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {

                                //return "<div class=\"btn-action\"><a href=\"#/" + 52 + "/trialgroup/" + full.id + "/Export\" class=\"btn btn-primary btn-xs\"><i class=\"glyphicon glyphicon-export\" > </i> Export</a> </div>";
                                return "<div class=\"btn-action\"><button  id=\"" + full.companyId + "_" + full.trialId + "_" + full.drugRegimenId + "\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-upload\" > </i> Export</button> </div>";
                            }
                        }


                    ],
                    "columnDefs": [

                       
                    ]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    }
                });
            }
        });


       
        $('#datatable_export').off('click.rowClick').on('click.rowClick', 'td button', function () {
            
            var attId = $(this).attr('id');
            var companyId = attId.split("_")[0];
            var trialId = attId.split("_")[1];
            var drugRegimenId = attId.split("_")[2];
             self.exportNow(companyId, trialId, drugRegimenId);
                
           


        });

    }

}
