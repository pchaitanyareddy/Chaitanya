﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CompanyService } from '../../services/company.service';
import { UserService } from '../../services/user.service';
import { Company } from '../../models/company';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import { CommonService } from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './company-list.component.html?v=${new Date().getTime()}'
})

export class CompanyListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    @ViewChild('changeStatusModal') public changeStatusModal: ModalDirective;
    @ViewChild('companyOverviewModal') public companyOverviewModal: ModalDirective;
    
    public companies: any;
    public UserRole: typeof UserRole = UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public userToDelete: Company;
    isLoading: boolean;
    public maxSize: number = 5;
    public currentPage: number = 1;
    companyOverviewInformationList: any;
    loggedInCompanyName: string;
    loggedInCompanyId: number;
    privilegesByModule: any;
    privilegesList: any;
    selectedCompanyId: number;
    public privileges: Privileges;
    errorMessage_DtableError: string;
    errorCount: number;
    endTime: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private companyService: CompanyService,
        private userService: UserService,
        private reportService: ReportService,
        private cognitoUtil: CognitoUtil,
        private router: Router,
        private url: LocationStrategy) {
    }

    public ngOnInit(): void {
        this.endTime = this.reportService.getTokenEndTime();
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.errorCount = 0;
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
       
        this.companies = this.route.snapshot.data['companies'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        

        this.companyOverviewInformationList = this.companyService.getCompanyOverviewInformation(this.loggedInCompanyId);

        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Manage Company')  //'Manage Company';
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        this.selectedCompanyId = Number(localStorage.getItem("GLOBAL_COMPANY_ID"));
        
    }
    public ngAfterViewInit(): void {

        this.loadDataTable();

    }
    companyReload() {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            if (Number(localStorage.getItem('GLOBAL_COMPANY_ID'))!=1){
            this.errorMessage_DtableError = "Company is changed so page is refreshing..."
            this.url.pushState(null, null, '/customers/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/view', '');
            location.reload();
            }
            else if (Number(localStorage.getItem('GLOBAL_COMPANY_ID')) == 1) {
                this.errorMessage_DtableError = "Company is changed so page is refreshing..."
                this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/company', '');
                location.reload();
            }

        }

    }
	
    performDataTableRefresh() {
        //alert(localStorage.getItem("CompanyList_IS_TOKEN_EXPIRED"));
        this.reportService.isTokenExpired(this.endTime,'CompanyList');
        if (localStorage.getItem("CompanyList_IS_TOKEN_EXPIRED") == 'Y') {
            location.reload();
            //alert('Expired');
            //localStorage.setItem("CompanyList_IS_TOKEN_EXPIRED", "N");
            //this.endTime = this.reportService.getTokenEndTime();
            //this.reportService.isTokenExpired(this.endTime, 'CompanyList');
            //$(window).scrollTop(5);
            //this.errorMessage_DtableError = "Refreshing page...";
            //$("#pnlAlertWarning").css("display", "block");
            //setTimeout(function () {
            //    $('#pnlAlertWarning').fadeOut('fast');
            //}, 3000); 
            ////alert('Refreshing page...');
            //this.loadDataTable();
            //this.authorizationToken = self.getNewIdToken();
        }

    }


    public loadDataTable(): void {
        $("#datatable_company").dataTable().fnDestroy();
        var self = this; 
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
                
                $('#datatable_company')
		         .on('order.dt', function () {
                        
			        //self.performDataTableRefresh();

                            })
                    .on('search.dt', function () {
                        //alert('search');
                       // self.performDataTableRefresh();
                    })
                    .on('page.dt', function () {
                        
                       // self.performDataTableRefresh();

                    })
		            .DataTable({
                    "processing": true,
                    "serverSide": true,
                    "stateSave": true,
                    stateSaveParams: function (settings, data) {
                        delete data.search;
                        data.start = 0;
                    },
                    "rowId": "id",
                    'ajax': {
                        
                        //'url': 'https://7f3v9h36kf.execute-api.us-east-1.amazonaws.com/dev/company/list/',
                        'url': CommonService.API_PATH_V2_LIST_ALL_COMPANIES+'company/list/',
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        error: function (xhr, error, code) {
			                //self.errorCount = self.errorCount + 1;
                   //         if (self.errorCount==1 && (xhr.status == 0 || xhr.status == 401)) {
                   //             $(window).scrollTop(5);
                   //             self.errorMessage_DtableError = "Refreshing page...";
                   //             $("#pnlAlertWarning").css("display", "block");
                   //             setTimeout(function () {
                   //                 $('#pnlAlertWarning').fadeOut('fast');
                   //             }, 3000); 
                   //             self.loadDataTable();
                   //         }
                   //         else {

                   //             let errorMessage = '';
                   //             if (xhr.responseJSON != undefined)
                   //                 errorMessage = xhr.responseJSON.message;
                   //             else
                   //                 errorMessage = 'Server error occured';
                   //             self.errorMessage = errorMessage;
                   //             $('.dataTables_processing', $('#datatable_company').closest('.dataTables_wrapper')).hide();
                   //         }
                        }
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_LIST_ALL_COMPANIES + 'company/list/?draw=4&columns%5B0%5D%5Bdata%5D=PatientID&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=trialName&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=TrialGroups&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=Company&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=startDate&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=endDate&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=15'
                                self.reportService.ExportAll(apiUrl, 'Company List');
                            },
                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            } }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "companyName" },
                        { "data": "companyType" },
                        { "data": "minPatientAdhTarget" },
                        { "data": "labelsCommitted" },
                        { "data": "labelsPurchased" },
                        { "data": "labelsUsed" },
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a title=\"Cannot Edit this Company as it is already deleted\"  disabled " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/company/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Cannot Delete this company already deleted\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){  localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.labelsUsed >0) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/company/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Cannot Delete this company already associated with labels\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){  localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else  {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/company/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){  localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {

                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a title=\"Cannot Edit this Company as it is already deleted\"  disabled " + localStorage.getItem('GLOBAL_COMPANY_ID') + "/company/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    else if (full.labelsUsed > 0) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/company/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><a  href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/company/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){  localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {

                                    if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Cannot Delete this company already deleted\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){  localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.labelsUsed > 0) {
                                        return "<div class=\"btn-action\"> <button title=\"Cannot Delete this company already associated with labels\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){  localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){  localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () { $('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {

                                    return "";
                                }
                            }
                        }

                    ],
                    "columnDefs": [
                        
                    ]
                    , "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    },
                    "drawCallback": function (settings, json) {
                        $("#datatable_company td").each(function () {
                            var id = $(this).text();

                            if ($.isNumeric(id)) {
                                var num = id;

                                var commaNum = numberWithCommas(num);
                                $(this).text(commaNum);
                            }
                        });
                        function numberWithCommas(number) {
                            var parts = number.toString().split(".");
                            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            return parts.join(".");
                        }
                    }
                    
                });
            }
        });

        $('#datatable_company tbody').on("click", 'tr', function (evt) {
            var attId = $(this).attr('id');
            if (!$(evt.target).is("button")) {
                self.viewCompanyOverview(attId);
            }

        });

        $('#datatable_company').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            this.selectedCompanyId = buttonId;
            if (buttonName == "deleteItem")
                self.deleteItem(buttonId);



        });
        $('#datatable_company tbody').on("click", 'tr', function (evt) {

            self.isLoading = true;

            if ($(evt.target).is("a") && $(evt.target).is('[disabled]') == false) {
                self.isLoading = true;
            }

        });
    }

    public viewCompanyOverview(companyId): void {
        
        this.router.navigate(['/customers', companyId, 'view']);
        
    }

    public deleteItem(id): void {
        this.selectedCompanyId = id
        this.deleteModal.show();
    }


    public hideDeleteModal(): void {
        
        this.deleteModal.hide();
    }

    public hideCompanyOverviewModal(): void {
        this.userToDelete = null;
        this.companyOverviewModal.hide();
    }

   
    

    public confirmDelete(): void {
        let user = this.userToDelete;
        this.isLoading = true;
        this.companyService
            .deleteCompany(this.selectedCompanyId)
            .subscribe(
            (response) => {
                
                this.successMessage = "Selected Company has been Deleted Successfully";
                this.hideDeleteModal();
                this.isLoading = false;
                $("#datatable_company").dataTable().fnDestroy();
                this.loadDataTable();
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public customerChanged(): void {
        this.userService.getUsers(this.selectedCustomerId).subscribe((users) => {
            this.users = users;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/users', '');
        });
    }

    public pageChanged(event: any): void {
        let queryParams = new URLSearchParams();
        queryParams.set('page', event.page);
        queryParams.set('per_page', event.itemsPerPage);

        this.url.pushState(null, null, this.url.path().split('?')[0], queryParams.toString());
        this.userService.getUsers(this.selectedCustomerId, event.page, event.itemsPerPage).subscribe((users) => {
            this.users = users;
        });
    }

    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }
    //Code added by ramesh on 14th Nov 2017
    public changeUserStatus(user): void {
        this.userToDelete = user;
        this.changeStatusModal.show();
    }

    public hideChangeUserStatusModal(): void {
        this.userToDelete = null;
        this.changeStatusModal.hide();
    }


    public confirmChangeStatusConfirmation(): void {
        let user = this.userToDelete;
        this.successMessage = 'User status has been changed successfully';
        this.hideChangeUserStatusModal();
        
    }

    public AddCompany(): void {
        if (!$('#datatable_processing').is(':visible')) {
            this.isLoading = true;
        }
        this.router.navigate(['/', this.selectedCustomerId, 'company', 'new']);
    }
}
