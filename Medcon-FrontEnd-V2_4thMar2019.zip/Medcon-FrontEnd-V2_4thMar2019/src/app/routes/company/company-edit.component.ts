﻿import { UserCreateRequest } from '../../requests/user-create-request';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { CompanyService } from '../../services/company.service';
import { Observable } from 'rxjs/Observable';
import { CompanyRequest } from '../../requests/companyrequest';
import { CompanyEditRequest } from '../../requests/companyEdit-request';

import { CompanyEdit } from '../../models/companyEdit';
import { Company } from '../../models/company';
import { UserRole } from '../../models/userrole';
enum Roles {
    'Medcon Admin',
    'Customer Admin',
    'Label User',
    'Customer User',
    'Patient'
}

enum Companies {

    'ABC Pharmaticual',
    'Test1',
    'Test2'
}

@Component({
    templateUrl: './company-edit.component.html?v=${new Date().getTime()}'
})

export class CompanyEditComponent implements OnInit {
    public companyEdit: FormGroup;
    public showErrors: boolean;
    public errorMessage: string;
    public successMessage: string;
    options: string[];
    myValue: Roles;
    Roles: typeof Roles = Roles;
    companyOptions: string[];
    Companies: typeof Companies = Companies;
    defaultRole;
    defaultCompany;
    companyTypeList: any;
    countryList: any;
    stateList: any;
    public companyEditData: CompanyEdit;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    selectedCompanyType: string;
    selectedCompanyTypeId: number;
    selectedCountry: string;
    selectedState: string;
    selectedStateId: number;
    selectedCountryId: number;
    selectedCompanyId: number;
    selectedPhoneCode: number;
    userId: number;
    isLoading: boolean;
    isResetAction: boolean;
    constructor(public templateService: TemplateService,
        public router: Router,
        public companyService: CompanyService,
        private fb: FormBuilder,
        private route: ActivatedRoute) {
    }

    public ngOnInit() {
        this.isResetAction = false;
        this.isLoading = true;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.userId = Number(localStorage.getItem('GLOBAL_LOGGED_IN_USER_ID'))
        this.companyEditData = this.route.snapshot.data['company'];
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'));
        this.route.params.subscribe(params => {
            this.selectedCompanyId = params['id'];
            
        });

        
        this.companyService.getSelectedCompany(Number(this.selectedCompanyId)).subscribe(
            (response) => {
                this.companyEditData = response;

           

            },
            (err) => {
                this.errorMessage = err;

            });
        this.selectedCompanyType = this.companyEditData.companyType;
        this.companyEdit = this.fb.group({
            companyName: [this.companyEditData.name, [Validators.required]],
            companyType: [this.selectedCompanyType, [Validators.required]],
            companyAdherenceTarget: [this.companyEditData.adherenceTarget],
            address: [this.companyEditData.address, [Validators.required]],
            country: ['', [Validators.required]],
            state: ['', [Validators.required]],
            city: [this.companyEditData.city, [Validators.required, Validators.pattern('[A-Za-z ]{2,45}')]],
            zipcode: [this.companyEditData.zipcode, [Validators.required]],
            phone: [this.companyEditData.phoneNumber]
        });

       
        this.selectedCompanyType = this.companyEditData.companyType;
        this.selectedCountryId = this.companyEditData.countryId;
        this.selectedStateId = this.companyEditData.stateId;

        
        
       
        this.companyTypeList = [
            
            { companyTypeId: 2, companyType: 'Label Manufacturing' },
            { companyTypeId: 3, companyType: 'Pharmaceutical' },
            
        ]

        
        

        this.companyService.getCountries().subscribe(
            (response) => {
                this.countryList = response;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });

        this.GetStatesByCountry(this.selectedCountryId);

    }

    public onSubmit() {
        var Cname = this.companyEdit.value.companyName.trim();
        var city = this.companyEdit.value.city.trim();
        this.showErrors = true;
        this.errorMessage = "";
        if (this.companyEdit.invalid) {
            this.showErrors = true;
            return;
        }
        else if (String(this.selectedCountryId) == 'NaN' || this.selectedCountryId == undefined || this.selectedCountryId == 0) {
            this.showErrors = true;
            this.errorMessage = "Please Select Country";
        }
        
        else if ($('#ddlstate :selected').text() == undefined || $('#ddlstate :selected').text() == 'NaN' || $('#ddlstate :selected').text() == '') {

            this.showErrors = true;
            this.errorMessage = "Please Select State";
        }
        else if (!this.isValidNumber(Number(this.companyEdit.value.companyAdherenceTarget))){
            this.showErrors = true;
            this.errorMessage = "Please enter Valid Range values(0 - 100) for Company Adherence Target";
        }
        else if (Cname == '') {
            this.errorMessage = "Please enter valid company name"
            this.companyEdit.controls['companyName'].setValue('');
            $(window).scrollTop(5);
        }
        else if (city == '') {
            this.errorMessage = "Please enter city"
            this.companyEdit.controls['city'].setValue('');
            $(window).scrollTop(5);
        }
        else {
            this.isLoading = true;
            let request = new CompanyEditRequest(
                
                Cname,
                this.selectedCompanyType,
                Number(this.companyEdit.value.companyAdherenceTarget),
                this.companyEdit.value.address,
                this.selectedCountryId,
                this.selectedStateId,
                city,
                Number(this.companyEdit.value.zipcode),
                Number(this.companyEdit.value.phone),
                Number(this.userId)


            );
            this.companyService.updateCompany(this.selectedCompanyId, request).subscribe(
                (response) => {
                    localStorage.setItem('GLOBAL_COMPANY_NAME', String(this.companyEdit.value.companyName));
                    this.isLoading = false;
                    this.companyEdit.markAsPristine();
                    this.goBack();
                },
                (err) => {
                    this.isLoading = false;
                    this.errorMessage = err;
                });


        }
    }

    public alertClosed(): void {
        this.errorMessage = null;
    }

    public goBack(): void {
        this.isLoading = true;
        let companyId = localStorage.getItem('GLOBAL_COMPANY_ID');
        if (companyId != "1") {
            
            this.router.navigate(['/customers', companyId, 'view']);
        }
        else
            this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'company']);
    }

    @HostListener('window:beforeunload')
    public canDeactivate(): Observable<boolean> | boolean {
        return !this.companyEditData.dirty;
    }

    onChange(selectedValue) {
        
        let countryId = Number(selectedValue);
        
        this.GetStatesByCountry(countryId);
                
        this.selectedCountryId = Number(selectedValue);
        this.selectedCountry = null;
        //To get selected role name
        if (this.countryList != null) {
            for (var i = 0; i < this.countryList.length; i++) {
                if (this.countryList[i].id == this.selectedCountryId) {
                    this.selectedCountry = this.countryList[i].name;
                    this.selectedPhoneCode = this.countryList[i].phonecode;
                    this.companyEdit.controls["phone"].setValue("+" + this.selectedPhoneCode);
                    if (this.isResetAction) {
                        this.companyEdit.controls["phone"].setValue(this.companyEditData.phoneNumber);
                        this.isResetAction = false;
                    }
                }
            }

        }

    }

    onChange_CompanyType(selectedValue) {
        
        this.selectedCompanyType = selectedValue;
        

    }

    onChange_State(selectedValue) {
        this.selectedStateId = Number(selectedValue);
        this.selectedState = null;
        //To get selected role name
        if (this.stateList != null) {
            for (var i = 0; i < this.stateList.length; i++) {
                if (this.stateList[i].id == this.selectedStateId) {
                    this.selectedState = this.stateList[i].name;
                }
            }

        }

    }

    GetStatesByCountry(countryId) {

        this.isLoading = true;
        this.companyService.getStatesByCountry(countryId).subscribe(
            (response) => {
                this.stateList = response;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });

    }
    isValidNumber(val): boolean {

        if (val < 0)
            return false;
        else if (val > 100)
            return false;
        else
            return true;

    }


    resetData() {
        
        this.ngOnInit();
        this.selectedCountryId = this.companyEditData.countryId;
        this.selectedStateId = this.companyEditData.stateId;
        this.companyEdit.controls["country"].setValue(this.selectedCountryId);
        this.companyEdit.controls["state"].setValue(this.selectedStateId);
        this.companyEdit.controls["phone"].setValue(this.companyEditData.phoneNumber);
        $('#phone').val(this.companyEditData.phoneNumber);  
        this.isResetAction = true;
    }

}
