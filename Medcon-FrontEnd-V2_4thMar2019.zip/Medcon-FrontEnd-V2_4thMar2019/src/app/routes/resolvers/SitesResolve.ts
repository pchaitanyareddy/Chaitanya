import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SiteService } from '../../services/site.service';
import { Site } from '../../models/site';

@Injectable()
export class SitesResolve implements Resolve<Site[]> {
	constructor(private siteService: SiteService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Site[]> | Promise<Site[]> | Site[] {
		return this.siteService.getSites(route.params['customer_id']);
	}
}
