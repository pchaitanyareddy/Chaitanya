import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TrialService } from '../../services/trial.service';
import { Trial } from '../../models/trial';

@Injectable()
export class TrialResolve implements Resolve<Trial> {
	constructor(private trialService: TrialService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Trial> | Promise<Trial> | Trial {
        return this.trialService.getTrial(route.params['id']);
	}
}
