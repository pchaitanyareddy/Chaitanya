﻿
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BroadcastMessagesService } from '../../services/broadcastMessages.service';
import { BroadcastMessages } from '../../models/broadcastMessages';

@Injectable()
export class BroadcastMessageResolve implements Resolve<BroadcastMessages> {
    constructor(private broadcastMessagesService: BroadcastMessagesService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<BroadcastMessages> | Promise<BroadcastMessages> | BroadcastMessages {
        return this.broadcastMessagesService.getBroadcastMessage(route.params['id']);
    }
}
