import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PatientService } from '../../services/patient.service';
import { Race } from '../../models/race';

@Injectable()
export class RacesResolve implements Resolve<Race[]> {
	constructor(private patientService: PatientService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Race[]> | Promise<Race[]> | Race[] {
		return this.patientService.getRaces(route.params['customer_id']);
	}
}
