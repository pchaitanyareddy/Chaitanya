﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MeasureService } from '../../services/measure.service';
import { Measurement } from '../../models/measurement';
import { Pagination } from '../../models/pagination';

@Injectable()
export class MeasurementResolve implements Resolve<Measurement> {
    constructor(private measureService: MeasureService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<Measurement> | Promise<Measurement> | Measurement {
        return this.measureService.getMeasurement(route.params['id'], route.params['customer_id']);
    }
}
