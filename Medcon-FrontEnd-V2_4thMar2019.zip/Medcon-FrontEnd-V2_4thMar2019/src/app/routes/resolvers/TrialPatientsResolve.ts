import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TrialService } from '../../services/trial.service';
import { Patient } from '../../models/patient';

@Injectable()
export class TrialPatientsResolve implements Resolve<Patient[]> {
	constructor(private trialService: TrialService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<Patient[]> | Promise<Patient[]> | Patient[] {
		return this.trialService.getPatients(route.params['id'], route.params['customer_id']);
	}
}
