﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TrialGroupService } from '../../services/trialgroup.service';
import { TrialGroup } from '../../models/trialgroup';
import { Pagination } from '../../models/pagination';
@Injectable()
export class TrialGroupListResolve implements Resolve<(Pagination<TrialGroup>)> {
    constructor(private trialGroupService: TrialGroupService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<TrialGroup>
        | Promise<(Pagination<TrialGroup>)>
        | TrialGroup {
        return this.trialGroupService.getSelectedTrialGroup(route.params['id']);
    }



}
