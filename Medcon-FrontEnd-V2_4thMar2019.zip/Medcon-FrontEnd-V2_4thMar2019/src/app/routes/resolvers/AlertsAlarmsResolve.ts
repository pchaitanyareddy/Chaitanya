import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AlertAlarmService } from '../../services/alert-alarms.service';
import { AlertAlarm } from '../../models/alert-alarm';

@Injectable()
export class AlertsAlarmsResolve implements Resolve<(Observable<AlertAlarm[]>)> {
	constructor(private alertAlarmService: AlertAlarmService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<(AlertAlarm[])> {
		return this.alertAlarmService.getAlertsAlarms();
	}
}
