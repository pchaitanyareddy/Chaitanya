﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CompanyService } from '../../services/company.service';
import { Company } from '../../models/company';

@Injectable()
export class CompanyResolve implements Resolve<Company> {
    constructor(private companyService: CompanyService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<Company> | Promise<Company> | Company {
        return this.companyService.getSelectedCompany(route.params['id']);
    }


   
}

