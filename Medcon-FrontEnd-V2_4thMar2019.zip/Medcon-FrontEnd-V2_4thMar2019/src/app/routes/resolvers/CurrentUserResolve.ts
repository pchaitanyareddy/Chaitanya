import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CurrentUserService } from '../../services/currentuser.service';

@Injectable()
export class CurrentUserResolve implements Resolve<{ [key: string]: string }> {
	constructor(private currentUserService: CurrentUserService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<({ [key: string]: string })>
		| Promise<{ [key: string]: string }>
		| { [key: string]: string } {
		return this.currentUserService.getUserAttributes();
	}
}
