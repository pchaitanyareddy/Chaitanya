import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TrialService } from '../../services/trial.service';

@Injectable()
export class TrialContainersResolve implements Resolve<any> {
	constructor(private trialService: TrialService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<any> | Promise<any> | any {
		return this.trialService.getContainers(route.params['id'], route.params['customer_id']);
	}
}
