import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LabelService } from '../../services/label.service';

@Injectable()
export class TrialLabelsResolve implements Resolve<any> {
	constructor(private labelService: LabelService) {
	}

	public resolve(route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<any> | Promise<any> | any {
		return this.labelService.getOverview(route.params['id'], route.params['customer_id']);
	}
}
