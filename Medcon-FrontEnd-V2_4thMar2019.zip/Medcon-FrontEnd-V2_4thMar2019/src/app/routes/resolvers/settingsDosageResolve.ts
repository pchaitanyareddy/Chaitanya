﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SettingsService } from '../../services/settings.service';
import { Settings } from '../../models/settings';

@Injectable()
export class SettingsDosageResolve implements Resolve<Settings> {
    constructor(private SettingsService: SettingsService) {
    }

   
    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<Settings> | Promise<Settings> | Settings {
        return this.SettingsService.getDosageWindows();
    }

}
