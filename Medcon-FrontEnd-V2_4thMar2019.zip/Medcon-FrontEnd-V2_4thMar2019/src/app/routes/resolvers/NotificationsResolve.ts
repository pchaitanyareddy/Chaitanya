﻿import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { NotificationsService } from '../../services/notifications.service';
import { Notifications } from '../../models/notifications';
import { Pagination } from '../../models/pagination';

@Injectable()
export class NotificationsResolve implements Resolve<Notifications> {
    constructor(private NotificationService: NotificationsService) {
    }

    public resolve(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<Pagination<Notifications>> | Promise<Notifications> | Notifications {
        return this.NotificationService.getNotification(route.params['id'], route.params['customer_id']);
    }
}
