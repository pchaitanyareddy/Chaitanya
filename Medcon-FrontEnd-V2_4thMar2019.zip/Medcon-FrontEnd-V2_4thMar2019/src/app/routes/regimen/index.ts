export * from './regimen-new.component';
export * from './regimen-list.component';
export * from './regimen-edit.component';
