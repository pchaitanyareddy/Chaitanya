import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { LocationStrategy } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap';
import { TemplateService } from '../../services/template.service';
import { CustomerService } from '../../services/customer.service';
import { SiteService } from '../../services/site.service';
import { Site } from '../../models/site';
import { UserRole } from '../../models/userrole';
import { Customer } from '../../models/customer';
import { Pagination } from '../../models/pagination';
import '../../../assets/js/Common/datatable/jquery-1.12.4.js';
import '../../../assets/js/Common/datatable/jquery.dataTables.min.js';
import '../../../assets/js/Common/datatable/dataTables.buttons.min.js';
import '../../../assets/js/Common/datatable/buttons.flash.min.js';
import '../../../assets/js/Common/datatable/buttons.html5.min.js';
import '../../../assets/js/Common/datatable/jszip.min.js';
import '../../../assets/js/Common/datatable/buttons.print.min.js';
import { PrivilegesService } from '../../services/privileges.service';
import { Privileges } from '../../models/privileges';
import { CognitoUtil } from '../../services/cognito/cognitoutil.service';
import {CommonService} from '../../services/commonService';
import { ReportService } from '../../services/report.service';
var $ = require('jquery');
var dt = require('datatables.net');
require('style-loader!datatables.net-bs/css/dataTables.bootstrap.css');
@Component({
    templateUrl: './site-list.component.html?v=${new Date().getTime()}'
})

export class SiteListComponent implements OnInit {
    @ViewChild('deleteModal') public deleteModal: ModalDirective;
    public sites: Pagination<Site>;
    public UserRole: typeof UserRole = UserRole;
    public currentUserRole: UserRole;
    public customers: Customer[];
    public selectedCustomerId: number;
    public successMessage: string;
    public errorMessage: string;
    public selectedSiteId: number;
    isLoading: boolean;
    public maxSize: number = 5;
    public currentPage: number = 1;
    siteList: any;
    privilegesByModule: any;
    privilegesList: any;
    public privileges: Privileges;
    errorMessage_DtableError: string;
    errorCount: number;
    endTime: number;
    selectedCompanyId: number;
    constructor(private route: ActivatedRoute,
        public templateService: TemplateService,
        private customerService: CustomerService,
        private SiteService: SiteService,
        private reportService: ReportService,
        private cognitoUtil: CognitoUtil,
        private router: Router,
        private url: LocationStrategy) {
    }

    public ngOnInit(): void {
        setTimeout(function () {
            location.reload();
        }, 1500000);
        this.endTime = this.reportService.getTokenEndTime();
        this.errorCount = 0;
        this.isLoading = false;
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.currentUserRole = this.route.snapshot.data['role'];
        this.sites = this.route.snapshot.data['sites'];
        this.selectedCustomerId = this.route.snapshot.params['customer_id'];

        if (this.route.queryParams['page']) {
            this.currentPage = this.route.queryParams['page'];
        }

        if (this.currentUserRole === UserRole.MedConAdmin) {
            this.SiteService.getSiteList(this.selectedCustomerId)
                .subscribe((site) => {
                    this.sites = site;
                    
                    this.hideDeleteModal();
                }
                );
        }


        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Manage Sites')
        localStorage.setItem('IS_ALLOWED_EDIT', this.privilegesByModule[0].edit);
        localStorage.setItem('IS_ALLOWED_DELETE', this.privilegesByModule[0].delete);
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'))
    }
    siteReload() {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            this.errorMessage_DtableError = "Company is changed so page is refreshing..."
            this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/sites', '');
            location.reload();

        }
    }
    performDataTableRefresh() {
        this.reportService.isTokenExpired(this.endTime,'SiteList');
        if (localStorage.getItem("SiteList_IS_TOKEN_EXPIRED") == 'Y') {
            //alert('Expired');
            localStorage.setItem("SiteList_IS_TOKEN_EXPIRED", "N");
            this.endTime = this.reportService.getTokenEndTime();
            this.reportService.isTokenExpired(this.endTime,'SiteList');
            $(window).scrollTop(5);
            this.errorMessage_DtableError = "Refreshing page...";
            $("#pnlAlertWarning").css("display", "block");
            setTimeout(function () {
                $('#pnlAlertWarning').fadeOut('fast');
            }, 3000);
            //alert('Refreshing page...');
            this.loadDataTable();
            //this.authorizationToken = self.getNewIdToken();
        }

    }
    public loadDataTable(): void {
        $("#datatable_site").dataTable().fnDestroy();
        var self = this;
        this.cognitoUtil.getIdToken({
            callback() {
                /* tslint:disable:no-empty */
            },
            callbackWithParam(token: any) {

                this.authorizationToken = token;
               
                $('#datatable_site')
                    .on('order.dt', function () {

                        //self.performDataTableRefresh();

                    })
                    .on('search.dt', function () {
                        //alert('search');
                        //self.performDataTableRefresh();
                    })
                    .on('page.dt', function () {

                        //self.performDataTableRefresh();

                    })
                    .DataTable({
                    "processing": true,
                    "serverSide": true,
                    "stateSave": true,
                    stateSaveParams: function (settings, data) {
                        delete data.search;
                        data.start = 0;
                    },
                    'ajax': {
                        
                        //'url': 'https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com/dev/site/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'url': CommonService.API_PATH_V2_LIST_ALL_SITES+'site/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID'),
                        'type': 'GET',
                        'beforeSend': function (request) {
                            request.setRequestHeader("Authorization", token);
                        }
                        ,
                        error: function (xhr, error, code) {
                            //self.errorCount = self.errorCount + 1;
                            //if (self.errorCount == 1 && (xhr.status == 0 || xhr.status == 401)) {
                            //    $(window).scrollTop(5);
                            //    self.errorMessage_DtableError = "Refreshing page...";
                            //    $("#pnlAlertWarning").css("display", "block");
                            //    setTimeout(function () {
                            //        $('#pnlAlertWarning').fadeOut('fast');
                            //    }, 3000);
                            //    self.loadDataTable();
                            //}
                            //else {

                            //    let errorMessage = '';
                            //    if (xhr.responseJSON != undefined)
                            //        errorMessage = xhr.responseJSON.message;
                            //    else
                            //        errorMessage = 'Server error occured';
                            //    self.errorMessage = errorMessage;
                            //    $('.dataTables_processing', $('#datatable_site').closest('.dataTables_wrapper')).hide();
                            //}
                        }
                    }
                   

                    ,
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'csv', text: 'Export', exportOptions: {
                                columns: [0, 1, 2, 3]
                            },
                            action: function () {
                                let apiUrl = CommonService.API_PATH_V2_LIST_ALL_SITES + 'site/list/company/' + localStorage.getItem('GLOBAL_COMPANY_ID') + '?draw=2&columns%5B0%5D%5Bdata%5D=trailGroupName&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=true&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=createdBy&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=createdDate&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=id&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=true&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B4%5D%5Bdata%5D=trailCount&columns%5B4%5D%5Bname%5D=&columns%5B4%5D%5Bsearchable%5D=true&columns%5B4%5D%5Borderable%5D=true&columns%5B4%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B4%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B5%5D%5Bdata%5D=status&columns%5B5%5D%5Bname%5D=&columns%5B5%5D%5Bsearchable%5D=true&columns%5B5%5D%5Borderable%5D=true&columns%5B5%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B5%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B6%5D%5Bdata%5D=6&columns%5B6%5D%5Bname%5D=&columns%5B6%5D%5Bsearchable%5D=true&columns%5B6%5D%5Borderable%5D=false&columns%5B6%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B6%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=0&order%5B0%5D%5Bdir%5D=desc&start=0&length=-1&search%5Bvalue%5D=' + $('input[type="search"]').val() +'&search%5Bregex%5D=false&_=1525343677314'
                                self.reportService.ExportAll(apiUrl, 'Site List');
                            },

                        },
                        {
                            extend: 'print', text: 'Print', exportOptions: {
                                columns: [0, 1, 2, 3]
                            } }

                    ],
                    "order": [[0, "desc"]],
                    "columns": [
                        { "data": "siteName" },
                        { "data": "siteAdress" },
                        {
                            "data": "countryName",
                            "render": function (data, type, full, meta) {


                                return '<div style="cursor:pointer" title=' + full.fulllocation + '>' + full.countryName + '</div>';

                            } },
                        { "data": "phoneNumber" },
                       
                        {
                            sortable: false,
                            "render": function (data, type, full, meta) {
                                if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.numTrials > 0) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/sites/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Can not delete this site as it is associated with trial\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a disabled title=\"Can not edit this site as it is in Inactive status\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button title=\"Can not delete this site as it is in Inactive status\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/sites/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> <button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 1 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 0) {
                                    if (full.numTrials > 0) {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/sites/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a></div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><a disabled title=\"Can not edit this site as it is in Inactive status\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><a href=\"#/" + localStorage.getItem('GLOBAL_COMPANY_ID') + "/sites/" + full.id + "/edit\" class=\"btn btn-primary btn-xs\"><i class=\"fa fa-pencil\" > </i> Edit</a> </div>";
                                    }
                                }
                                else if (Number(localStorage.getItem('IS_ALLOWED_EDIT')) == 0 && Number(localStorage.getItem('IS_ALLOWED_DELETE')) == 1) {
                                    if (full.numTrials > 0) {
                                        return "<div class=\"btn-action\"><button title=\"Can not delete this site as it is associated with trial\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else if (full.status == 0) {
                                        return "<div class=\"btn-action\"><button title=\"Can not delete this site as it is in Inactive status\" disabled id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                    else {
                                        return "<div class=\"btn-action\"><button  id=\"" + full.id + "_deleteItem" + "\" class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\" > </i> Delete</button> <script> function DeleteFn(id){ localStorage.setItem('ID', id); $('#pnlDeleteModal').modal('show');  }  $('#btnCloseModalPopup,#btnCancel_Popup,#btnConfirmDelete').click(function () {$('#pnlDeleteModal').modal('hide');});</script>  </div>";
                                    }
                                }
                                else {
                                    return "";
                                }
                                
                            }
                        }

                    ]
                    //,
                    //"columnDefs": [
                    
                    //    {
                    //        "targets": [3],
                    //        render: function (toFormat) {
                    //            return toFormat.toString().replace(
                    //                /(\d\d\d)(\d\d\d)(\d\d\d\d)/g, '$1-$2-$3'
                    //            );
                    //        }
                    //    }
                       
                    //]
                    ,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
                    ,
                   
                    "language": {
                        "emptyTable": "No data available in table",
                        "info": "Showing _START_ to _END_ of _TOTAL_ Entries",
                        "infoEmpty": "Showing 0 to 0 of 0 Entries",
                        "infoFiltered": "(filtered from _MAX_ total Entries)",
                        "infoPostFix": "",
                        "thousands": ",",
                        "lengthMenu": "Show _MENU_ Entries",
                    }
                });
            }
        });
        $('#datatable_site').on('click', 'td button', function () {

            var attId = $(this).attr('id');
            var buttonId = attId.split("_")[0];
            var buttonName = attId.split("_")[1];
            this.selectedSiteId = buttonId;
            if (buttonName == "deleteItem")
                self.deleteItem(buttonId);



        });
        $('#datatable_site tbody').on("click", 'tr', function (evt) {


            if ($(evt.target).is("a") && $(evt.target).is('[disabled]') == false) {
                self.isLoading = true;
            }

        });
    }

    public ngAfterViewInit(): void {

       

        this.loadDataTable();
        
    }

    public deleteItem(id): void {
        this.selectedSiteId = id;
        this.deleteModal.show();
    }

    public hideDeleteModal(): void {
        this.selectedSiteId = null;
        this.deleteModal.hide();
    }

    public confirmDelete(): void {
        this.isLoading = true;
        this.SiteService
            .deleteSite(this.selectedSiteId)
            .subscribe(
            (response) => {
                
                this.successMessage = "successfully deleted Site";
                this.hideDeleteModal();
               
                this.isLoading = false;
                $("#datatable_site").dataTable().fnDestroy();
                this.loadDataTable();
            },
            (err) => {
                this.errorMessage = err;
                this.hideDeleteModal();
            }
            );
    }

    public customerChanged(): void {
        this.SiteService.getSiteList(this.selectedCustomerId).subscribe((sites) => {
            this.sites = sites;
            this.url.pushState(null, null, '/' + this.selectedCustomerId + '/sites', '');
        });
    }


    public alertClosed(): void {
        this.successMessage = null;
        this.errorMessage = null;
    }
   
    public AddSite(): void {
        if (!$('#datatable_processing').is(':visible')) {
            this.isLoading = true;
        }
        this.router.navigate(['/', this.selectedCustomerId, 'sites', 'new']);
    }
}
