import { Component, HostListener, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TemplateService } from '../../services/template.service';
import { SiteService } from '../../services/site.service';
import { Customer } from '../../models/customer';
import { SiteRequest } from '../../requests/site-request';
import { Observable } from 'rxjs/Observable';


@Component({
    templateUrl: './site-new.component.html?v=${new Date().getTime()}'
})

export class SiteNewComponent implements OnInit {
	public form: FormGroup;
	public showErrors: boolean;
	public customer: Customer;
    public errorMessage: string;
    public successMessage: string;
    public selectedPhoneCode: number;
    isLoading: boolean;
	public states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut',
		'Delaware', 'District of Columbia', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana',
		'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan',
		'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
		'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma',
		'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas',
        'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];

    selectedStateId: number;
    selectedCountryId: number;
    selectedCountry: string;
    selectedState: string;
    stateList: any;
    countryList: any;
    userId: number;
    zipCode: number;
	constructor(public templateService: TemplateService,
		private router: Router,
		private route: ActivatedRoute,
		private fb: FormBuilder,
        private siteService: SiteService
      ) {
	}

	public ngOnInit(): void {
		this.customer = this.route.snapshot.data['customer'];
        this.isLoading = true;
        this.form = this.fb.group({
            name: ['', [Validators.required]],
            address_line_1: ['', [Validators.required]],
            city: ['', Validators.required],
            zip_code: ['', Validators.required],
            state: [this.states[0], Validators.required],
            country: [this.states[0], Validators.required],
            phone: ['', Validators.required],
        });

        this.siteService.getCountries().subscribe(
            (response) => {
                this.countryList = response;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });
        
	}

    public onSubmit(): void {
        this.userId = Number(this.route.snapshot.params['customer_id']);
        this.zipCode = Number(this.form.value.zip_code);
        var siteName = this.form.value.name.trim();
        var cityValue = this.form.value.city.trim();
		if (this.form.invalid) {
			this.showErrors = true;
        }
        else if (String(this.selectedCountryId) == 'NaN' || this.selectedCountryId == undefined) {
            this.showErrors = true;
            this.errorMessage = "Please Select Country"
        }
        else if (String(this.selectedStateId) == 'NaN' || this.selectedStateId == undefined) {
            this.showErrors = true;
            this.errorMessage = "Please Select State"
        }
        else if (siteName == '') {
            this.errorMessage = "Please enter valid  site name"
            this.form.controls['name'].setValue('');
            $(window).scrollTop(5);
        }
        else if (cityValue == '') {
            this.errorMessage = "Please enter city"
            this.form.controls['city'].setValue('');
            $(window).scrollTop(5);
        }
        else {
            this.isLoading = true;
			// TODO: NEED TO ADD COUNTRY SELECTOR TO THE VIEW
            let request = new SiteRequest(
                this.userId,
                siteName, 
                this.form.value.address_line_1,
                this.selectedCountryId,//country id//this.form.value.city,
                this.selectedStateId,//state_id this.form.value.zip_code,
                cityValue,
                this.zipCode,
                this.form.value.phone
			);

            this.siteService.createSite(request, Number(localStorage.getItem('GLOBAL_COMPANY_ID'))).subscribe(
                (response) => {
                    this.isLoading = false;
                    this.form.markAsPristine();
                    this.successMessage = 'Site successfully created';
                    $(window).scrollTop(5);
					this.goBack();
				},
                (err) => {
                    this.isLoading = false;
					this.errorMessage = err;
				});
		}
	}

	public alertClosed(): void {
		this.errorMessage = null;
	}

    public goBack(): void {
        this.isLoading = true;
		this.form.markAsPristine();
        this.router.navigate(['/', this.route.snapshot.params['customer_id'], 'sites']);
    }

    onChange(selectedValue) {
        this.isLoading = true;
        let countryId = Number(selectedValue);
        //Call API when country is selected, then retrieve data for state drop down list
        this.siteService.getStatesByCountry(countryId).subscribe(
            (response) => {
                this.stateList = response;
                this.isLoading = false;
            },
            (err) => {
                this.errorMessage = err;
                this.isLoading = false;
            });

        this.selectedCountryId = Number(selectedValue);
        this.selectedCountry = null;
        this.selectedPhoneCode = null;

        //To get selected role name
        if (this.countryList != null) {
            for (var i = 0; i < this.countryList.length; i++) {
                if (this.countryList[i].id == this.selectedCountryId) {
                    this.selectedCountry = this.countryList[i].name;
                    this.selectedPhoneCode = this.countryList[i].phonecode;
                    $('#phone').val("+"+this.selectedPhoneCode+"-");                   
                }
               
            }

        }

    }

    

    onChange_State(selectedValue) {
        this.selectedStateId = Number(selectedValue);
        this.selectedState = null;
        //To get selected role name
        if (this.stateList != null) {
            for (var i = 0; i < this.stateList.length; i++) {
                if (this.stateList[i].id == this.selectedStateId) {
                    this.selectedState = this.stateList[i].name;
                }
            }

        }

    }

    clearData() {
        this.form.reset();
    }

	@HostListener('window:beforeunload')
	public canDeactivate(): Observable<boolean> | boolean {
		return !this.form.dirty;
	}
}
