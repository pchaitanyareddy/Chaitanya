//export * from './customer-new.component';
//export * from './customers-list.component';
export * from './customer-view.component';
//export * from './customer-edit.component';
