import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TemplateService } from '../../services/template.service';
import { PatientService } from '../../services/patient.service';
import { DoseService } from '../../services/dose.service';
import { UserService } from '../../services/user.service';
import { TrialService } from '../../services/trial.service';
import { LabelService } from '../../services/label.service';
import { CompanyService } from '../../services/company.service';
import { Customer } from '../../models/customer';
import { CompanyOverview } from '../../models/CompanyOverview';
import { Drug } from '../../models/drug';
import { Regimen } from '../../models/regimen';
import { Site } from '../../models/site';
import { UserRole } from '../../models/userrole';
import { ModalDirective, TabsetComponent } from 'ngx-bootstrap';
import { Privileges } from '../../models/privileges';
import { LocationStrategy } from '@angular/common';
@Component({
    templateUrl: './customer-view.component.html?v=${new Date().getTime()}',
    styleUrls: ['./customer-view.component.scss?v=${new Date().getTime()}']
})

export class CustomerViewComponent implements OnInit {
    //public customer: Customer;
    public customer: CompanyOverview;
	public UserRole: typeof UserRole = UserRole;
	public currentUserRole: UserRole;
	public regimens: Regimen[];
	public drugs: Drug[];
	public site: Site;
	public patientOverview: any;
	public doseOverview: any;
	public userOverview: any;
	public trialOverview: any;
	public labelOverview: any;
	public activeYear: number;
	public years = [];
    public labelDetailsList: any;
    public companyId: number;
    public labelDetailsObject: number;
    public errorMessage: string;
    public isLoading: boolean;
    privilegesByModule: any;
    privilegesList: any;
    selectedCompanyId: number;
    errorMessage_DtableError: string;
    public privileges: Privileges;
    @ViewChild('labelDetailsModal') public labelDetailsModal: ModalDirective;
	constructor(public templateService: TemplateService,
        private route: ActivatedRoute,
        private router: Router,
		private patientService: PatientService,
		private doseService: DoseService,
		private userService: UserService,
        private trialService: TrialService,
        private companyService: CompanyService,
        private labelService: LabelService,
        private url: LocationStrategy) {
	}

	public ngOnInit(): void {
        $(window).scrollTop(5);
        this.customer = this.route.snapshot.data['companyOverview'];
        
        if (this.route.snapshot.params['customer_id'] != undefined)
        {
            this.companyId = Number(this.route.snapshot.params['customer_id']);
        }
        else if (localStorage.getItem("GLOBAL_COMPANY_ID") != undefined)
        {
            this.companyId = Number(localStorage.getItem("GLOBAL_COMPANY_ID"));

        }
		for (let i = 2017; i <= 2017 + 1; i++) {
			this.years.push(i);
		}
		this.activeYear = this.years[0];
        this.yearChanged();


        

        //19th July 2018 code added to check edit company access privileges to the given role
        this.privileges = this.route.snapshot.data['privileges'];
        this.privilegesList = this.privileges;
        this.privilegesByModule = this.privilegesList.filter(
            privileges => privileges.moduleName === 'Manage Company') 


        //End
        this.selectedCompanyId = Number(localStorage.getItem('GLOBAL_COMPANY_ID'))
       
	}

	public yearChanged(): void {
		
    }

    public hideLabelDetailsModal(): void {
        
        this.labelDetailsModal.hide();
    }
    companyReload() {
        if (this.selectedCompanyId != Number(localStorage.getItem('GLOBAL_COMPANY_ID'))) {
            if (Number(localStorage.getItem('GLOBAL_COMPANY_ID')) != 1) {
                this.errorMessage_DtableError = "Company is changed so page is refreshing..."
                this.url.pushState(null, null, '/customers/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/view', '');
                location.reload();
            }
            else if (Number(localStorage.getItem('GLOBAL_COMPANY_ID')) == 1) {
                this.errorMessage_DtableError = "Company is changed so page is refreshing..."
                this.url.pushState(null, null, '/' + Number(localStorage.getItem('GLOBAL_COMPANY_ID')) + '/company', '');
                location.reload();
            }

        }

    }

    public viewLabelDetails(): void {
        var dt = new Date();
        let year = dt.getFullYear();
        this.companyService.getCompanyOverview_LabelDetails(this.companyId, year).subscribe(
            (response) => {
               
                let status = (response.status) ? "Active" : "Inactive";
                $("#spnActive").text(status);
                $("#spnCommitted").text(response.committed);
                $("#spnPurchased").text(response.purchased);
                $("#spnUsed").text(response.used);
                $("#spnRemaining").text(response.remaining);
                $("#Country").text(response.country);
                $("#Gender").text(response.gender);
                $("#State").text(response.state);
                $("#EmailAddress").text(response.emailAddress);
                $("#City").text(response.location);
                $("#Mobile").text(response.phoneNumber);
                $("#Zipcode").text(response.zipcode);
                $("#Race").text(response.race);
                $("#City").text(response.city);
                this.LoadLabelPurchaseData(this.companyId);
                this.labelDetailsModal.show();
                
            },
            (err) => {
                this.errorMessage = err;

            });

       
    }

    public LoadLabelPurchaseData(companyId): void {

        
        var dt = new Date();
        let year = dt.getFullYear();

        this.labelService.getLabelPurchase(companyId,year).subscribe(
            (response) => {
                this.labelDetailsList = response



            },
            (err) => {
                this.errorMessage = err;

            });

    }

    public btnEditCompany(): void {
        
        this.isLoading = true;
        this.router.navigate(['/', this.companyId, 'company', this.companyId, 'edit']);
    }


}
